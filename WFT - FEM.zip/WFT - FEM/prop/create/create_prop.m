%% Defini��o da Propriedade 2D do Problema

%% INPUT
% Prop_Param        - Estrutura de Dados Inicial da Propriedade do Problema
% t                 - Espessura da Placa 2D

%% OUPTUR
% Mat_Param         - Estrutura de Dados Final do Material do Problema

%% Declara��o da Fun��o de Defini��o da Propriedade 2D do Problema
function [ Prop_Param ] = create_prop ( Prop_Param , t )

    % Defini��o do Id da Propriedade 2D
    Prop_Param ( 1 ).id = 1;
    
    % Defini��o do Tipo da Propriedade
    Prop_Param ( 1 ).type  = '2d';
    
    % Defini��o da Espessura da Proprieade
    Prop_Param ( 1 ).thick = t;
   
end