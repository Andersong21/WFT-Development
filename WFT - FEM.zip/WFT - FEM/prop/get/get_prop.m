%% Retorno do Gerador das Propriedes do Problema

%% INPUT
% t                - Espessura da Placa 2D

%% OUPTUT
% Section_Param    - Estrutura de Dados das Propriedades do Sistema

%% Declara��o da Fun��o de Retorno do Gerador de Propriedades do Problema
function [ Prop_Param ] = get_prop ( t )

    % Inicializa��o do Timer
    t1 = cputime;
    
    % Inicializa��o dos Par�metros das Propriedades
    [ Prop_Param ] = init_prop (); 
    
    % Defini��o da Propriedade 2D da an�lise
    [ Prop_Param ] = create_prop ( Prop_Param , t );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_prop : %2.2f s.\n', t2 );
   
end