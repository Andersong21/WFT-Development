%% Inicializa��o dos Par�metros das Propriedades do Problema

%% INPUT

%% OUTPUT
% Prop_Param         - Estrutura de Dados das Propriedades da An�lise

%% Declara��o da Fun��o de Inicializa��o dos Par�metros das Propriedades
function [ Prop_Param ] = init_prop ()
 
    % Inicializa��o da Estrutura das Propriedades da An�lise
    Prop_Param = struct;
    
end