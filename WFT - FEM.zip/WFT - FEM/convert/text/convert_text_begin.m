%% Retorno para convers�o do Texto para Formato ASCII no Come�o

%% INPUT
% text              - Texto a Ser Formatado

%% OUPTUT
% text_ASCII        - Formata��o do Texto no Formato ASCII no Come�o

%% Declara��o da Fun��o de Convers�o do Texto para Formato ASCII no Come�o
function [ text_ASCII ] = convert_text_begin ( text )
    
    % Formata��o do Texto -- < 8 char
    if ( length ( text ) < 8 )
    
        % Quantidade de Termos Nulos
        Tn = 8 - length ( text );        
        
        % Espa�amento em Branco
        for i = 1:Tn
            
            % Char em Branco
            Ws ( i ) = ' ';
        
        end

        % Atualiza��o do Formato Texto
        text_ASCII = [ text , Ws ];
        
    end
    
    % Formata��o do Texto -- = 8 char
    if  ( length ( text ) == 8 )
    
        % Atualiza��o do Formato Texto
        text_ASCII = text;    
        
    end
    
end