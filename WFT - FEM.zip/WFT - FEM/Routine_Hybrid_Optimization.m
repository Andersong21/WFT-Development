%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROTINA DO M�TODO H�BRIDO DE OTIMIZA��O %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Limpeza das Vari�veis
clear all;

% Fechar todas as janelas
close all;

% Limpeza das Entrada
clc;

% Inicializa��o do Timer
tic;

% Formatar Sa�da
format short;

% Defini��o do Multicore    
p = gcp('nocreate');

% Processadores n�o Dispon�veis
if isempty( p )

    % N�mero de Processadores
    multicore = 1;

else

    % N�mero de Processadores
    multicore = p.NumWorkers;

end

%% ESTRUTURA DO PROBLEMA

% Vari�veis
% x ( 1  ) - Vari�vel b1      - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1      - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2      - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2      - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L       - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf      - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t       - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d       - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r       - Raio do Centro da C�lula de Carga    - [ mm ]

% Qualidade de Malha
N        = input ('Entre com a qualidade de malha:');

% N�mero de Amostras
Ns       = 16;

% Fator de Correla��o
FS       = input ('Entre o fato de correla��o:');

%%%%%%%%%%%%%%%%%%%%%%%%%%
% OTIMIZA��O DO PROBLEMA %
%%%%%%%%%%%%%%%%%%%%%%%%%%

% Inicializa��o do Di�rio
diary ( strcat ( 'hybrid_optimization' , int2str ( N ) , '.out' ) );

% Lower Bound
LB       = [ 10 , 10 , 10 , 10 , 41 , 41 , 0.5 , 1.5 , 30 ];

% Upper Bound
UB       = [ 40 , 40 , 40 , 40 , 52 , 94 , 8.0 , 8.0 , 32 ];

% Escrita da Qualidade de Malha
fprintf( 'Mesh Quality %d :\n' , N );

%%%%%%%%%%%%%%%%%%%
% PONTOS INICIAIS %
%%%%%%%%%%%%%%%%%%%

% Pontos Iniciais de An�lise
[ xn , Ns ] = get_starting_point3 ( LB , UB , Ns );
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M�TODO ITERATIVO DE BUSCA DE M�NIMO GLOBAL %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

% Contador de Itera��es
counter     = 1;

% Inicializa��o das Vari�veis das Fun��es Objetivo do Problema -- Pattern
fval1_points = zeros ( 1 , Ns );

% Inicializa��o das Vari�veis das Fun��es Objetivo do Problema -- Interior
fval2_points = zeros ( 1 , Ns );

% Inicializa��o das Vari�veis das Fun��es Objetivo do Problema -- Final
fvalf_points = zeros ( 1 , Ns );

% Inicializa��o das Vari�veis dos Pontos Iniciais
x0_points   = zeros ( length ( LB ) , Ns );

% Inicializa��o das Vari�veis dos Pontos - Pattern Search
x1_points   = zeros ( length ( LB ) , Ns );

% Inicializa��o das Vari�veis dos Pontos - Interior Point
x2_points   = zeros ( length ( LB ) , Ns );

% Inicializa��o das Vari�veis dos Pontos Finais
xf_points   = zeros ( length ( LB ) , Ns );

% Valores �timo da Fun��o Objetivo
bestfval    = zeros ( 1 , 1 );

% Valores �timos dos Par�metros
bestx       = zeros ( length ( LB ) , 1 );
    
%%%%%%%%%%%%%%
% PONTOS DOE %
%%%%%%%%%%%%%%

% Varredura nos Pontos DOE
for i = 1:Ns
    
    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Di�rio
    diary ( strcat ( 'hybrid_optimization_' , int2str ( N ) , '_point_' , int2str ( i ) , '.out' ) );

    % Escrita do Ponto de Estudo
    fprintf( 'Point %d :\n' , i );
    
    % Ponto de Estudo
    x0 = xn ( i , 1:end );
    
    % Aloca��o da Vari�vel
    x0_points ( 1:end , i ) = x0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DA OTIMIZA��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Parametriza��o da Fun��o Objetivo
    ObjFunction  = @ ( x )objective_function ( x , N , FS , multicore );

    % Restri��es
    ConsFunction = @ ( x )restriction        ( x , N , FS , multicore );
    
    %%%%%%%%%%%%%%%%%%
    % PATTERN SEARCH %
    %%%%%%%%%%%%%%%%%%

    % Op��es do Solver -- PatternSearch
    options1 = psoptimset ( 'UseParallel' , true );
    options1 = psoptimset ( options1 , 'Display' , 'iter' );
    options1 = psoptimset ( options1 , 'PlotFcns' , { { @psplotbestf } , { @psplotfuncount } , { @psplotmeshsize } , { @psplotbestx } , { @psplotmaxconstr } } );
    options1 = psoptimset ( options1 , 'PollMethod' , 'GPSPositiveBasis2N' );
    options1 = psoptimset ( options1 , 'CompletePoll' , 'on' );
    options1 = psoptimset ( options1 , 'CompleteSearch' , 'on' );
    options1 = psoptimset ( options1 , 'MeshAccelerator' , 'on' );
    options1 = psoptimset ( options1 , 'Cache' , 'on' );

    % Estrutura��o do Problema do PatternSearch
    [ x1 , fval1 , exitflag1 , output1 ] = patternsearch ( ObjFunction , x0 , [] , [] , [] , [] , LB , UB , ConsFunction , options1 );
    
    %%%%%%%%%%%%%%%%%%%%
    % SEM CONVERG�NCIA %
    %%%%%%%%%%%%%%%%%%%%

    % Ponto Sem Converg�ncia -- PatternSearch
    if ( exitflag1 == -2 )

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ALOCA��O PONTO DO PATTERN SEARCH %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Aloca��o da Vari�vel
        x1_points ( 1:end , i ) = x0;
        
        % Aloca��o da Fun��o Objetivo
        fval1_points ( 1 , i ) = 0.0;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ALOCA��O PONTO DO INTERIOR POINT %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Aloca��o da Vari�vel
        x2_points ( 1:end , i ) = x0;
        
        % Aloca��o da Fun��o Objetivo
        fval2_points ( 1 , i ) = 0.0;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        % ALOCA��O PONTOS FINAIS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Aloca��o da Vari�vel
        xf_points ( 1:end , i ) = x0;
        
        % Aloca��o da Fun��o Objetivo
        fvalf_points ( 1 , i ) = 0.0;
        
        % Salvar as Vari�veis
        save ( strcat ( 'hybrid_optimization_' , int2str ( N ) , '_point_' , int2str ( i ) , '.mat' ) );

        % Determina��o do Tempo
        fprintf('\nTotal time - Point %d [ s ] : %g\n\n' , i , toc );

        % Finaliza��o do Di�rio
        diary off;

        % Continuar
        continue;

    end
    
    %%%%%%%%%%%%%%%%%%
    % INTERIOR POINT %
    %%%%%%%%%%%%%%%%%%

    % Op��es do Solver -- FminCon
    options2 = optimoptions ( 'fmincon' , 'Algorithm' , 'interior-point' );
    options2 = optimoptions ( options2  , 'UseParallel' , true );
    options2 = optimoptions ( options2  , 'Display' , 'iter-detailed' );
    options2 = optimoptions ( options2  , 'PlotFcns' , { { @optimplotx } , { @optimplotfunccount } , { @optimplotfval } , { @optimplotconstrviolation } , { @optimplotstepsize } , { @optimplotfirstorderopt } } );

    % Estrutura��o do Problema do Interior Point
    [ x2 , fval2 , exitflag2 , output2 ] = fmincon ( ObjFunction , x1 , [] , [] , [] , [] , LB - ones ( 1 , 9 ) , UB - ones ( 1 , 9 ) , ConsFunction , options2 );
    
    % Saida da Otimiza��o
    fprintf('\nInterior point - Mesh Quality %d - Point %d :' , N , i              );
    fprintf('\nThe number of iterations was : %d\n'           , output2.iterations );
    fprintf('\nThe number of function evaluations was : %d'   , output2.funcCount  );
    fprintf('\nThe best function value found was : %g\n'      , fval2              ); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O PONTO DO PATTERN SEARCH %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Aloca��o da Vari�vel
    x1_points ( 1:end , i ) = x1;

    % Aloca��o da Fun��o Objetivo
    fval1_points ( 1 , i ) = fval1;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O PONTO DO INTERIOR POINT %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Aloca��o da Vari�vel
    x2_points ( 1:end , i ) = x2;

    % Aloca��o da Fun��o Objetivo
    fval2_points ( 1 , i ) = fval2;

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O PONTOS FINAIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Interior Point >= Pattern Search
    if ( abs ( fval2 ) >= abs ( fval1 ) )
        
        % Aloca��o da Vari�vel
        xf_points ( 1:end , i ) = x2;

        % Aloca��o da Fun��o Objetivo
        fvalf_points ( 1 , i ) = fval2;
        
    % Patterh Search > Interior Point
    else
        
        % Aloca��o da Vari�vel
        xf_points ( 1:end , i ) = x1;

        % Aloca��o da Fun��o Objetivo
        fvalf_points ( 1 , i ) = fval1;
        
    end

    % Salvar as Vari�veis
    save ( strcat ( 'hybrid_optimization_' , int2str ( N ) , '_point_' , int2str ( i ) , '.mat' ) );

    % Determina��o do Tempo
    fprintf('\nTotal time - Point %d [ s ] : %g\n\n' , i , toc );
    
    % Finaliza��o do Di�rio
    diary off;
        
end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ALOCA��O DO M�NIMO GLOBAL %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Aloca��o da Menor Fun��o Objetivo
bestfval ( 1 , 1 ) = min ( fvalf_points );

% Defini��o do Ponto Encontrado
ID = find ( fvalf_points == min ( fvalf_points ) , 1 );

% Guardar Ponto de �timo do Problema
bestx    ( 1 , 1:end ) = xf ( ID , 1:end );

% Salvar as Vari�veis
save ( strcat ( 'hybrid_optimization_' , int2str ( N ) , '.mat' ) );

% Determina��o do Tempo
fprintf('\nTotal time [ s ] : %g\n\n' , toc );

% Finaliza��o da An�lise
display ( '\nEnd' );
display ( 'Analysis Succesfully' );
