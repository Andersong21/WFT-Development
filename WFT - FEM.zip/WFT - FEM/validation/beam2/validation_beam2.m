%% Cria��o do Elemento Beam2 de Valida��o

%% INPUT
% Prop_Param        - Estrutura de Dados das Propriedades do Problema

%% OUTPUT
% Node_Param        - Estrutura de Dados dos N�s do Elemento 1D
% Elem_Param        - Estrutura de Dados dos Elementos do Elemento 1D
% Prop_Param        - Estrutura de Dados das Propriedades do Elemento 1D
% T                 - Matriz de Aplica��o do Multi Point Constraint

%% Declara��o da Fun��o de Cria��o do Elemento Beam2 de Valida��o
function [ Node_Param , Elem_Param , Prop_Param , T ] = validation_beam2 ( Prop_Param )

    %%%%%%%%
    % N� 1 %
    %%%%%%%%
    
    % Id do N� 1
    Node_Param ( 1 ).id = 1;
    
    % Coordenadas do N� 1
    Node_Param ( 1 ).coord ( 1 ) = 0.0;
    Node_Param ( 1 ).coord ( 2 ) = 0.0;
    Node_Param ( 1 ).coord ( 3 ) = 0.0;
    
    % N� de Borda
    Node_Param ( 1 ).border = 'Y';
    
    % Cria��o dos Graus de Liberdade do N�
    for i = 1:6
    
        % Grau de Liberdade do N�
        Node_Param ( 1 ).dof ( i ) = 0;    
        
    end
    
    %%%%%%%%
    % N� 2 %
    %%%%%%%%
    
    % Id do N� 2
    Node_Param ( 2 ).id = 2;
    
    % Coordenadas do N� 1
    Node_Param ( 2 ).coord ( 1 ) = 1.0;
    Node_Param ( 2 ).coord ( 2 ) = 0.0;
    Node_Param ( 2 ).coord ( 3 ) = 0.0;
    
    % N� de Borda
    Node_Param ( 2 ).border = 'N';
    
    % Cria��o dos Graus de Liberdade do N�
    for i = 1:6
    
        % Grau de Liberdade do N�
        Node_Param ( 2 ).dof ( i ) = i;    
        
    end
    
    %%%%%%%%%%%%%%%
    % PROPRIEDADE %
    %%%%%%%%%%%%%%%
    
    % Id da Propriedade
    Prop_Param ( 2 ).id = 2;
    
    % Tipo da Propriedade
    Prop_Param ( 2 ).type = '1d';
    
    % Base do N� 1 na Propriedade
    Prop_Param ( 2 ).b ( 1 ) = 1;
    
    % Base do N� 2 na Propriedade
    Prop_Param ( 2 ).b ( 2 ) = 1;
    
    % Altura do N� 1 na Propriedade
    Prop_Param ( 2 ).h ( 1 ) = 1;
    
    % Altura do N� 2 na Propriedade
    Prop_Param ( 2 ).h ( 2 ) = 1;
    
    % Defini��o da �rea
    Prop_Param ( 2 ).Area ( 1 ) = Prop_Param ( 2 ).b ( 1 ) * Prop_Param ( 2 ).h ( 1 );
    Prop_Param ( 2 ).Area ( 2 ) = Prop_Param ( 2 ).b ( 2 ) * Prop_Param ( 2 ).h ( 2 );

    % Defini��o do Momento de In�rcia Iyy
    Prop_Param ( 2 ).Iyy ( 1 ) = ( Prop_Param ( 2 ).b ( 1 ) * Prop_Param ( 2 ).h ( 1 )^3 ) / 12;
    Prop_Param ( 2 ).Iyy ( 2 ) = ( Prop_Param ( 2 ).b ( 2 ) * Prop_Param ( 2 ).h ( 2 )^3 ) / 12;

    % Defini��o do Momento de In�rcia Izz
    Prop_Param ( 2 ).Izz ( 1 ) = ( ( Prop_Param ( 2 ).b ( 1 )^3 ) * Prop_Param ( 2 ).h ( 1 ) ) / 12;
    Prop_Param ( 2 ).Izz ( 2 ) = ( ( Prop_Param ( 2 ).b ( 2 )^3 ) * Prop_Param ( 2 ).h ( 2 ) ) / 12;

    % Defini��o do Momento Polar de In�rcia
    Prop_Param ( 2 ).J ( 1 )   = Prop_Param ( 2 ).Izz ( 1 ) + Prop_Param ( 2 ).Iyy ( 1 );
    Prop_Param ( 2 ).J ( 2 )   = Prop_Param ( 2 ).Izz ( 2 ) + Prop_Param ( 2 ).Iyy ( 2 );
    
    %%%%%%%%%%%%
    % ELEMENTO %
    %%%%%%%%%%%%
    
    % Id do Elemento
    Elem_Param ( 1 ).id = 1;
    
    % Id da Propriedade
    Elem_Param ( 1 ).prop_id = 2;
    
    % Tipo do Elemento
    Elem_Param ( 1 ).type = '1d';
    
    % Parte do Elemento
    Elem_Param ( 1 ).part = '0';
    
    % Estrutura do Elemento
    Elem_Param ( 1 ).estr = '0';
    
    % Id dos N�s
    Elem_Param ( 1 ).node ( 1 ) = 1;
    Elem_Param ( 1 ).node ( 2 ) = 2;   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Aplica��o do MPC ao Problema %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador
    cont = 1;
       
    % Varredura dos N�s
    for i = 1:2
        
        % Verifica��o se o N� est� Relacionado a uma Boundary Condition
        if ( strcmp ( Node_Param ( i ).border , 'Y' ) == 1 )

            % Continuar
            continue;

        else              

             % Varredura nos Graus de Liberdade
            for j = 1:6

                % Grau de Liberdade do N� Dependente
                Ti ( cont ) = Node_Param ( i ).dof ( j );
                Tj ( cont ) = Node_Param ( i ).dof ( j );
                Tv ( cont ) = 1;
                
                % Atualiza��o do Contador
                cont = cont + 1;

            end

        end     
    
    end
    
    % Cria��o da Matriz de Mpc T
    T = sparse ( Ti , Tj , Tv );
        
end

