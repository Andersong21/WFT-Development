%% Cria��o do Elemento Quad4 de Valida��o

%% INPUT
% Prop_Param        - Estrutura de Dados das Propriedades do Problema

%% OUTPUT
% Node_Param        - Estrutura de Dados dos N�s do Elemento 2D
% Elem_Param        - Estrutura de Dados dos Elementos do Elemento 2D
% Prop_Param        - Estrutura de Dados das Propriedades do Elemento 2D
% T                 - Matriz de Aplica��o do Multi Point Constraint

%% Declara��o da Fun��o de Cria��o do Elemento Quad4 de Valida��o
function [ Node_Param , Elem_Param , Prop_Param , T ] = validation_quad4 ( Prop_Param )

    %%%%%%%%
    % N� 1 %
    %%%%%%%%
    
    % Id do N� 1
    Node_Param ( 1 ).id = 1;
    
    % Coordenadas do N� 1
    Node_Param ( 1 ).coord ( 1 ) = + 0.0;
    Node_Param ( 1 ).coord ( 2 ) = + 0.0;
    Node_Param ( 1 ).coord ( 3 ) = + 0.0;
    
    % N� de Borda
    Node_Param ( 1 ).border = 'Y';
    
    % Cria��o dos Graus de Liberdade do N�
    for i = 1:6
    
        % Grau de Liberdade do N�
        Node_Param ( 1 ).dof ( i ) = 0;    
        
    end
    
    %%%%%%%%
    % N� 2 %
    %%%%%%%%
    
    % Id do N� 2
    Node_Param ( 2 ).id = 2;
    
    % Coordenadas do N� 1
    Node_Param ( 2 ).coord ( 1 ) = + 1.0;
    Node_Param ( 2 ).coord ( 2 ) = + 0.0;
    Node_Param ( 2 ).coord ( 3 ) = + 0.0;
    
    % N� de Borda
    Node_Param ( 2 ).border = 'N';
    
    % Cria��o dos Graus de Liberdade do N�
    for i = 1:6
    
        % Grau de Liberdade do N�
        Node_Param ( 2 ).dof ( i ) = i;    
        
    end
    
    %%%%%%%%
    % N� 3 %
    %%%%%%%%
    
    % Id do N� 3
    Node_Param ( 3 ).id = 3;
    
    % Coordenadas do N� 1
    Node_Param ( 3 ).coord ( 1 ) = + 1.0;
    Node_Param ( 3 ).coord ( 2 ) = + 1.0;
    Node_Param ( 3 ).coord ( 3 ) = + 0.0;
    
    % N� de Borda
    Node_Param ( 3 ).border = 'N';
    
    % Cria��o dos Graus de Liberdade do N�
    for i = 1:6
    
        % Grau de Liberdade do N�
        Node_Param ( 3 ).dof ( i ) = i + 6;    
        
    end
    
    %%%%%%%%
    % N� 4 %
    %%%%%%%%
    
    % Id do N� 4
    Node_Param ( 4 ).id = 4;
    
    % Coordenadas do N� 1
    Node_Param ( 4 ).coord ( 1 ) = + 0.0;
    Node_Param ( 4 ).coord ( 2 ) = + 1.0;
    Node_Param ( 4 ).coord ( 3 ) = + 0.0;
    
    % N� de Borda
    Node_Param ( 4 ).border = 'Y';
    
    % Cria��o dos Graus de Liberdade do N�
    for i = 1:6
    
        % Grau de Liberdade do N�
        Node_Param ( 4 ).dof ( i ) = 0;    
        
    end
    
    %%%%%%%%%%%%%%%
    % PROPRIEDADE %
    %%%%%%%%%%%%%%%
    
    % Id da Propriedade
    Prop_Param ( 2 ).id = 2;
    
    % Tipo da Propriedade
    Prop_Param ( 2 ).type = '2d';
    
    % Espessura da Propriedade
    Prop_Param ( 2 ).thick = 1;
    
    %%%%%%%%%%%%
    % ELEMENTO %
    %%%%%%%%%%%%
    
    % Id do Elemento
    Elem_Param ( 1 ).id = 1;
    
    % Id da Propriedade
    Elem_Param ( 1 ).prop_id = 2;
    
    % Tipo do Elemento
    Elem_Param ( 1 ).type = '2d';
    
    % Parte do Elemento
    Elem_Param ( 1 ).part = '0';
    
    % Estrutura do Elemento
    Elem_Param ( 1 ).estr = '0';
    
    % Id dos N�s
    Elem_Param ( 1 ).node ( 1 ) = 1;
    Elem_Param ( 1 ).node ( 2 ) = 2;   
    Elem_Param ( 1 ).node ( 3 ) = 3;
    Elem_Param ( 1 ).node ( 4 ) = 4;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Aplica��o do MPC ao Problema %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador
    cont = 1;
       
    % Varredura dos N�s
    for i = 1:4
        
        % Verifica��o se o N� est� Relacionado a uma Boundary Condition
        if ( strcmp ( Node_Param ( i ).border , 'Y' ) == 1 )

            % Continuar
            continue;

        else              

             % Varredura nos Graus de Liberdade
            for j = 1:6

                % Grau de Liberdade do N� Dependente
                Ti ( cont ) = Node_Param ( i ).dof ( j );
                Tj ( cont ) = Node_Param ( i ).dof ( j );
                Tv ( cont ) = 1;
                
                % Atualiza��o do Contador
                cont = cont + 1;

            end

        end     
    
    end
    
    % Cria��o da Matriz de Mpc T
    T = sparse ( Ti , Tj , Tv );
        
end

