%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROTINA DE ESCRITA DOS RESULTADOS 5 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fechar todas as janelas
close all;

% Limpeza das Entrada
clc;

% Inicializa��o do Timer
tic;

% Formatar Sa�da
format short;

% Defini��o do Multicore    
p = gcp('nocreate');

% Processadores n�o Dispon�veis
if isempty( p )

    % N�mero de Processadores
    multicore = 1;

else

    % N�mero de Processadores
    multicore = p.NumWorkers;

end

%% ESTRUTURA DO PROBLEMA

% Vari�veis
% x ( 1  ) - Vari�vel b1      - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1      - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2      - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2      - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L       - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf      - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t       - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d       - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r       - Raio do Centro da C�lula de Carga    - [ mm ]

% Experimento de Estudo
Ps        = input ('Entre o Experimento de estudo:');

% Erro Admiss�vel
max_error = input ('Entre o m�ximo erro admiss�vel:');

% Quantidade de Itera��es
Nmax      = input ('Entre o n�mero m�ximo de itera��es:');

%%%%%%%%%%%%%%%%%
% INICIALIZA��O %
%%%%%%%%%%%%%%%%%

% Lower Bound
LB       = [ 10 , 10 , 10 , 10 , 41 , 41 , 0.5 , 1.5 , 30 ];

% Upper Bound
UB       = [ 40 , 40 , 40 , 40 , 52 , 94 , 8.0 , 8.0 , 32 ];

% Inicializa��o do Timer
tic;

% Fator de Correla��o
Fc = 1.5;

%%%%%%%%%%%%%%%%%
% INICIALIZA��O %
%%%%%%%%%%%%%%%%%

% Inicializa��o do Di�rio
diary ( strcat ( 'Final_' , int2str ( Ps ) , '.out' ) );    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CRIT�RIO DE CONVERG�NCIA %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

% Erro Inicial
error = 1.0;

% Deslocamento da Itera��o
Dnew = 0;

% Deslocamento da Itera��o Anterior
Dold = 0;

% Tens�o da Itera��o
Snew = 0;

% Tens�o da Itera��o Anterior
Sold = 0;

% Aloca��o do Vetor de M�ximos Deslocamentos
maxD   = zeros ( Nmax , 1 );

% Aloca��o do Vetor de M�ximas Tens�es
maxS   = zeros ( Nmax , 1 );

% Aloca��o do Vetor das Frequ�ncias Naturais
maxF = zeros  ( Nmax , 1 );

% Aloca��o do Vetor da Sensibilidade 1
maxS1  = zeros ( Nmax , 1 );

% Aloca��o do Vetor da Sensibilidade 2
maxS2  = zeros ( Nmax , 1 );

% Aloca��o do Vetor da Sensibilidade 3
maxS3  = zeros ( Nmax , 1 );

% Aloca��o do Vetor da Sensibilidade 4
maxS4  = zeros ( Nmax , 1 );

% Aloca��o do Vetor da Sensibilidade 5
maxS5  = zeros ( Nmax , 1 );

% Aloca��o do Vetor da Sensibilidade 6
maxS6  = zeros ( Nmax , 1 );

% Aloca��o do Vetor de Graus de Liberdade
dofs   = zeros ( Nmax , 1 );

% Aloca��o do Vetor de Erros
errors = zeros ( Nmax , 1 );

% Inicialia��o do Par�metro de Malha
N = 1;

% Crit�rio de Converg�ncia
while ( N <= Nmax )

    % Escrita da Qualidade de Malha
    fprintf( 'Mesh Quality %d :\n' , N );

    % Modelo Num�rico do Transdutor
    [ f1 , Mat_Param , Prop_Param , Node_Param , Elem_Param , Mpc_Param , t2 ] = numerical_model( x2 , N , Fc , multicore );

    % M�ximo Deslocamento
    maxD ( N , 1 ) = max ( arrayfun ( @(struct)max(struct(:).max_disp   ) , Node_Param ) );

    % M�xima Tens�o
    maxS  ( N , 1 ) = max ( arrayfun ( @(struct)max(struct(:).max_stress ) , Elem_Param ) );
    
    % M�nima Frequ�ncia
    maxF  ( N , 1 ) = Node_Param ( 1 ).EVA;
    
    % Sensibilidade no Canal 1
    maxS1 ( N , 1 ) = f1 ( 2 );
    
    % Sensibilidade no Canal 2
    maxS2 ( N , 1 ) = f1 ( 3 );
    
    % Sensibilidade no Canal 3
    maxS3 ( N , 1 ) = f1 ( 4 );
    
    % Sensibilidade no Canal 4
    maxS4 ( N , 1 ) = f1 ( 5 );
    
    % Sensibilidade no Canal 5
    maxS5 ( N , 1 ) = f1 ( 6 );
    
    % Sensibilidade no Canal 6
    maxS6 ( N , 1 ) = f1 ( 7 );

    % Quantidade de Graus de Liberdade
    dofs  ( N , 1 ) = max ( arrayfun ( @(struct)max(struct(:).dof ( : ) ) , Node_Param ) );

    % Experimento Inicial
    if ( N == 1 )

        % Incremento na Qualidade de Malha
        N = N + 1;

        % Continuar
        continue;

    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONVERG�NCIA - DESLOCAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Deslocamento da Itera��o
    Dnew = maxD ( N , 1 );

    % Deslocamento da Itera��o Anterior
    Dold = maxD ( N - 1 , 1 );

    % Converg�ncia - Deslocamento
    error1 = abs ( ( Dnew - Dold ) / Dnew );

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % CONVERG�NCIA - TENS�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%

    % Tens�o da Itera��o
    Snew = maxS ( N , 1 );

    % Tens�o da Itera��o Anterior
    Sold = maxS ( N - 1 , 1 );

    % Converg�ncia - Tens�o
    error2 = abs ( ( Snew - Sold ) / Snew );

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % CONVERG�NCIA - M�TODO %
    %%%%%%%%%%%%%%%%%%%%%%%%%

    % Converg�ncia do M�todo
    error = max ( error1 , error2 );

    % Aloca��o do Erro
    errors ( N , 1 ) = error;        

    % Escrita do Erro do Deslocamento
    fprintf('Error1  : %2.2f\n' , error1 * 100 );

    % Escrita do Erro da Tens�o
    fprintf('Error2  : %2.2f\n' , error2 * 100 );

    % Escrita do Erro do M�todo
    fprintf('Error   : %2.2f\n' , error * 100  );

    % Incremento na Qualidade de Malha
    N = N + 1;

end

% Atualiza��o da Vari�vel de Qualidade de Malha
N = N - 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VISUALIZA��O RESULTADOS %
%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot de Resultado -- Deslocamento
figure
hold on;
grid on;
plot   ( dofs ( 3:N , 1 ) , maxD ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'blue' , 'MarkerEdgeColor' , 'blue' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Deslocamento [ mm ]', 'FontSize' , 12 );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Figura
savefig ( strcat ( 'Final_' , int2str ( Ps ) , '_disp' , '.fig' ) );

% Plot de Resultado -- Tens�o
figure
hold on;
grid on;
plot   ( dofs ( 3:N , 1 ) , maxS ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'red' , 'MarkerEdgeColor' , 'red' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Tens�o von Mises [ MPa ]', 'FontSize' , 12 );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Figura
savefig ( strcat ( 'Final_' , int2str ( Ps ) , '_stress' , '.fig' ) );

% Plot de Resultado -- Frequencia
figure
hold on;
grid on;
plot   ( dofs ( 3:N , 1 ) , maxF ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'red' , 'MarkerEdgeColor' , 'red' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Frequ�ncia [ Hz ]', 'FontSize' , 12 );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Figura
savefig ( strcat ( 'Final_' , int2str ( Ps ) , '_freq' , '.fig' ) );

% Plot de Resultado -- Erro
figure
hold on;
grid on;
plot   ( dofs ( 3:N , 1 ) , 100 * errors ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'black' , 'MarkerEdgeColor' , 'black' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Erro [ % ]', 'FontSize' , 12 );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Figura
savefig ( strcat ( 'Final_' , int2str ( Ps ) , '_error' , '.fig' ) );

% Plot de Resultado -- Sensibilidade 1
figure
hold on;
grid on;
subplot ( 3 , 2 , 1 );
plot   ( dofs ( 3:N , 1 ) , maxS1 ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'green' , 'MarkerEdgeColor' , 'green' );
plot   ( dofs , maxS1 , 'p' , 'LineWidth' , 2 );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Canal 1 [ mV / V ] ' );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Plot de Resultado -- Sensibilidade 2
hold on;
grid on;
subplot ( 3 , 2 , 2 );
plot   ( dofs ( 3:N , 1 ) , maxS2 ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'green' , 'MarkerEdgeColor' , 'green' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Canal 2 [ mV / V ] ' );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Plot de Resultado -- Sensibilidade 3
hold on;
grid on;
subplot ( 3 , 2 , 3 );
plot   ( dofs ( 3:N , 1 ) , maxS3 ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'green' , 'MarkerEdgeColor' , 'green' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Canal 3 [ mV / V ] ' );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Plot de Resultado -- Sensibilidade 4
hold on;
grid on;
subplot ( 3 , 2 , 4 );
plot   ( dofs ( 3:N , 1 ) , maxS4 ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'green' , 'MarkerEdgeColor' , 'green' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Canal 4 [ mV / V ] ' );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Plot de Resultado -- Sensibilidade 5
hold on;
grid on;
subplot ( 3 , 2 , 5 );
plot   ( dofs ( 3:N , 1 ) , maxS5 ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'green' , 'MarkerEdgeColor' , 'green' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Canal 5 [ mV / V ] ' );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );

% Plot de Resultado -- Sensibilidade 6
hold on;
grid on;
subplot ( 3 , 2 , 6 );
plot   ( dofs ( 3:N , 1 ) , maxS6 ( 3:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'green' , 'MarkerEdgeColor' , 'green' );
xlabel ( 'Graus de Liberdade'    , 'FontSize' , 12 );
ylabel ( 'Canal 6 [ mV / V ] ' );
title  ( strcat ( 'An�lise de converg�ncia - Experimento  ' , int2str ( Ps ) ) , 'FontSize' , 12 );
set    ( gca , 'FontSize' , 12 );
hold on;
grid on;

% Figura
savefig ( strcat ( 'Final_' , int2str ( Ps ) , '_Ss' , '.fig' ) );

% Salvar as Vari�veis
save ( strcat ( 'Final_' , int2str ( Ps ) , '.mat' ) );
        
% Determina��o do Tempo
fprintf('\nTotal time [ s ] : %g\n\n' , toc );

% Finaliza��o da An�lise
display ( '\nEnd' );
display ( 'Analysis Succesfully' );

% Finaliza��o do Di�rio
diary off;