%% Retorno do Gerador da Matriz de Massa do Problema

%% INPUT
% Node_Param   - Estrutura de Dados dos N�s do Problema
% Elem_Param   - Estrutura de Dados dos Elementos do Problema
% Mat_Param    - Estrutura de Dados do Material do Problema
% Prop_Param   - Estrutura de Dados das Propriedades do Problema
% T            - Matriz de Aplica��o do Multi Point Constraint
% multicore    - Quantidade de N�cleos

%% OUPTUT
% M            - Matriz de Massa do Problema

%% Declara��o da Fun��o de Retorno do Gerador da Matriz de Massa do Problema
function [ M ] = get_matrix_M ( Node_Param , Elem_Param , Mat_Param , Prop_Param, T , multicore )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Cria��o da Matriz de Massa do Problema
    [ M ] = create_matrix_M ( Node_Param , Elem_Param , Mat_Param , Prop_Param , T , multicore );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_matrix_M : %2.2f s.\n', t2 );    
    
end