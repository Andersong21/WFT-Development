%% Cria��o das Matrizes de Massa do Elemento -- Multicore

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% List_Elem         - Lista dos Ids dos Elementos do N�cleo

%% OUTPUT
% Mif               - Termo i da Matriz de Massa Global
% Mjf               - Termo j da Matriz de Massa Global
% Mvf               - Valor ( i , j ) da Matriz de Rigidez Global

%% Declara��o da Fun��o de Cria��o das Matrizes de Massa do Elemento
function [ Mif , Mjf , Mvf ] = create_matrix_M_multicore ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VARREDURA NA LISTA DE ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Quantidade de Elementos
    Nelem = length ( List_elem );
    
    % Inicializa��o das C�lulas para Aloca��o dos Termos i da Massa
    Mig = cell ( [ 1 , Nelem ] );
    
    % Inicializa��o das C�lulas para Aloca��o dos Termos j da Massa
    Mjg = cell ( [ 1 , Nelem ] );
    
    % Inicializa��o das C�lulas para Aloca��o dos Valores da Massa
    Mvg = cell ( [ 1 , Nelem ] );

    % Varredura na Lista de Elementos
    parfor i = 1:length ( List_elem )
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DA MATRIZ DE MASSA 1D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Matriz de Massa 1D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '1d' ) == 1 )
        
            % Montagem da Matriz de Massa - Beam2
            [ Mi , Mj , Mv ] = matrix_M_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem ( i ) );
            
            % Aloca��o dos Vetores do Triplet
            Mig { i } = Mi;
            Mjg { i } = Mj;
            Mvg { i } = Mv;
            
            % Continuar
            continue;     
        
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DA MATRIZ DE MASSA 2D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Matriz de Massa 2D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '2d' ) == 1 )
        
            % Montagem da Matriz de Massa - Quad4
            [ Mi , Mj , Mv ] = matrix_M_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem ( i ) );
            
            % Aloca��o dos Vetores do Triplet
            Mig { i } = Mi;
            Mjg { i } = Mj;
            Mvg { i } = Mv;
            
            % Continuar
            continue;       
        
        end 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DA MATRIZ DE MASSA CONCENTRADA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Matriz de Massa 0D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '0d' ) == 1 )
            
            % Montagem da Matriz de Massa - Point0
            [ Mi , Mj , Mv ] = matrix_M_point0 ( Node_Param , Elem_Param , List_elem ( i ) );
            
            % Aloca��o dos Vetores do Triplet
            Mig { i } = Mi;
            Mjg { i } = Mj;
            Mvg { i } = Mv;
            
            % Continuar
            continue;
            
        end       
        
    end 
    
    % Aloca��o dos Termos i no Vetor de Sa�da
    Mia = cell2mat( Mig );
    Mif = horzcat ( Mia ( : ) );

    % Aloca��o dos Termos j no Vetor de Sa�da
    Mja = cell2mat( Mjg );
    Mjf = horzcat ( Mja ( : ) );
    
    % Aloca��o dos Valores no Vetor de Sa�da
    Mva = cell2mat( Mvg );
    Mvf = horzcat ( Mva ( : ) );

end

