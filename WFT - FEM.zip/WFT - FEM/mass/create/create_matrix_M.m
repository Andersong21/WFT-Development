%% Cria��o das Matrizes de Massa do Elemento

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% Mpc_Param         - Estrutura de Dados dos Multi Point Constraint do Problema
% multicore         - Quantidade de N�cleos

%% OUTPUT
% M                 - Matriz de Massa do Elemento Preenchido

%% Declara��o da Fun��o de Cria��o das Matrizes de Massa do Elemento
function [ M ] = create_matrix_M ( Node_Param , Elem_Param , Mat_Param , Prop_Param, Mpc_Param , multicore )

    %%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA %
    %%%%%%%%%%%%%%%%%%%
    
    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id;
    
    % Quantidade de Elementos por N�cleo
    delem = fix ( Nelem / multicore );
    
    % Redimensionamento do tamanho dos n�cleos
    if ( delem == 0 )
        
        % Par�metro de Quantidade de N�cleos
        multicore = 1;
        
    end
    
    % Inicializa��o dos Vetores
    Mig = [];
    Mjg = [];
    Mvg = [];
    
    % Varredura na Lista de N�cleos
    parfor i = 1:multicore
        
        %%%%%%%%%%%%%%
        % DEFINI��ES %
        %%%%%%%%%%%%%%
        
        % Primeiros N�cleos 
        if ( i ~= multicore )
        
            % In�cio dos Elementos
            begin_elem = 1 + ( ( i - 1 ) * delem );

            % Final dos Elementos
            end_elem = i * delem;

        % Demais N�cleos
        else
            
            % In�cio dos Elementos
            begin_elem = 1 + ( ( i - 1 ) * delem );

            % Final dos Elementos
            end_elem = Nelem;
            
        end 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DA MATRIZ DE MASSA % MULTICORE %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Cria��o da Matriz de Massa em cada N�cleo
        [ Mi , Mj , Mv ] = create_matrix_M_multicore ( Node_Param , Elem_Param , Mat_Param , Prop_Param , begin_elem:1:end_elem );
        
        % Aloca��o na Linha da Matriz de Termos
        Mig = horzcat ( Mig , Mi' );
        Mjg = horzcat ( Mjg , Mj' );
        Mvg = horzcat ( Mvg , Mv' );
        
    end 
    
    %%%%%%%%%%%%%%
    % RESTRI��ES %
    %%%%%%%%%%%%%%
    
    % Quantidade de Graus de Liberdade
    Ndof = max ( arrayfun ( @(struct)max(struct(:).dof ( : ) ) , Node_Param ) );   

    % Quantidade de N�s Dependentes
    Ndep = max ( arrayfun ( @(struct)max(struct(:).node_dep ) , Node_Param ) );
    
    % Quantidade de N�s
    Nnode = Node_Param ( end ).id;
    
    % Inicializa��o dos Vetores
    Tig = zeros ( 36 * Ndep , 1 );
    Tjg = zeros ( 36 * Ndep , 1 );
    Tvg = zeros ( 36 * Ndep , 1 );
    
    % Posi��o no Final da Matriz de Rigidez
    cont = Ndof + 1;
    
    % Contagem de Linhas
    cont_L = 1;    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Cria��o dos DOFs do Problema %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos N�s
    for i = 1:Nnode
        
        % Verifica��o se o n� � Dependente
        if ( strcmp ( Node_Param ( i ).mpc_type , 'DEP' ) == 1 )
        
            % Id do Mpc
            mpc_id = Node_Param ( i ).mpc_id;

            % N� Independente do Mpc
            ind_node_id = Mpc_Param ( mpc_id ).node_ind ( 1 );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % COORDENADAS N� INDEPENDENTE %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada X do N� Independente
            Xi = Node_Param ( ind_node_id ).coord ( 1 );

            % Coordenada Y do N� Independente
            Yi = Node_Param ( ind_node_id ).coord ( 2 );

            % Coordenada Z do N� Independente
            Zi = Node_Param ( ind_node_id ).coord ( 3 );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % COORDENADAS N� DEPENDENTE %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada X do N� Independente
            Xd = Node_Param ( i ).coord ( 1 );

            % Coordenada Y do N� Independente
            Yd = Node_Param ( i ).coord ( 2 );

            % Coordenada Z do N� Independente
            Zd = Node_Param ( i ).coord ( 3 );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % GRAUS DE LIBERDADE DE TRANSLA��O %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Varredura nos Graus de Liberdade de Transla��o
            for j = 1:3

                % Grau de Liberdade do N� Dependente
                T1 = Node_Param ( i ).dof ( j );

                % Grau de Liberdade do N� Independente
                T2 = Node_Param ( ind_node_id ).dof ( j );

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % RELA��O DOS GRAUS DE LIBERDADE EM RELA��O A X %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                % Grau de Liberdade de Transla��o X
                if ( j == 1 )

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % DEFINI��O DAS RESTRI��ES NA MATRIZ T %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Grau de Liberdade de Rota��o 5 do N� Independente
                    T3 = Node_Param ( ind_node_id ).dof ( 5 );

                    % Grau de Liberdade de Rota��o 6 do N� Independente
                    T4 = Node_Param ( ind_node_id ).dof ( 6 );

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ALOCA��O DAS RESTRI��ES NA MATRIZ T %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 1
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T1;
                    Tvg ( cont_L ) = 0;

                   % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 2
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T2;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 3
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T3;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 4
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T4;
                    Tvg ( cont_L ) = 0; 

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 5
                    Tig ( cont_L ) = T1;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 6
                    Tig ( cont_L ) = T2;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 7
                    Tig ( cont_L ) = T3;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 8
                    Tig ( cont_L ) = T4;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                end

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % RELA��O DOS GRAUS DE LIBERDADE EM RELA��O A Y %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                % Grau de Liberdade de Transla��o Y
                if ( j == 2 )

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % DEFINI��O DAS RESTRI��ES NA MATRIZ T %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Grau de Liberdade de Rota��o 4 do N� Independente
                    T3 = Node_Param ( ind_node_id ).dof ( 4 );

                    % Grau de Liberdade de Rota��o 6 do N� Independente
                    T4 = Node_Param ( ind_node_id ).dof ( 6 );

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ALOCA��O DAS RESTRI��ES NA MATRIZ T %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 1
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T1;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 2
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T2;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 3
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T3;
                    Tvg ( cont_L ) = 0;
                    
                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 4
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T4;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 5
                    Tig ( cont_L ) = T1;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 6
                    Tig ( cont_L ) = T2;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 7
                    Tig ( cont_L ) = T3;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 8
                    Tig ( cont_L ) = T4;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0; 

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                end

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % RELA��O DOS GRAUS DE LIBERDADE EM RELA��O A Z %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                % Grau de Liberdade de Transla��o Z
                if ( j == 3 )

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % DEFINI��O DAS RESTRI��ES NA MATRIZ T %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Grau de Liberdade de Rota��o 4 do N� Independente
                    T3 = Node_Param ( ind_node_id ).dof ( 4 );

                    % Grau de Liberdade de Rota��o 5 do N� Independente
                    T4 = Node_Param ( ind_node_id ).dof ( 5 );

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ALOCA��O DAS RESTRI��ES NA MATRIZ T %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 1
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T1;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 2
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T2;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 3
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T3;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 4
                    Tig ( cont_L ) = cont;
                    Tjg ( cont_L ) = T4;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 5
                    Tig ( cont_L ) = T1;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 6
                    Tig ( cont_L ) = T2;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 7
                    Tig ( cont_L ) = T3;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                    % Aloca��o do Termo na Lista de Valores da Matrix -- 8
                    Tig ( cont_L ) = T4;
                    Tjg ( cont_L ) = cont;
                    Tvg ( cont_L ) = 0;

                    % Atualiza�ao da Contagem de Linhas
                   cont_L = cont_L + 1;

                end              

                % Atualiza��o do Contador
                cont = cont + 1;

            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % GRAUS DE LIBERDADE DE ROTA��O %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Varredura nos Graus de Liberdade de Rota��o
            for j = 4:6

                % Grau de Liberdade do N� Dependente
                T1 = Node_Param ( i ).dof ( j );

                % Grau de Liberdade do N� Independente
                T2 = Node_Param ( ind_node_id ).dof ( j );

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ALOCA��O DAS RESTRI��ES NA MATRIZ T %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                % Aloca��o do Termo na Lista de Valores da Matrix -- 1
                Tig ( cont_L ) = cont;
                Tjg ( cont_L ) = T1;
                Tvg ( cont_L ) = 0;

                % Atualiza�ao da Contagem de Linhas
               cont_L = cont_L + 1;

                % Aloca��o do Termo na Lista de Valores da Matrix -- 2
                Tig ( cont_L ) = cont;
                Tjg ( cont_L ) = T2;
                Tvg ( cont_L ) = 0;

                % Atualiza�ao da Contagem de Linhas
               cont_L = cont_L + 1;

                % Aloca��o do Termo na Lista de Valores da Matrix -- 3
                Tig ( cont_L ) = T1;
                Tjg ( cont_L ) = cont;
                Tvg ( cont_L ) = 0;

                % Atualiza�ao da Contagem de Linhas
               cont_L = cont_L + 1;

                % Aloca��o do Termo na Lista de Valores da Matrix -- 4
                Tig ( cont_L ) = T2;
                Tjg ( cont_L ) = cont;
                Tvg ( cont_L ) = 0;

                % Atualiza�ao da Contagem de Linhas
               cont_L = cont_L + 1;

                % Atualiza��o do Contador
                cont = cont + 1;

            end
            
        end

    end
    
    % Aloca��o na Linha da Matriz de Termos
    Mig = horzcat ( Mig , transpose ( Tig ) );
    Mjg = horzcat ( Mjg , transpose ( Tjg ) );
    Mvg = horzcat ( Mvg , transpose ( Tvg ) );      
        
    % Transforma��o do Triplet na Matriz de Massa
    M = sparse ( Mig , Mjg , Mvg );
        
end

