%% Defini��o da Fun��o Objetivo

% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]
% x ( 10 ) - Vari�vel P      - Posi��o do Gaige no Comprimento Lf   - [ -- ]
% n                          - Quantidade de Elementos              - [ -  ]
% multicore                  - Quantidade de N�cleos

%% Declara��o da Fun��o Objetivo
function [ stop , opts , optchanged ] = plot_function( optimvalues , opts , flag )

    %%%%%%%%%%%%%
    % VARI�VEIS %
    %%%%%%%%%%%%%
    
    % Defini��o das Vari�veis
    b1 = optimvalues.x ( 1  );
    h1 = optimvalues.x ( 2  );
    b2 = optimvalues.x ( 3  );
    h2 = optimvalues.x ( 4  );
    L  = optimvalues.x ( 5  );
    Lf = optimvalues.x ( 6  );
    t  = optimvalues.x ( 7  );
    d  = optimvalues.x ( 8  );
    r  = optimvalues.x ( 9  );
    P  = optimvalues.x ( 10 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PARAMETRIZA��O DOS DADOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Visualiza��o das Legendas
    labels = { 'b1' , 'b2' , 'h1' , 'h2' , 'L' , 'Lf' , 't' , 'd' , 'r' , 'P' };
    
    % Visualiza��o dos dados
    data = [ b1 b2 h1 h2 L Lf t d r P ];     

    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VISUALIZA��O RESULTADOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Resultado - Itera��es
    if strcmp ( flag , 'iter' )
        
        % Gr�fico dos Resultados
        [ ~ , ax ] = plotmatrix ( data );
        
        % Defini��o das Legendas
        for i = 1:10
           
            % Defini��o da Legenda em X
            xlabel ( ax ( 10 , i ) , labels { i } );
            
            % Defini��o da Legenda em Y
            ylabel ( ax ( i , 10 ) , labels { i } );
        
        end
        
    end
    
    %%%%%%%%%%%%%%%
    % FINALIZA��O %
    %%%%%%%%%%%%%%%
    
    % Finaliza��o das vari�veis
    stop       = false;
    optchanged = false;

end