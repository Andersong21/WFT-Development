%% Cria��o da Matriz de Rigidez do Elemento Beam2 

%% INPUT
% E                 - M�dulo de Elasticidade do Elemento
% G                 - M�dulo de Elasticidade Transversal do Elemento
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento
% Cl                - Matriz das Coordenadas Locais do Elemento Beam2

%% OUTPUT
% Kl                - Matriz de Rigidez do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez do Elemento Beam2
function [ Kl ] = matrix_Kl_beam2 ( E , G , b , h , Cl )

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS GEOM�TRICOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    
    % �rea da Se��o Transversal
    A = b * h;
    
    % Momento de In�rcia Iyy
    Iz = h * b * b * b / 12;

    % Momento de In�rcia Izz
    Iy = b * h * h * h / 12;
    
    % Momento Polar de Inercia
    if ( b < h )
        
        % Momento Polar de In�rcia
        J = 0.141 * h * b * b * b;
        
    else
        
        % Momento Polar de In�rcia
        J = 0.141 * b * h * h * h;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez
    Kl = zeros ( 12 , 12 );
    
    % Aloca��o dos Termos -- Linha 1
    Kl ( 1  , 1  ) = + A * E / L;
    Kl ( 1  , 7  ) = - A * E / L;

    % Aloca��o dos Termos -- Linha 2
    Kl ( 2  , 2  ) = + 12.0 * E * Iz / ( L * L * L );
    Kl ( 2  , 6  ) = + 6.0  * E * Iz / ( L * L );
    Kl ( 2  , 8  ) = - 12.0 * E * Iz / ( L * L * L );
    Kl ( 2  , 12 ) = + 6.0  * E * Iz / ( L * L );

    % Aloca��o dos Termos -- Linha 3
    Kl ( 3  , 3  ) = + 12.0 * E * Iy / ( L * L * L );
    Kl ( 3  , 5  ) = - 6.0  * E * Iy / ( L * L );
    Kl ( 3  , 9  ) = - 12.0 * E * Iy / ( L * L * L );
    Kl ( 3  , 11 ) = - 6.0  * E * Iy / ( L * L );

    % Aloca��o dos Termos -- Linha 4
    Kl ( 4  , 4  ) = + G * J / L;
    Kl ( 4  , 10 ) = - G * J / L;

    % Aloca��o dos Termos -- Linha 5
    Kl ( 5  , 3  ) = - 6.0  * E * Iy / ( L * L );
    Kl ( 5  , 5  ) = + 4.0  * E * Iy / L;
    Kl ( 5  , 9  ) = + 6.0  * E * Iy / ( L * L );
    Kl ( 5  , 11 ) = + 2.0  * E * Iy / L;

    % Aloca��o dos Termos -- Linha 6
    Kl ( 6  , 2  ) = + 6.0  * E * Iz / ( L * L );
    Kl ( 6  , 6  ) = + 4.0  * E * Iz / L;
    Kl ( 6  , 8  ) = - 6.0  * E * Iz / ( L * L );
    Kl ( 6  , 12 ) = + 2.0  * E * Iz / L;

    % Aloca��o dos Termos -- Linha 7
    Kl ( 7  , 1  ) = - A * E / L;
    Kl ( 7  , 7  ) = + A * E / L;

    % Aloca��o dos Termos -- Linha 8
    Kl ( 8  , 2  ) = - 12.0 * E * Iz / ( L * L * L );
    Kl ( 8  , 6  ) = - 6.0  * E * Iz / ( L * L );
    Kl ( 8  , 8  ) = + 12.0 * E * Iz / ( L * L * L );
    Kl ( 8  , 12 ) = - 6.0  * E * Iz / ( L * L );

    % Aloca��o dos Termos -- Linha 9
    Kl ( 9  , 3  ) = - 12.0 * E * Iy / ( L * L * L );
    Kl ( 9  , 5  ) = + 6.0  * E * Iy / ( L * L );
    Kl ( 9  , 9  ) = + 12.0 * E * Iy / ( L * L * L );
    Kl ( 9  , 11 ) = + 6.0  * E * Iy / ( L * L );

    % Aloca��o dos Termos -- Linha 10
    Kl ( 10 , 4  ) = - G * J / L;
    Kl ( 10 , 10 ) = + G * J / L;

    % Aloca��o dos Termos -- Linha 11
    Kl ( 11 , 3  ) = - 6.0  * E * Iy / ( L * L );
    Kl ( 11 , 5  ) = + 2.0  * E * Iy / L;
    Kl ( 11 , 9  ) = + 6.0  * E * Iy / ( L * L );
    Kl ( 11 , 11 ) = + 4.0 * E * Iy / L;

    % Aloca��o dos Termos -- Linha 12
    Kl ( 12 , 2  ) = + 6.0  * E * Iz / ( L * L );
    Kl ( 12 , 6  ) = + 2.0  * E * Iz / L;
    Kl ( 12 , 8  ) = - 6.0  * E * Iz / ( L * L );
    Kl ( 12 , 12 ) = + 4.0  * E * Iz / L;
    
end

