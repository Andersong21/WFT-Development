%% Cria��o da Matriz de Rigidez do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% B                 - Matriz de Correla��o Deforma��o Deslocamento do Elemento Beam2
% D                 - Matriz Constitutiva de Membrana do Elemento Beam2

%% OUTPUT
% K1                - Matriz de Rigidez do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ K1 ] = matrix_K_QG_beam2 ( B , D )

    %%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez
    K1 = ( transpose ( B ) * D * B );   
    
end

