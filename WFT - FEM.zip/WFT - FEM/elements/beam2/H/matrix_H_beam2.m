%% Cria��o da Matriz de Fun��es de Forma do Elemento Beam2

%% INPUT
% x                 - Posi��o X do Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% H                 - Matriz de Fun��es de Forma do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Fun��es de Forma do Elemento Beam2
function [ H ] = matrix_H_beam2 ( x , Cl )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Defini��o do Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    
    % Defini��o do Semi Comprimento do Elemento
    a = L / 2;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma
    H = zeros ( 6 , 12 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma
    H ( 1 , 1  ) = - ( ( a + x ) / ( 2 * a ) );
    H ( 1 , 7  ) = + ( ( a + x ) / ( 2 * a ) );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma
    H ( 2 , 2  ) = + 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^2 ) * ( ( ( 2 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^3 );
    H ( 2 , 6  ) = + 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^2 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^2 );
    H ( 2 , 8  ) = + 1 * ( ( ( ( 2 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^2 ) ) / ( 4 * a^3 );
    H ( 2 , 12 ) = - 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^2 ) ) / ( 4 * a^2 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma
    H ( 3 , 3  ) = + 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^2 ) * ( ( ( 2 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^3 );
    H ( 3 , 5  ) = - 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^2 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^2 );
    H ( 3 , 9  ) = + 1 * ( ( ( ( 2 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^2 ) ) / ( 4 * a^3 );
    H ( 3 , 11 ) = + 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^2 ) ) / ( 4 * a^2 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma
    H ( 4 , 4  ) = - ( ( a + x ) / ( 2 * a ) );
    H ( 4 , 10 ) = + ( ( a + x ) / ( 2 * a ) );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma
    H ( 5 , 3  ) = - 3 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^3 );
    H ( 5 , 5  ) = + 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 3 * x ) )^1 ) ) / ( 4 * a^2 );
    H ( 5 , 9  ) = + 3 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^3 );
    H ( 5 , 11 ) = + 1 * ( ( ( ( 1 * a ) - ( 3 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^2 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma
    H ( 6 , 2  ) = - 3 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^3 );
    H ( 6 , 6  ) = - 1 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 3 * x ) )^1 ) ) / ( 4 * a^2 );
    H ( 6 , 8  ) = + 3 * ( ( ( ( 1 * a ) - ( 1 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^3 );
    H ( 6 , 12 ) = - 1 * ( ( ( ( 1 * a ) - ( 3 * x ) )^1 ) * ( ( ( 1 * a ) + ( 1 * x ) )^1 ) ) / ( 4 * a^2 );    
    
end

