%% Cria��o da Matriz dos Pontos da Quadratura de Gauss do Elemento Beam2

%% INPUT
% Cl                - Estrutura de Dados das Coordenadas Locais do N� do Elemento Beam2

%% OUTPUT
% WE                - Matriz dos Pontos da Quadratura de Gauss do Beam2

%% Declara��o da Fun��o de Cria��o da Matriz dos Pontos da Quadratura de Gauss do Elemento Beam2
function [ PO ] = matrix_PO_beam2 ( Cl )

    % Defini��o do Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    
    % Defini��o do Semi Comprimento do Elemento
    a = L / 2;
   
    % Inicializa��o da Matriz dos Pontos da Quadratura de Gauss
    PO = zeros ( 3 , 1 );
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 1
    PO ( 1 , 1 ) = - a * sqrt ( 3 / 5 );
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 2
    PO ( 2 , 1 ) =   0.0;
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 3
    PO ( 3 , 1 ) = + a * sqrt ( 3 / 5 );
    
end

