%% Cria��o da Densidade do Elemento Beam2

%% INPUT
% Mat_Param         - Estrutura de Dados do Material do Problema

%% OUTPUT
% rho               - Densidade do Material

%% Declara��o da Fun��o de Cria��o da Densidade do Elemento Beam2
function [ rho ] = matrix_P_beam2 ( Mat_Param )

    %%%%%%%%%%%%%%
    % PAR�METROS %
    %%%%%%%%%%%%%%
    
    % Densidade do Material
    rho = Mat_Param ( 1 ).rho;

end

