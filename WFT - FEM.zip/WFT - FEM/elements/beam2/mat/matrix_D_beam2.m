%% Cria��o da Matriz Constutitva do Elemento Beam2

%% INPUT
% Mat_Param         - Estrutura de Dados do Material do Problema

%% OUTPUT
% E                 - M�dulo de Elasticidade do Elemento
% G                 - M�dulo de Elasticidade Transversal do Elemento

%% Declara��o da Fun��o de Cria��o da Matriz Constutitva do Elemento Beam2
function [ E , G ] = matrix_D_beam2 ( Mat_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DE MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % M�dulo de Elasticidade do Elemento
    E = Mat_Param ( 1 ).E;
    
    % Coeficiente de Poisson
    poisson = Mat_Param ( 1 ).poisson;
    
    % M�dulo de Elasticidade Transversal do Elemento
    G = ( E / ( ( 2 * ( 1 + poisson ) ) ) ); 
    
end

