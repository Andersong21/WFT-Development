%% Cria��o da Matriz de Transforma��o de Coordenadas do Elemento Beam2

%% INPUT
% Cg                - Matriz das Coordenadas Globais do Elemento Beam2

%% OUTPUT
% R                 - Matriz de Transforma��o de Coordenadas do Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Transforma��o de Coordenadas do Elemento Beam2
function [ R ] = matrix_R_beam2 ( Cg )

    %%%%%%%%%%%%%%%%%%%%%%%
    % COORDENADAS DO N� 1 %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenada X
    X1 = Cg ( 1 , 1 );

    % Coordenada Y
    Y1 = Cg ( 1 , 2 );
    
    % Coordenada Z
    Z1 = Cg ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%
    % COORDENADAS DO N� 2 %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenada X
    X2 = Cg ( 2 , 1 );

    % Coordenada Y
    Y2 = Cg ( 2 , 2 );
    
    % Coordenada Z
    Z2 = Cg ( 2 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%
    % C�LCULOS INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Defini��o do Comprimento do Elemento
    L = sqrt ( ( ( X2 - X1 )^2 ) + ( ( Y2 - Y1 )^2 ) + ( ( Z2 - Z1 )^2 ) );
    
    %%%%%%%%%%%%%%%%%%%%%%
    % COSSENOS DIRETORES %
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Cosseno Diretor l
    l = ( X2 - X1 ) / L;
    
    % Cosseno Diretor m
    m = ( Y2 - Y1 ) / L;
    
    % Cosseno Diretor n
    n = ( Z2 - Z1 ) / L;
    
    % Cosseno Diretor Di
    Di = sqrt ( ( l * l ) + ( m * m ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE ROTA��O DE TRANSLA��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rota��o de Transla��o
    T = zeros ( 3 , 3 );
    
    % Verifica��o do Cosseno Diretor Di Nulo
    if ( Di == 0.0 )
        
        % Coordenada Z2 > Z1
        if ( Z2 > Z1 )
            
            % Defini��o da Matriz de Rota��o de Transla��o
            T ( 1 , 3 ) = + 1.0;
            T ( 2 , 2 ) = + 1.0;
            T ( 3 , 1 ) = - 1.0;

        % Coordenada Z1 > Z2
        else
            
            % Defini��o da Matriz de Rota��o de Transla��o
            T ( 1 , 3 ) = - 1.0;
            T ( 2 , 2 ) = + 1.0;
            T ( 3 , 1 ) = + 1.0;
            
        end
        
    % Verifica��o do Cosseno Diretor Di N�o Nulo
    else
        
        % Defini��o da Matriz de Rota��o de Transla��o
        T ( 1 , 1 ) = + l;
        T ( 1 , 2 ) = + m;
        T ( 1 , 3 ) = + n;
        T ( 2 , 1 ) = - ( m / Di );
        T ( 2 , 2 ) = + ( l / Di );
        T ( 2 , 3 ) = 0.0;
        T ( 3 , 1 ) = - ( l * n / Di );
        T ( 3 , 2 ) = - ( m * n / Di );
        T ( 3 , 3 ) = + Di;
        
    end
    
    % Defini��o da Matriz de Transforma��o Nodal
    TT = blkdiag ( T , T );
    
    % Defini��o da Matriz de Transforma��o do Elemento
    R = blkdiag ( TT , TT );     
        
end

