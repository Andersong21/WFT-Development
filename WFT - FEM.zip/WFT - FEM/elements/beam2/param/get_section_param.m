%% Retorno dos Par�metros da Se��o do Elemento i

%% INPUT
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento com id i

%% OUTPUT
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento

%% Declara��o da Fun��o de Retorno dos Par�metros da Se��o do Elemento i
function [ b , h ] = get_section_param ( Elem_Param , Prop_Param , i )

    %%%%%%%%%%%%%%
    % PAR�METROS %
    %%%%%%%%%%%%%%
    
    % Id da Propriedade do Elemento
    prop_Id = Elem_Param ( i ).prop_id;
    
    % Base do Elemento no N� 1
    b1 = Prop_Param ( prop_Id ).b ( 1 );

    % Base do Elemento no N� 2
    b2 = Prop_Param ( prop_Id ).b ( 2 );
    
    % Base M�dia do Elemento
    b = ( b1 + b2 ) / 2;
    
    % Altura do Elemento no N� 1
    h1 = Prop_Param ( prop_Id ).h ( 1 );

    % Altura do Elemento no N� 2
    h2 = Prop_Param ( prop_Id ).h ( 2 );
    
    % Altura M�dia do Elemento
    h = ( h1 + h2 ) / 2;   
    
end

