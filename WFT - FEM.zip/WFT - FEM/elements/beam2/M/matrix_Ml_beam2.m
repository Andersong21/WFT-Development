%% Cria��o da Matriz de Massa Local do Elemento Beam2

%% INPUT
% rho               - Densidade do Material
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento
% Cl                - Matriz das Coordenadas Locais do Elemento Beam2

%% OUTPUT
% Ml                - Matriz de Massa Local do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Massa Local do Elemento Beam2
function [ Ml ] = matrix_Ml_beam2 ( rho , b , h , Cl )
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS GEOM�TRICOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    
    % �rea da Se��o Transversal
    A = b * h;
    
    % Momento Polar de Inercia
    if ( b < h )
        
        % Momento Polar de In�rcia
        J = 0.141 * h * b * b * b;
        
    else
        
        % Momento Polar de In�rcia
        J = 0.141 * b * h * h * h;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA LOCAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local
    Ml = zeros ( 12 , 12 );

    % Aloca��o dos Termos -- Barra
    Ml ( 1  , 1  ) = ( rho * A * L ) * ( 1.0 / 3.0 );
    Ml ( 1  , 7  ) = ( rho * A * L ) * ( 1.0 / 6.0 );
    Ml ( 7  , 1  ) = ( rho * A * L ) * ( 1.0 / 6.0 );
    Ml ( 7  , 7  ) = ( rho * A * L ) * ( 1.0 / 3.0 );

    % Aloca��o dos Termos -- Viga na Dire��o Y
    Ml ( 2  , 2  ) = ( rho * A * L ) * ( 39.0 / 78.0 );
    Ml ( 6  , 6  ) = ( rho * A * L ) * ( 39.0 * L * L / 78.0 );
    Ml ( 8  , 8  ) = ( rho * A * L ) * ( 39.0 / 78.0 );
    Ml ( 12 , 12 ) = ( rho * A * L ) * ( 39.0 * L * L / 78.0 );

    % Aloca��o dos Termos -- Viga na Dire��o Z
    Ml ( 3  , 3  ) = ( rho * A * L ) * ( 39.0 / 78.0 );
    Ml ( 5  , 5  ) = ( rho * A * L ) * ( 39.0 * L * L / 78.0 );
    Ml ( 9  , 9  ) = ( rho * A * L ) * ( 39.0 / 78.0 );
    Ml ( 11 , 11 ) = ( rho * A * L ) * ( 39.0 * L * L / 78.0 );

    % Aloca��o dos Termos -- Tor��o
    Ml ( 4  , 4  ) = ( rho * L ) * ( J / 3.0 );
    Ml ( 4  , 10 ) = ( rho * L ) * ( J / 6.0 );
    Ml ( 10 , 4  ) = ( rho * L ) * ( J / 6.0 );
    Ml ( 10 , 10 ) = ( rho * L ) * ( J / 3.0 );    
    
end

