%% Cria��o da Matriz de Massa do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% H                 - Matriz de Fun��es de Forma do Elemento Beam2
% rho               - Densidade do Material
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento

%% OUTPUT
% M1                - Matriz de Massa do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ M1 ] = matrix_M_QG_beam2 ( H , rho , b , h )

    %%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA %
    %%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa
    M1 = ( transpose ( H ) * H ) * rho * b * h;   
    
end

