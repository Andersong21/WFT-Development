%% Cria��o da Matriz de Massa do Elemento Tapered Beam2

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Elemento i

%% OUTPUT
% Mi                - Termo i da Matriz de Massa Global
% Mj                - Termo j da Matriz de Massa Global
% Mv                - Valor ( i , j ) da Matriz de Massa Global

%% Declara��o da Fun��o de Cria��o da Matriz de Massa do Elemento
function [ Mi , Mj , Mv ] = matrix_M_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno das Defini��es Iniciais da Propriedade
    [ b , h ] = get_section_param ( Elem_Param , Prop_Param , i );
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_beam2 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_beam2 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_beam2 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DENSIDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Densidade do Elemento
    [ rho ] = matrix_P_beam2 ( Mat_Param );  
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO % LOCAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Massa Local
    [ Ml ] = matrix_Ml_beam2 ( rho , b , h , Cl );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO % GLOBAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Global do Elemento
    Mg = sparse ( transpose ( R ) * Ml * R );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE GRAUS DE LIBERDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador de Graus de Liberdade do Elemento
    Ndof = 1;
    
    % Inicializa��o do Vetor de Graus de Liberdade
    DOF = zeros ( 12 , 1 );
    
    % Varredura nos N�s do Elemento
    for j = 1:length( Elem_Param ( i ).node )
       
        % Id do N�
        Idn = Elem_Param ( i ).node ( j );
        
        % Varredura nos Graus de Liberdade dos N�s do Elemento
        for k = 1:length ( Node_Param ( Idn ).dof )            
            
            % Aloca��o no Vetor de Graus de Liberdade
            DOF ( Ndof ) = Node_Param ( Idn ).dof ( k );
            
            % Incremento na Contagem de Graus de Liberdade
            Ndof = Ndof + 1;
            
        end         
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Quantidade de Termos N�o Nulos na Matriz
    Nn = nnz ( Mg );
    
    % Defini��o das Posi��es e Valores da Matriz
    [ pi , pj , pv ] = find ( Mg );
    
    % Inicializa��o do Contador
    cont = 1;
    
    % Aloca��o na Matriz de Massa Global do Problema
    for j = 1:Nn
        
        % Posi��o a
        a = pi ( j );
        
        % Posi��o b
        b = pj ( j );        
        
        % Verifica��o se o Grau de Liberdade � nulo
        if ( DOF ( a ) == 0 )
            
            % Continuar
            continue;
            
        else     
            
            % Verifica��o se o Grau de Liberdade � nulo
            if ( DOF ( b ) == 0 )

                % Continuar
                continue;

            else

                % Aloca��o dos Termos da Matriz na Posi��o Global
                Mi ( cont ) = DOF ( a );
                Mj ( cont ) = DOF ( b );
                Mv ( cont ) = pv ( j );
                
                % Atualiza��o do Contador
                cont = cont + 1;
                
            end
            
        end
        
    end
    
end

