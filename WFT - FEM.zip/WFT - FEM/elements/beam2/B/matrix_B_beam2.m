%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o do Elemento Beam2

%% INPUT
% x                 - Posi��o x do Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Ba                - Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2
% Bfz               - Matriz de Correla��o Deslocamento Deforma��o Flex�o ZZ do Elemento Beam2
% Bfy               - Matriz de Correla��o Deslocamento Deforma��o Flex�o YY do Elemento Beam2
% Bt                - Matriz de Correla��o Deslocamento Deforma��o Tor��o do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o do Elemento Beam2
function [ Ba , Bfz , Bfy , Bt ] = matrix_B_beam2 ( x , Cl )

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS GEOM�TRICOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento Axial
    Ba = zeros ( 1 , 2 );

    % Aloca��o dos Termos na Matriz Correla��o Deforma��o Deslocamento Axial
    Ba ( 1 , 1 ) = ( - 1.0 / L );
    Ba ( 1 , 2 ) = ( + 1.0 / L );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento Flex�o ZZ
    Bfz = zeros ( 1 , 4 );

    % Aloca��o dos Termos na Matriz Correla��o Deforma��o Deslocamento Flex�o ZZ
    Bfz ( 1 , 1 ) = + ( - 6.0 / ( L * L ) ) + ( ( 12.0 * x ) / ( L * L * L )  );
    Bfz ( 1 , 2 ) = - ( 1.0 ) * ( ( - 4.0 / L ) + ( ( 6.0 * x ) / ( L * L ) ) );
    Bfz ( 1 , 3 ) = + ( + 6.0 / ( L * L ) ) - ( ( 12.0 * x ) / ( L * L * L )  );
    Bfz ( 1 , 4 ) = - ( 1.0 ) * ( ( - 2.0 / L ) + ( ( 6.0 * x ) / ( L * L ) ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento Flex�o YY
    Bfy = zeros ( 1 , 4 );

    % Aloca��o dos Termos na Matriz Correla��o Deforma��o Deslocamento Flex�o YY
    Bfy ( 1 , 1 ) = + ( - 6.0 / ( L * L ) ) + ( ( 12.0 * x ) / ( L * L * L )  );
    Bfy ( 1 , 2 ) = + ( 1.0 ) * ( ( - 4.0 / L ) + ( ( 6.0 * x ) / ( L * L ) ) );
    Bfy ( 1 , 3 ) = + ( + 6.0 / ( L * L ) ) - ( ( 12.0 * x ) / ( L * L * L )  );
    Bfy ( 1 , 4 ) = + ( 1.0 ) * ( ( - 2.0 / L ) + ( ( 6.0 * x ) / ( L * L ) ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento Tor��o
    Bt = zeros ( 1 , 2 );

    % Aloca��o dos Termos na Matriz Correla��o Deforma��o Deslocamento Tor��o
    Bt ( 1 , 1 ) = ( - 1.0 / L );
    Bt ( 1 , 2 ) = ( + 1.0 / L );
    
end

