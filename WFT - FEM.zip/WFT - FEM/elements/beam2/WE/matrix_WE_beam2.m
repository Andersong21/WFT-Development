%% Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Beam2

%% INPUT
% Cl                - Estrutura de Dados das Coordenadas Locais do N� do Elemento Beam2

%% OUTPUT
% WE                - Matriz dos Pesos na Quadratura de Gauss do Beam2

%% Declara��o da Fun��o de Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Beam2
function [ WE ] = matrix_WE_beam2 ( Cl )
   
    % Defini��o do Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    
    % Defini��o do Semi Comprimento do Elemento
    a = L / 2;
    
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss
    WE = zeros ( 3 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss
    WE ( 1 ) = 5 * a / 9;
    WE ( 2 ) = 8 * a / 9;
    WE ( 3 ) = 5 * a / 9;
    
end

