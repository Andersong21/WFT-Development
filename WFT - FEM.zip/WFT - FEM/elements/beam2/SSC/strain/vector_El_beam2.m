%% Cria��o do Vetor de Deforma��es Locais do Elemento Beam2

%% INPUT
% Ba                - Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2
% Bfz               - Matriz de Correla��o Deslocamento Deforma��o Flex�o ZZ do Elemento Beam2
% Bfy               - Matriz de Correla��o Deslocamento Deforma��o Flex�o YY do Elemento Beam2
% Bt                - Matriz de Correla��o Deslocamento Deforma��o Tor��o do Elemento Beam2
% Ul                - Vetor de Deslocamento Nodais Locais do Elemento
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento  
% local             - Local de C�lculo das Deforma��es na Viga
%                   - [ C ] = Canto
%                   - [ E ] = Extremidade                    

%% OUTPUT
% ElA               - Vetor de Deforma��es Locais no Ponto A
% ElB               - Vetor de Deforma��es Locais no Ponto B
% ElC               - Vetor de Deforma��es Locais no Ponto C
% ElD               - Vetor de Deforma��es Locais no Ponto D
% ElE               - Vetor de Deforma��es Locais no Ponto E
% ElF               - Vetor de Deforma��es Locais no Ponto F
% ElG               - Vetor de Deforma��es Locais no Ponto G
% ElH               - Vetor de Deforma��es Locais no Ponto H
% ElI               - Vetor de Deforma��es Locais no Ponto I
% ElJ               - Vetor de Deforma��es Locais no Ponto J
% ElK               - Vetor de Deforma��es Locais no Ponto K
% ElL               - Vetor de Deforma��es Locais no Ponto L

%% Declara��o da Fun��o de Cria��o Vetor de Deforma��es Locais do Elemento Beam2
function [ ElA , ElB , ElC , ElD , ElE , ElF , ElG , ElH , ElI , ElJ , ElK , ElL ] = vector_El_beam2 ( Ba , Bfz , Bfy , Bt , Ul ,  b , h , local )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Axial
    Ula = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Axial
    Ula ( 1 , 1 ) = Ul ( 1  , 1 );
    Ula ( 2 , 1 ) = Ul ( 7  , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o YY
    Uly = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o YY
    Uly ( 1 , 1 ) = Ul ( 3  , 1 );
    Uly ( 2 , 1 ) = Ul ( 5  , 1 );
    Uly ( 3 , 1 ) = Ul ( 9  , 1 );
    Uly ( 4 , 1 ) = Ul ( 11 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o ZZ
    Ulz = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o ZZ
    Ulz ( 1 , 1 ) = Ul ( 2  , 1 );
    Ulz ( 2 , 1 ) = Ul ( 6  , 1 );
    Ulz ( 3 , 1 ) = Ul ( 8  , 1 );
    Ulz ( 4 , 1 ) = Ul ( 12 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Tor��o
    Ult = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Tor��o
    Ult ( 1 , 1 ) = Ul ( 4  , 1 );
    Ult ( 2 , 1 ) = Ul ( 10 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DEFORMA��ES CANTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��o Canto
    if ( strcmp ( local , 'C' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = + b / 2;
        zl = + h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto A
        E_axial_A = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto A
        E_fy_A = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto A
        E_fz_A = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto A
        E_ft_A = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        ElA ( 1 ) = E_axial_A ( 1 ) + E_fy_A ( 1 ) + E_fz_A ( 1 );
        ElA ( 2 ) = 0;
        ElA ( 3 ) = 0;
        ElA ( 4 ) = E_ft_A ( 1 ) / 2.0;
        ElA ( 5 ) = 0;
        ElA ( 6 ) = 0;

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = - b / 2;
        zl = + h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto B
        E_axial_B = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto B
        E_fy_B = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto B
        E_fz_B = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto B
        E_ft_B = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto B
        ElB ( 1 ) = E_axial_B ( 1 ) + E_fy_B ( 1 ) + E_fz_B ( 1 );
        ElB ( 2 ) = 0;
        ElB ( 3 ) = 0;
        ElB ( 4 ) = E_ft_B ( 1 ) / 2.0;
        ElB ( 5 ) = 0;
        ElB ( 6 ) = 0;

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - b / 2;
        zl = - h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto C
        E_axial_C = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto C
        E_fy_C = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto C
        E_fz_C = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto C
        E_ft_C = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto C
        ElC ( 1 ) = E_axial_C ( 1 ) + E_fy_C ( 1 ) + E_fz_C ( 1 );
        ElC ( 2 ) = 0;
        ElC ( 3 ) = 0;
        ElC ( 4 ) = E_ft_C ( 1 ) / 2.0;
        ElC ( 5 ) = 0;
        ElC ( 6 ) = 0;

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = + b / 2;
        zl = - h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto D
        E_axial_D = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto D
        E_fy_D = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto D
        E_fz_D = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto D
        E_ft_D = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto D
        ElD ( 1 ) = E_axial_D ( 1 ) + E_fy_D ( 1 ) + E_fz_D ( 1 );
        ElD ( 2 ) = 0;
        ElD ( 3 ) = 0;
        ElD ( 4 ) = E_ft_D ( 1 ) / 2.0;
        ElD ( 5 ) = 0;
        ElD ( 6 ) = 0;
        
        % Vetor de Deforma��es Locais do Ponto E
        ElE = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto F
        ElF = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto G
        ElG = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto H
        ElH = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto I
        ElI = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto J
        ElJ = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto K
        ElK = zeros ( 6 , 1 );
        
        % Vetor de Deforma��es Locais do Ponto L
        ElL = zeros ( 6 , 1 );
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DEFORMA��ES EXTREMIDADE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��o Extremidade
    if ( strcmp ( local , 'E' ) == 1 )
        
        %%%%%%%%%%%        
        % Ponto A %
        %%%%%%%%%%%
        
        % Defini��es das Coordenadas do Ponto A
        yl = + 1.5;
        zl = + h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto A
        E_axial_A = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto A
        E_fy_A = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto A
        E_fz_A = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto A
        E_ft_A = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        ElA ( 1 ) = E_axial_A ( 1 ) + E_fy_A ( 1 ) + E_fz_A ( 1 );
        ElA ( 2 ) = 0;
        ElA ( 3 ) = 0;
        ElA ( 4 ) = E_ft_A ( 1 ) / 2.0;
        ElA ( 5 ) = 0;
        ElA ( 6 ) = 0;
        
        %%%%%%%%%%%        
        % Ponto B %
        %%%%%%%%%%%
        
        % Defini��es das Coordenadas do Ponto B
        yl = + 0.0;
        zl = + h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto B
        E_axial_B = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto B
        E_fy_B = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto B
        E_fz_B = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto B
        E_ft_B = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        ElB ( 1 ) = E_axial_B ( 1 ) + E_fy_B ( 1 ) + E_fz_B ( 1 );
        ElB ( 2 ) = 0;
        ElB ( 3 ) = 0;
        ElB ( 4 ) = E_ft_B ( 1 ) / 2.0;
        ElB ( 5 ) = 0;
        ElB ( 6 ) = 0; 
    
        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - 1.5;
        zl = + h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto C
        E_axial_C = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto C
        E_fy_C = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto C
        E_fz_C = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto C
        E_ft_C = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto C
        ElC ( 1 ) = E_axial_C ( 1 ) + E_fy_C ( 1 ) + E_fz_C ( 1 );
        ElC ( 2 ) = 0;
        ElC ( 3 ) = 0;
        ElC ( 4 ) = E_ft_C ( 1 ) / 2.0;
        ElC ( 5 ) = 0;
        ElC ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = + b / 2;
        zl = + 1.5;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto D
        E_axial_D = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto D
        E_fy_D = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto D
        E_fz_D = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto D
        E_ft_D = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto D
        ElD ( 1 ) = E_axial_D ( 1 ) + E_fy_D ( 1 ) + E_fz_D ( 1 );
        ElD ( 2 ) = 0;
        ElD ( 3 ) = 0;
        ElD ( 4 ) = E_ft_D ( 1 ) / 2.0;
        ElD ( 5 ) = 0;
        ElD ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO E %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto E
        yl = + b / 2;
        zl = + 0.0;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto E
        E_axial_E = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto E
        E_fy_E = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto E
        E_fz_E = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto E
        E_ft_E = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto E
        ElE ( 1 ) = E_axial_E ( 1 ) + E_fy_E ( 1 ) + E_fz_E ( 1 );
        ElE ( 2 ) = 0;
        ElE ( 3 ) = 0;
        ElE ( 4 ) = E_ft_E ( 1 ) / 2.0;
        ElE ( 5 ) = 0;
        ElE ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO F %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto F
        yl = + b / 2;
        zl = - 1.5;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto F
        E_axial_F = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto F
        E_fy_F = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto F
        E_fz_F = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto F
        E_ft_F = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto F
        ElF ( 1 ) = E_axial_F ( 1 ) + E_fy_F ( 1 ) + E_fz_F ( 1 );
        ElF ( 2 ) = 0;
        ElF ( 3 ) = 0;
        ElF ( 4 ) = E_ft_F ( 1 ) / 2.0;
        ElF ( 5 ) = 0;
        ElF ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO G %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto G
        yl = - 1.5;
        zl = - h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto G
        E_axial_G = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto G
        E_fy_G = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto G
        E_fz_G = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto G
        E_ft_G = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto G
        ElG ( 1 ) = E_axial_G ( 1 ) + E_fy_G ( 1 ) + E_fz_G ( 1 );
        ElG ( 2 ) = 0;
        ElG ( 3 ) = 0;
        ElG ( 4 ) = E_ft_G ( 1 ) / 2.0;
        ElG ( 5 ) = 0;
        ElG ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO H %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto H
        yl = + 0.0;
        zl = - h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto H
        E_axial_H = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto H
        E_fy_H = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto H
        E_fz_H = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto H
        E_ft_H = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto H
        ElH ( 1 ) = E_axial_H ( 1 ) + E_fy_H ( 1 ) + E_fz_H ( 1 );
        ElH ( 2 ) = 0;
        ElH ( 3 ) = 0;
        ElH ( 4 ) = E_ft_H ( 1 ) / 2.0;
        ElH ( 5 ) = 0;
        ElH ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO I %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto I
        yl = + 1.5;
        zl = - h / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto I
        E_axial_I = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto I
        E_fy_I = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto I
        E_fz_I = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto I
        E_ft_I = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto I
        ElI ( 1 ) = E_axial_I ( 1 ) + E_fy_I ( 1 ) + E_fz_I ( 1 );
        ElI ( 2 ) = 0;
        ElI ( 3 ) = 0;
        ElI ( 4 ) = E_ft_I ( 1 ) / 2.0;
        ElI ( 5 ) = 0;
        ElI ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO J %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto J
        yl = - b / 2;
        zl = - 1.5;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto J
        E_axial_J = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto J
        E_fy_J = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto J
        E_fz_J = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto J
        E_ft_J = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto J
        ElJ ( 1 ) = E_axial_J ( 1 ) + E_fy_J ( 1 ) + E_fz_J ( 1 );
        ElJ ( 2 ) = 0;
        ElJ ( 3 ) = 0;
        ElJ ( 4 ) = E_ft_J ( 1 ) / 2.0;
        ElJ ( 5 ) = 0;
        ElJ ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO K %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto K
        yl = - b / 2;
        zl = + 0.0;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto K
        E_axial_K = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto K
        E_fy_K = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto K
        E_fz_K = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto K
        E_ft_K = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto K
        ElK ( 1 ) = E_axial_K ( 1 ) + E_fy_K ( 1 ) + E_fz_K ( 1 );
        ElK ( 2 ) = 0;
        ElK ( 3 ) = 0;
        ElK ( 4 ) = E_ft_K ( 1 ) / 2.0;
        ElK ( 5 ) = 0;
        ElK ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO L %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto L
        yl = - b / 2;
        zl = + 1.5;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto L
        E_axial_L = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto L
        E_fy_L = - zl * ( Bfy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto L
        E_fz_L = - yl * ( Bfz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto L
        E_ft_L = - ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto L
        ElL ( 1 ) = E_axial_L ( 1 ) + E_fy_L ( 1 ) + E_fz_L ( 1 );
        ElL ( 2 ) = 0;
        ElL ( 3 ) = 0;
        ElL ( 4 ) = E_ft_L ( 1 ) / 2.0;
        ElL ( 5 ) = 0;
        ElL ( 6 ) = 0;
        
    end

end

