%% Cria��o do Vetor de Deforma��es Globais do Elemento Beam2

%% INPUT
% ElA               - Vetor de Deforma��o Local no Ponto A
% ElB               - Vetor de Deforma��o Local no Ponto B
% ElC               - Vetor de Deforma��o Local no Ponto C
% ElD               - Vetor de Deforma��o Local no Ponto D
% ElE               - Vetor de Deforma��es Locais no Ponto E
% ElF               - Vetor de Deforma��es Locais no Ponto F
% ElG               - Vetor de Deforma��es Locais no Ponto G
% ElH               - Vetor de Deforma��es Locais no Ponto H
% ElI               - Vetor de Deforma��es Locais no Ponto I
% ElJ               - Vetor de Deforma��es Locais no Ponto J
% ElK               - Vetor de Deforma��es Locais no Ponto K
% ElL               - Vetor de Deforma��es Locais no Ponto L
% R                 - Matriz de Transforma�ao de Coordenada do Elemento

%% OUTPUT
% EgA               - Vetor de Deforma��o Global no Ponto A
% EgB               - Vetor de Deforma��o Global no Ponto B
% EgC               - Vetor de Deforma��o Global no Ponto C
% EgD               - Vetor de Deforma��o Global no Ponto D
% EgE               - Vetor de Deforma��o Global no Ponto E
% EgF               - Vetor de Deforma��o Global no Ponto F
% EgG               - Vetor de Deforma��o Global no Ponto G
% EgH               - Vetor de Deforma��o Global no Ponto H
% EgI               - Vetor de Deforma��o Global no Ponto I
% EgJ               - Vetor de Deforma��o Global no Ponto J
% EgK               - Vetor de Deforma��o Global no Ponto K
% EgL               - Vetor de Deforma��o Global no Ponto L

%% Declara��o da Fun��o de Cria��o Vetor de Deforma��es Globais do Elemento Beam2
function [ EgA , EgB , EgC , EgD , EgE , EgF , EgG , EgH , EgI , EgJ , EgK , EgL ] = vector_Eg_beam2 ( ElA , ElB , ElC , ElD , ElE , ElF , ElG , ElH , ElI , ElJ , ElK , ElL , R )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto A
    matrix_El_A = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em A -- Linha 1
    matrix_El_A ( 1 , 1 ) = ElA ( 1 );
    matrix_El_A ( 1 , 2 ) = ElA ( 4 );
    matrix_El_A ( 1 , 3 ) = ElA ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em A -- Linha 2
    matrix_El_A ( 2 , 1 ) = ElA ( 4 );
    matrix_El_A ( 2 , 2 ) = ElA ( 2 );
    matrix_El_A ( 2 , 3 ) = ElA ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em A -- Linha 3
    matrix_El_A ( 3 , 1 ) = ElA ( 6 );
    matrix_El_A ( 3 , 2 ) = ElA ( 5 );
    matrix_El_A ( 3 , 3 ) = ElA ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto A
    matrix_Eg_A =  transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_A * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em A
    EgA ( 1 ) = matrix_Eg_A ( 1 , 1 );
    EgA ( 2 ) = matrix_Eg_A ( 2 , 2 );
    EgA ( 3 ) = matrix_Eg_A ( 3 , 3 );
    EgA ( 4 ) = matrix_Eg_A ( 1 , 2 );
    EgA ( 5 ) = matrix_Eg_A ( 2 , 3 );
    EgA ( 6 ) = matrix_Eg_A ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto B
    matrix_El_B = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em B -- Linha 1
    matrix_El_B ( 1 , 1 ) = ElB ( 1 );
    matrix_El_B ( 1 , 2 ) = ElB ( 4 );
    matrix_El_B ( 1 , 3 ) = ElB ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em B -- Linha 2
    matrix_El_B ( 2 , 1 ) = ElB ( 4 );
    matrix_El_B ( 2 , 2 ) = ElB ( 2 );
    matrix_El_B ( 2 , 3 ) = ElB ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em B -- Linha 3
    matrix_El_B ( 3 , 1 ) = ElB ( 6 );
    matrix_El_B ( 3 , 2 ) = ElB ( 5 );
    matrix_El_B ( 3 , 3 ) = ElB ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto B
    matrix_Eg_B = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_B * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em B
    EgB ( 1 ) = matrix_Eg_B ( 1 , 1 );
    EgB ( 2 ) = matrix_Eg_B ( 2 , 2 );
    EgB ( 3 ) = matrix_Eg_B ( 3 , 3 );
    EgB ( 4 ) = matrix_Eg_B ( 1 , 2 );
    EgB ( 5 ) = matrix_Eg_B ( 2 , 3 );
    EgB ( 6 ) = matrix_Eg_B ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM C %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto C
    matrix_El_C = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em C -- Linha 1
    matrix_El_C ( 1 , 1 ) = ElC ( 1 );
    matrix_El_C ( 1 , 2 ) = ElC ( 4 );
    matrix_El_C ( 1 , 3 ) = ElC ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em C -- Linha 2
    matrix_El_C ( 2 , 1 ) = ElC ( 4 );
    matrix_El_C ( 2 , 2 ) = ElC ( 2 );
    matrix_El_C ( 2 , 3 ) = ElC ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em C -- Linha 3
    matrix_El_C ( 3 , 1 ) = ElC ( 6 );
    matrix_El_C ( 3 , 2 ) = ElC ( 5 );
    matrix_El_C ( 3 , 3 ) = ElC ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em C %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto C
    matrix_Eg_C = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_C * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em C
    EgC ( 1 ) = matrix_Eg_C ( 1 , 1 );
    EgC ( 2 ) = matrix_Eg_C ( 2 , 2 );
    EgC ( 3 ) = matrix_Eg_C ( 3 , 3 );
    EgC ( 4 ) = matrix_Eg_C ( 1 , 2 );
    EgC ( 5 ) = matrix_Eg_C ( 2 , 3 );
    EgC ( 6 ) = matrix_Eg_C ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto D
    matrix_El_D = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em D -- Linha 1
    matrix_El_D ( 1 , 1 ) = ElD ( 1 );
    matrix_El_D ( 1 , 2 ) = ElD ( 4 );
    matrix_El_D ( 1 , 3 ) = ElD ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em D -- Linha 2
    matrix_El_D ( 2 , 1 ) = ElD ( 4 );
    matrix_El_D ( 2 , 2 ) = ElD ( 2 );
    matrix_El_D ( 2 , 3 ) = ElD ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em D -- Linha 3
    matrix_El_D ( 3 , 1 ) = ElD ( 6 );
    matrix_El_D ( 3 , 2 ) = ElD ( 5 );
    matrix_El_D ( 3 , 3 ) = ElD ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto D
    matrix_Eg_D = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_D * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em D
    EgD ( 1 ) = matrix_Eg_D ( 1 , 1 );
    EgD ( 2 ) = matrix_Eg_D ( 2 , 2 );
    EgD ( 3 ) = matrix_Eg_D ( 3 , 3 );
    EgD ( 4 ) = matrix_Eg_D ( 1 , 2 );
    EgD ( 5 ) = matrix_Eg_D ( 2 , 3 );
    EgD ( 6 ) = matrix_Eg_D ( 1 , 3 );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto E
    matrix_El_E = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em E -- Linha 1
    matrix_El_E ( 1 , 1 ) = ElE ( 1 );
    matrix_El_E ( 1 , 2 ) = ElE ( 4 );
    matrix_El_E ( 1 , 3 ) = ElE ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em E -- Linha 2
    matrix_El_E ( 2 , 1 ) = ElE ( 4 );
    matrix_El_E ( 2 , 2 ) = ElE ( 2 );
    matrix_El_E ( 2 , 3 ) = ElE ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em E -- Linha 3
    matrix_El_E ( 3 , 1 ) = ElE ( 6 );
    matrix_El_E ( 3 , 2 ) = ElE ( 5 );
    matrix_El_E ( 3 , 3 ) = ElE ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto E
    matrix_Eg_E = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_E * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em E
    EgE ( 1 ) = matrix_Eg_E ( 1 , 1 );
    EgE ( 2 ) = matrix_Eg_E ( 2 , 2 );
    EgE ( 3 ) = matrix_Eg_E ( 3 , 3 );
    EgE ( 4 ) = matrix_Eg_E ( 1 , 2 );
    EgE ( 5 ) = matrix_Eg_E ( 2 , 3 );
    EgE ( 6 ) = matrix_Eg_E ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto F
    matrix_El_F = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em F -- Linha 1
    matrix_El_F ( 1 , 1 ) = ElF ( 1 );
    matrix_El_F ( 1 , 2 ) = ElF ( 4 );
    matrix_El_F ( 1 , 3 ) = ElF ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em F -- Linha 2
    matrix_El_F ( 2 , 1 ) = ElF ( 4 );
    matrix_El_F ( 2 , 2 ) = ElF ( 2 );
    matrix_El_F ( 2 , 3 ) = ElF ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em F -- Linha 3
    matrix_El_F ( 3 , 1 ) = ElF ( 6 );
    matrix_El_F ( 3 , 2 ) = ElF ( 5 );
    matrix_El_F ( 3 , 3 ) = ElF ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto F
    matrix_Eg_F = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_F * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em F
    EgF ( 1 ) = matrix_Eg_F ( 1 , 1 );
    EgF ( 2 ) = matrix_Eg_F ( 2 , 2 );
    EgF ( 3 ) = matrix_Eg_F ( 3 , 3 );
    EgF ( 4 ) = matrix_Eg_F ( 1 , 2 );
    EgF ( 5 ) = matrix_Eg_F ( 2 , 3 );
    EgF ( 6 ) = matrix_Eg_F ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto G
    matrix_El_G = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em G -- Linha 1
    matrix_El_G ( 1 , 1 ) = ElG ( 1 );
    matrix_El_G ( 1 , 2 ) = ElG ( 4 );
    matrix_El_G ( 1 , 3 ) = ElG ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em G -- Linha 2
    matrix_El_G ( 2 , 1 ) = ElG ( 4 );
    matrix_El_G ( 2 , 2 ) = ElG ( 2 );
    matrix_El_G ( 2 , 3 ) = ElG ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em G -- Linha 3
    matrix_El_G ( 3 , 1 ) = ElG ( 6 );
    matrix_El_G ( 3 , 2 ) = ElG ( 5 );
    matrix_El_G ( 3 , 3 ) = ElG ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto G
    matrix_Eg_G = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_G * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em G
    EgG ( 1 ) = matrix_Eg_G ( 1 , 1 );
    EgG ( 2 ) = matrix_Eg_G ( 2 , 2 );
    EgG ( 3 ) = matrix_Eg_G ( 3 , 3 );
    EgG ( 4 ) = matrix_Eg_G ( 1 , 2 );
    EgG ( 5 ) = matrix_Eg_G ( 2 , 3 );
    EgG ( 6 ) = matrix_Eg_G ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM H %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto H
    matrix_El_H = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em H -- Linha 1
    matrix_El_H ( 1 , 1 ) = ElH ( 1 );
    matrix_El_H ( 1 , 2 ) = ElH ( 4 );
    matrix_El_H ( 1 , 3 ) = ElH ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em H -- Linha 2
    matrix_El_H ( 2 , 1 ) = ElH ( 4 );
    matrix_El_H ( 2 , 2 ) = ElH ( 2 );
    matrix_El_H ( 2 , 3 ) = ElH ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em H -- Linha 3
    matrix_El_H ( 3 , 1 ) = ElH ( 6 );
    matrix_El_H ( 3 , 2 ) = ElH ( 5 );
    matrix_El_H ( 3 , 3 ) = ElH ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em H %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto H
    matrix_Eg_H = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_H * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em H
    EgH ( 1 ) = matrix_Eg_H ( 1 , 1 );
    EgH ( 2 ) = matrix_Eg_H ( 2 , 2 );
    EgH ( 3 ) = matrix_Eg_H ( 3 , 3 );
    EgH ( 4 ) = matrix_Eg_H ( 1 , 2 );
    EgH ( 5 ) = matrix_Eg_H ( 2 , 3 );
    EgH ( 6 ) = matrix_Eg_H ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM I %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto I
    matrix_El_I = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em I -- Linha 1
    matrix_El_I ( 1 , 1 ) = ElI ( 1 );
    matrix_El_I ( 1 , 2 ) = ElI ( 4 );
    matrix_El_I ( 1 , 3 ) = ElI ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em I -- Linha 2
    matrix_El_I ( 2 , 1 ) = ElI ( 4 );
    matrix_El_I ( 2 , 2 ) = ElI ( 2 );
    matrix_El_I ( 2 , 3 ) = ElI ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em I -- Linha 3
    matrix_El_I ( 3 , 1 ) = ElI ( 6 );
    matrix_El_I ( 3 , 2 ) = ElI ( 5 );
    matrix_El_I ( 3 , 3 ) = ElI ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em I %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto I
    matrix_Eg_I = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_I * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em I
    EgI ( 1 ) = matrix_Eg_I ( 1 , 1 );
    EgI ( 2 ) = matrix_Eg_I ( 2 , 2 );
    EgI ( 3 ) = matrix_Eg_I ( 3 , 3 );
    EgI ( 4 ) = matrix_Eg_I ( 1 , 2 );
    EgI ( 5 ) = matrix_Eg_I ( 2 , 3 );
    EgI ( 6 ) = matrix_Eg_I ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM J %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto J
    matrix_El_J = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em J -- Linha 1
    matrix_El_J ( 1 , 1 ) = ElJ ( 1 );
    matrix_El_J ( 1 , 2 ) = ElJ ( 4 );
    matrix_El_J ( 1 , 3 ) = ElJ ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em J -- Linha 2
    matrix_El_J ( 2 , 1 ) = ElJ ( 4 );
    matrix_El_J ( 2 , 2 ) = ElJ ( 2 );
    matrix_El_J ( 2 , 3 ) = ElJ ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em J -- Linha 3
    matrix_El_J ( 3 , 1 ) = ElJ ( 6 );
    matrix_El_J ( 3 , 2 ) = ElJ ( 5 );
    matrix_El_J ( 3 , 3 ) = ElJ ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em J %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto J
    matrix_Eg_J = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_J * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em J
    EgJ ( 1 ) = matrix_Eg_J ( 1 , 1 );
    EgJ ( 2 ) = matrix_Eg_J ( 2 , 2 );
    EgJ ( 3 ) = matrix_Eg_J ( 3 , 3 );
    EgJ ( 4 ) = matrix_Eg_J ( 1 , 2 );
    EgJ ( 5 ) = matrix_Eg_J ( 2 , 3 );
    EgJ ( 6 ) = matrix_Eg_J ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM K %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto K
    matrix_El_K = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em K -- Linha 1
    matrix_El_K ( 1 , 1 ) = ElK ( 1 );
    matrix_El_K ( 1 , 2 ) = ElK ( 4 );
    matrix_El_K ( 1 , 3 ) = ElK ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em K -- Linha 2
    matrix_El_K ( 2 , 1 ) = ElK ( 4 );
    matrix_El_K ( 2 , 2 ) = ElK ( 2 );
    matrix_El_K ( 2 , 3 ) = ElK ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em K -- Linha 3
    matrix_El_K ( 3 , 1 ) = ElK ( 6 );
    matrix_El_K ( 3 , 2 ) = ElK ( 5 );
    matrix_El_K ( 3 , 3 ) = ElK ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em K %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto K
    matrix_Eg_K = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_K * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em K
    EgK ( 1 ) = matrix_Eg_K ( 1 , 1 );
    EgK ( 2 ) = matrix_Eg_K ( 2 , 2 );
    EgK ( 3 ) = matrix_Eg_K ( 3 , 3 );
    EgK ( 4 ) = matrix_Eg_K ( 1 , 2 );
    EgK ( 5 ) = matrix_Eg_K ( 2 , 3 );
    EgK ( 6 ) = matrix_Eg_K ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM L %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto L
    matrix_El_L = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em L -- Linha 1
    matrix_El_L ( 1 , 1 ) = ElL ( 1 );
    matrix_El_L ( 1 , 2 ) = ElL ( 4 );
    matrix_El_L ( 1 , 3 ) = ElL ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em L -- Linha 2
    matrix_El_L ( 2 , 1 ) = ElL ( 4 );
    matrix_El_L ( 2 , 2 ) = ElL ( 2 );
    matrix_El_L ( 2 , 3 ) = ElL ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em L -- Linha 3
    matrix_El_L ( 3 , 1 ) = ElL ( 6 );
    matrix_El_L ( 3 , 2 ) = ElL ( 5 );
    matrix_El_L ( 3 , 3 ) = ElL ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em L %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto L
    matrix_Eg_L = transpose ( R ( 1:3 , 1:3 ) ) * matrix_El_L * R ( 1:3 , 1:3 );
    
    % Aloca��o no Vetor de Deforma��es Globais em L
    EgL ( 1 ) = matrix_Eg_L ( 1 , 1 );
    EgL ( 2 ) = matrix_Eg_L ( 2 , 2 );
    EgL ( 3 ) = matrix_Eg_L ( 3 , 3 );
    EgL ( 4 ) = matrix_Eg_L ( 1 , 2 );
    EgL ( 5 ) = matrix_Eg_L ( 2 , 3 );
    EgL ( 6 ) = matrix_Eg_L ( 1 , 3 );
    
end

