%% Cria��o do Vetor de Deslocamentos Nodais Globais do Elemento Beam2

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% i                 - Posi��o i do Elemento

%% OUTPUT
% Ug                - Vetor de Deslocamentos Nodais Globais do Elemento

%% Declara��o da Fun��o de Cria��o do Vetor de Deslocamentos Nodais Globais do Elemento Beam2
function [ Ug ] = vector_Ug_beam2 ( Node_Param , Elem_Param , i )    

    % Inicializa��o do Vetor de Deslocamento Nodais Globais
    Ug = zeros ( 12 , 1 );
    
    % Varredura nos N�s do Elemento
    for j = 1:2
    
        % Id do N�
        Node_Id = Elem_Param ( i ).node ( j );
        
        % Aloca��o dos Deslocamentos Nodais
        Ug ( 6 * j - 5 ) = Node_Param ( Node_Id ).disp ( 1 );
        Ug ( 6 * j - 4 ) = Node_Param ( Node_Id ).disp ( 2 );
        Ug ( 6 * j - 3 ) = Node_Param ( Node_Id ).disp ( 3 );
        Ug ( 6 * j - 2 ) = Node_Param ( Node_Id ).disp ( 4 );
        Ug ( 6 * j - 1 ) = Node_Param ( Node_Id ).disp ( 5 );
        Ug ( 6 * j - 0 ) = Node_Param ( Node_Id ).disp ( 6 );
    
    end      
        
end

