%% Cria��o do Vetor de Deslocamentos Nodais Locais do Elemento Beam2

%% INPUT
% R                 - Matriz de Rota��o do Elemento
% Ug                - Vetor de Deslocamentos Nodais Globais do Elemento

%% OUTPUT
% Ul                - Vetor de Deslocamentos Nodais Locais do Elemento

%% Declara��o da Fun��o de Cria��o do Vetor de Deslocamentos Nodais Locais do Elemento Beam2
function [ Ul ] = vector_Ul_beam2 ( R , Ug )    

    % Inicializa��o do Vetor de Deslocamento Nodais Locais
    Ul = R * Ug;    
        
end

