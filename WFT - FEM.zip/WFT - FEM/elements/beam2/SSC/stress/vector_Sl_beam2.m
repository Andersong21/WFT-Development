%% Cria��o do Vetor de Tens�es Locais do Elemento Beam2

%% INPUT
% Ba                - Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2
% By                - Matriz de Correla��o Deslocamento Deforma��o de Flex�o YY do Elemento Beam2
% Bz                - Matriz de Correla��o Deslocamento Deforma��o de Flex�o ZZ do Elemento Beam2
% Bt                - Matriz de Correla��o Deslocamento Deforma��o de Tor��o do Elemento Beam2
% Ul                - Vetor de Deslocamento Nodais Locais do Elemento
% b                 - Base do Elemento no Ponto de Coordenada Natural e
% h                 - Altura do Elemento no Ponto de Coordenada Natural e
% E                 - M�dulo de Elasticidade do Elemento
% G                 - M�dulo de Elasticidade Transversal do Elemento
% local             - Local de C�lculo das Tens�es na Viga
%                   - [ C ] = Canto
%                   - [ E ] = Extremidade  

%% OUTPUT
% SlA               - Vetor de Tens�es Locais no Ponto A
% SlB               - Vetor de Tens�es Locais no Ponto B
% SlC               - Vetor de Tens�es Locais no Ponto C
% SlD               - Vetor de Tens�es Locais no Ponto D

%% Declara��o da Fun��o de Cria��o Vetor de Tens�es Locais do Elemento Beam2
function [ SlA , SlB , SlC , SlD ] = vector_Sl_beam2 ( Ba , Bfz , Bfy , Bt , Ul ,  b , h , E , G , local )

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS GEOM�TRICOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Momento de In�rcia Izz
    Iy = h * b * b * b / 12;

    % Momento de In�rcia Iyy
    Iz = b * h * h * h / 12;
    
    % Momento Polar de Inercia
    if ( b < h )
        
        % Momento Polar de In�rcia
        J = 0.141 * h * b * b * b;
        
    else
        
        % Momento Polar de In�rcia
        J = 0.141 * b * h * h * h;
        
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Axial
    Ula = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Axial
    Ula ( 1 , 1 ) = Ul ( 1  , 1 );
    Ula ( 2 , 1 ) = Ul ( 7  , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o YY
    Uly = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o YY
    Uly ( 1 , 1 ) = Ul ( 3  , 1 );
    Uly ( 2 , 1 ) = Ul ( 5  , 1 );
    Uly ( 3 , 1 ) = Ul ( 9  , 1 );
    Uly ( 4 , 1 ) = Ul ( 11 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o ZZ
    Ulz = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o ZZ
    Ulz ( 1 , 1 ) = Ul ( 2  , 1 );
    Ulz ( 2 , 1 ) = Ul ( 6  , 1 );
    Ulz ( 3 , 1 ) = Ul ( 8  , 1 );
    Ulz ( 4 , 1 ) = Ul ( 12 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Tor��o
    Ult = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Tor��o
    Ult ( 1 , 1 ) = Ul ( 4  , 1 );
    Ult ( 2 , 1 ) = Ul ( 10 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO TENS�ES CANTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Tens�o Canto
    if ( strcmp ( local , 'C' ) == 1 )
     
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = + b / 2;
        zl = + h / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto A
        S_axial_A = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto A
        M_fy_A = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto A
        S_fy_A = ( M_fy_A * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto A
        M_fz_A = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto A
        S_fz_A = ( M_fz_A * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto A
        M_ft_A = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto A
        S_ft_A = ( M_ft_A * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto A
        SlA ( 1 ) = S_axial_A ( 1 ) + S_fy_A ( 1 ) + S_fz_A ( 1 );
        SlA ( 2 ) = 0;
        SlA ( 3 ) = 0;
        SlA ( 4 ) = S_ft_A ( 1 );
        SlA ( 5 ) = 0;
        SlA ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = - b / 2;
        zl = + h / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto B
        S_axial_B = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto B
        M_fy_B = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto B
        S_fy_B = ( M_fy_B * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto B
        M_fz_B = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto B
        S_fz_B = ( M_fz_B * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto B
        M_ft_B = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto B
        S_ft_B = ( M_ft_B * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto B
        SlB ( 1 ) = S_axial_B ( 1 ) + S_fy_B ( 1 ) + S_fz_B ( 1 );
        SlB ( 2 ) = 0;
        SlB ( 3 ) = 0;
        SlB ( 4 ) = S_ft_B ( 1 );
        SlB ( 5 ) = 0;
        SlB ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - b / 2;
        zl = - h / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto C
        S_axial_C = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto C
        M_fy_C = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto C
        S_fy_C = ( M_fy_C * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto C
        M_fz_C = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto C
        S_fz_C = ( M_fz_C * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto C
        M_ft_C = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto C
        S_ft_C = ( M_ft_C * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto C
        SlC ( 1 ) = S_axial_C ( 1 ) + S_fy_C ( 1 ) + S_fz_C ( 1 );
        SlC ( 2 ) = 0;
        SlC ( 3 ) = 0;
        SlC ( 4 ) = S_ft_C ( 1 );
        SlC ( 5 ) = 0;
        SlC ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = + b / 2;
        zl = - h / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto D
        S_axial_D = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto D
        M_fy_D = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto D
        S_fy_D = ( M_fy_D * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto D
        M_fz_D = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto D
        S_fz_D = ( M_fz_D * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto D
        M_ft_D = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto D
        S_ft_D = ( M_ft_D * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto D
        SlD ( 1 ) = S_axial_D ( 1 ) + S_fy_D ( 1 ) + S_fz_D ( 1 );
        SlD ( 2 ) = 0;
        SlD ( 3 ) = 0;
        SlD ( 4 ) = S_ft_D ( 1 );
        SlD ( 5 ) = 0;
        SlD ( 6 ) = 0;       
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO TENS�ES EXTREMIDADE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Tens�o Extremidade
    if ( strcmp ( local , 'E' ) == 1 )
     
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = 0;
        zl = + h / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto A
        S_axial_A = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto A
        M_fy_A = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto A
        S_fy_A = ( M_fy_A * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto A
        M_fz_A = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto A
        S_fz_A = ( M_fz_A * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto A
        M_ft_A = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto A
        S_ft_A = ( M_ft_A * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto A
        SlA ( 1 ) = S_axial_A ( 1 ) + S_fy_A ( 1 ) + S_fz_A ( 1 );
        SlA ( 2 ) = 0;
        SlA ( 3 ) = 0;
        SlA ( 4 ) = S_ft_A ( 1 );
        SlA ( 5 ) = 0;
        SlA ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = + b / 2;
        zl = 0;

        % Determina��o do Vetor de Tens�es Axiais do Ponto B
        S_axial_B = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto B
        M_fy_B = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto B
        S_fy_B = ( M_fy_B * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto B
        M_fz_B = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto B
        S_fz_B = ( M_fz_B * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto B
        M_ft_B = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto B
        S_ft_B = ( M_ft_B * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto B
        SlB ( 1 ) = S_axial_B ( 1 ) + S_fy_B ( 1 ) + S_fz_B ( 1 );
        SlB ( 2 ) = 0;
        SlB ( 3 ) = 0;
        SlB ( 4 ) = S_ft_B ( 1 );
        SlB ( 5 ) = 0;
        SlB ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = 0;
        zl = - h / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto C
        S_axial_C = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto C
        M_fy_C = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto C
        S_fy_C = ( M_fy_C * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto C
        M_fz_C = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto C
        S_fz_C = ( M_fz_C * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto C
        M_ft_C = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto C
        S_ft_C = ( M_ft_C * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto C
        SlC ( 1 ) = S_axial_C ( 1 ) + S_fy_C ( 1 ) + S_fz_C ( 1 );
        SlC ( 2 ) = 0;
        SlC ( 3 ) = 0;
        SlC ( 4 ) = S_ft_C ( 1 );
        SlC ( 5 ) = 0;
        SlC ( 6 ) = 0;
        
        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = - b / 2;
        zl = 0;

        % Determina��o do Vetor de Tens�es Axiais do Ponto D
        S_axial_D = E * Ba * Ula;
        
        % Determina��o do Vetor de Momento de Flex�o YY do Ponto D
        M_fy_D = - E * Iy * ( Bfy * Uly );
        
        % Determina��o do Vetor de Tens�es de Flex�o YY do Ponto D
        S_fy_D = ( M_fy_D * zl ) / Iy;
        
        % Determina��o do Vetor de Momento de Flex�o ZZ do Ponto D
        M_fz_D = - E * Iz * ( Bfz * Ulz );
        
        % Determina��o do Vetor de Tens�es de Flex�o ZZ do Ponto D
        S_fz_D = ( M_fz_D * yl ) / Iz;
        
        % Determina��o do Vetor de Momento de Tor��o do Ponto D
        M_ft_D = - G * J * ( ( Bt * Ult ) / 2.0 ); 

        % Determina��o do Vetor de Tens�es de Tor��o do Ponto D
        S_ft_D = ( M_ft_D * sqrt ( ( yl^2 ) + ( zl^2 ) ) ) / J;

        % Vetor de Tens�es Locais do Ponto D
        SlD ( 1 ) = S_axial_D ( 1 ) + S_fy_D ( 1 ) + S_fz_D ( 1 );
        SlD ( 2 ) = 0;
        SlD ( 3 ) = 0;
        SlD ( 4 ) = S_ft_D ( 1 );
        SlD ( 5 ) = 0;
        SlD ( 6 ) = 0;        
        
    end
    
end