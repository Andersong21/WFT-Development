%% Cria��o do Vetor de For�as Locais do Elemento Beam2

%% INPUT
% B                 - Matriz de Correla��o Deslocamento For�a do Elemento Beam2
% D                 - Matriz Constitutiva do Elemento Beam2
% Ul                - Vetor de Deslocamento Nodais Locais do Elemento
% local             - Local de C�lculo das Deforma��es na Viga
%                   - [ C ] = Canto
%                   - [ E ] = Extremidade    

%% OUTPUT
% FlA               - Vetor de For�as Locais no Ponto A
% FlB               - Vetor de For�as Locais no Ponto B
% FlC               - Vetor de For�as Locais no Ponto C
% FlD               - Vetor de For�as Locais no Ponto D

%% Declara��o da Fun��o de Cria��o Vetor de For�as Locais do Elemento Beam2
function [ FlA , FlB , FlC , FlD ] = vector_Fl_beam2 ( B , Ul , D , local )

    %%%%%%%%%%%%%%%%%%%%%%
    % FOR�AS NO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%
    
    % For�a no N� do Elemento
    F_elem = D * B * Ul;
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO FOR�AS CANTO %
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    % For�a Canto
    if ( strcmp ( local , 'C' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%
        
        % Determina��o da For�a Axial do Ponto A
        FlA ( 1 ) = + F_elem ( 1 );
        
        % Determina��o da For�a de Flex�o ZZ do Ponto A
        FlA ( 2 ) = - F_elem ( 2 );
        
        % Determina��o da For�a de Flex�o YY do Ponto A
        FlA ( 3 ) = - F_elem ( 3 );

        % Determina��o do Vetor de Deforma��es Axiais do Ponto A
        FlA ( 4 ) = - F_elem ( 4 );        

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto B
        FlB ( 1 ) = + F_elem ( 1 );

        % Determina��o da For�a de Flex�o ZZ do Ponto B
        FlB ( 2 ) = + F_elem ( 2 );
        
        % Determina��o da For�a de Flex�o YY do Ponto B
        FlB ( 3 ) = - F_elem ( 3 );

        % Determina��o do Vetor de Deforma��es Axiais do Ponto B
        FlB ( 4 ) = - F_elem ( 4 );

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto C
        FlC ( 1 ) = + F_elem ( 1 );

        % Determina��o da For�a de Flex�o ZZ do Ponto C
        FlC ( 2 ) = + F_elem ( 2 );
        
        % Determina��o da For�a de Flex�o YY do Ponto C
        FlC ( 3 ) = + F_elem ( 3 );

        % Determina��o do Vetor de Deforma��es Axiais do Ponto C
        FlC ( 4 ) = - F_elem ( 4 );

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto D
        FlD ( 1 ) = + F_elem ( 1 );

        % Determina��o da For�a de Flex�o ZZ do Ponto D
        FlD ( 2 ) = - F_elem ( 2 );
        
        % Determina��o da For�a de Flex�o YY do Ponto D
        FlD ( 3 ) = + F_elem ( 3 );

        % Determina��o do Vetor de Deforma��es Axiais do Ponto D
        FlD ( 4 ) = - F_elem ( 4 );
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO FOR�A EXTREMIDADE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % For�a Extremidade
    if ( strcmp ( local , 'E' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto A
        FlA ( 1 ) = + F_elem ( 1 );
        
        % Determina��o da For�a de Flex�o ZZ do Ponto A
        FlA ( 2 ) =   0.0;
        
        % Determina��o da For�a de Flex�o YY do Ponto A
        FlA ( 3 ) = - F_elem ( 3 );

        % Determina��o do Vetor de Deforma��es Axiais do Ponto A
        FlA ( 4 ) = - F_elem ( 4 );

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto B
        FlB ( 1 ) = + F_elem ( 1 );

        % Determina��o da For�a de Flex�o ZZ do Ponto B
        FlB ( 2 ) = + F_elem ( 2 );
        
        % Determina��o da For�a de Flex�o YY do Ponto B
        FlB ( 3 ) =   0.0;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto B
        FlB ( 4 ) = - F_elem ( 4 );

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto C
        FlC ( 1 ) = + F_elem ( 1 );

        % Determina��o da For�a de Flex�o ZZ do Ponto C
        FlC ( 2 ) =   0.0;
        
        % Determina��o da For�a de Flex�o YY do Ponto C
        FlC ( 3 ) = + F_elem ( 3 );

        % Determina��o do Vetor de Deforma��es Axiais do Ponto C
        FlC ( 4 ) = - F_elem ( 4 );

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Determina��o da For�a Axial do Ponto D
        FlD ( 1 ) = + F_elem ( 1 );

        % Determina��o da For�a de Flex�o ZZ do Ponto D
        FlD ( 2 ) = - F_elem ( 2 );
        
        % Determina��o da For�a de Flex�o YY do Ponto D
        FlD ( 3 ) =   0.0;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto D
        FlD ( 4 ) = - F_elem ( 4 );
        
    end    
    
end

