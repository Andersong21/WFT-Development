%% Cria��o da Estrutura de Deforma��es e Tens�es do Elemento Beam2

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Elemento i

%% OUTPUT
% Ei                - Vetor de Deforma��es do Elemento i
% Si                - Vetor de Tens�es do Elemento i

%% Declara��o da Fun��o de Cria��o da Estrutura de Tens�es do Elemento Beam2
function [ Ei , Si ] = strain_stress_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno das Defini��es Iniciais da Propriedade
    [ b , h ] = get_section_param ( Elem_Param , Prop_Param , i );
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_beam2 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_beam2 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_beam2 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva do Elemento
    [ E , G ] = matrix_D_beam2 ( Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Globais do Elemento
    [ Ug ] = vector_Ug_beam2 ( Node_Param , Elem_Param , i );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS NODAIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Locais do Elemento
    [ Ul ] = vector_Ul_beam2 ( R , Ug );
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COORDENADAS NATURAIS DOS N�S %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Posi��o X no elemento
    x = ( Cl ( 2 , 1 ) - Cl ( 1 , 1 ) ) / 2.0;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
    [ Ba , Bfz , Bfy , Bt ] = matrix_B_beam2 ( x , Cl );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Deforma��es Locais do Elemento
    [ ElA , ElB , ElC , ElD , ElE , ElF , ElG , ElH , ElI , ElJ , ElK , ElL ] = vector_El_beam2 ( Ba , Bfz , Bfy , Bt , Ul , b , h , 'C' );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Tens�es Locais do Elemento
    [ SlA , SlB , SlC , SlD ] = vector_Sl_beam2 ( Ba , Bfz , Bfy , Bt , Ul ,  b , h , E , G , 'C' );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Deforma��es Globais do Elemento
    [ EgA , EgB , EgC , EgD ] = vector_Eg_beam2 ( ElA , ElB , ElC , ElD , ElE , ElF , ElG , ElH , ElI , ElJ , ElK , ElL , R );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Tens�es Globais do Elemento
    [ SgA , SgB , SgC , SgD ] = vector_Sg_beam2 ( SlA , SlB , SlC , SlD , R );
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O NA ESTRUTURA DE DADOS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o na Estrutura de Deforma��es do Elemento
    Ei = [ EgA , EgB , EgC , EgD ];
    
    % Aloca��o na Estrutura de Tens�es do Elemento
    Si = [ SgA , SgB , SgC , SgD ];
   
end

