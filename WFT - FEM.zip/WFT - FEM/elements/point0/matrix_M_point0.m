%% Cria��o da Matriz de Massa do Elemento Concentrado

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% i                 - Elemento i

%% OUTPUT
% Mi                - Termo i da Matriz de Massa Global
% Mj                - Termo j da Matriz de Massa Global
% Mv                - Valor ( i , j ) da Matriz de Massa Global

%% Declara��o da Fun��o de Cria��o da Matriz de Massa do Elemento
function [ Mi , Mj , Mv ] = matrix_M_point0 ( Node_Param , Elem_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa
    Mg = zeros ( 6 , 6 );
    
    % Aloca��o dos Termos da Matriz de Massa
    Mg ( 1 , 1 ) = Elem_Param ( i ).mass;
    Mg ( 2 , 2 ) = Elem_Param ( i ).mass;
    Mg ( 3 , 3 ) = Elem_Param ( i ).mass;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE GRAUS DE LIBERDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador de Graus de Liberdade do Elemento
    Ndof = 1;
    
    % Inicializa��o do Vetor de Graus de Liberdade
    DOF = zeros ( 6 , 1 );
    
    % Varredura nos N�s do Elemento
    for j = 1:length( Elem_Param ( i ).node )
       
        % Id do N�
        Idn = Elem_Param ( i ).node ( j );
        
        % Varredura nos Graus de Liberdade dos N�s do Elemento
        for k = 1:length ( Node_Param ( Idn ).dof )            
            
            % Aloca��o no Vetor de Graus de Liberdade
            DOF ( Ndof ) = Node_Param ( Idn ).dof ( k );
            
            % Incremento na Contagem de Graus de Liberdade
            Ndof = Ndof + 1;
            
        end         
        
    end
    
    % Inicializa��o do Contador
    cont = 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o na Matriz de Massa Global do Problema
    for j = 1:6
        
        % Verifica��o se o Grau de Liberdade � nulo
        if ( DOF ( j ) == 0 )
            
            % Continuar
            continue;
            
        else      

            % Aloca��o dos Termos da Matriz na Posi��o Global
            Mi ( cont ) = DOF ( j );
            Mj ( cont ) = DOF ( j );
            Mv ( cont ) = Mg ( j , j );

            % Incremento do Contador
            cont = cont + 1;
            
        end

    end 
    
end

