%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% J                 - Matriz Jacobiana do Elemento

%% OUTPUT
% Bm                - Matriz de Correla��o Deslocamento Deforma��o de Membrana do Elemento Quad4
% Bb                - Matriz de Correla��o Deslocamento Deforma��o de Flex�o do Elemento Quad4
% Bs                - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o do Elemento Quad4
function [ Bm , Bb , Bs ] = matrix_B_quad4 ( e , n , J )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO DA MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o A
    A = zeros ( 3 , 4 );
    
    % Aloca��o dos Termos na Matriz A -- LINHA 1
    A ( 1 , 1 ) = + J ( 2 , 2 );
    A ( 1 , 2 ) = - J ( 1 , 2 );
    
    % Aloca��o dos Termos na Matriz A -- LINHA 2
    A ( 2 , 3 ) = - J ( 2 , 1 );
    A ( 2 , 4 ) = + J ( 1 , 1 );
    
    % Aloca��o dos Termos na Matriz A -- LINHA 3
    A ( 3 , 1 ) = - J ( 2 , 1 );
    A ( 3 , 2 ) = + J ( 1 , 1 );
    A ( 3 , 3 ) = + J ( 2 , 2 );
    A ( 3 , 4 ) = - J ( 1 , 2 );
    
    % Multiplica��o pelo Determinante do Jacobiana
    A = ( 1 / det ( J ) ) * A;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4;
    
    % Inicializa��o da Matriz das Derivadas das Fun��es de Forma
    DN = zeros ( 4 , 8 );
    
    % Aloca��o das Derivadas das Fun��es de Forma -- LINHA 1
    DN ( 1 , 1 ) = DN1e;
    DN ( 1 , 3 ) = DN2e;
    DN ( 1 , 5 ) = DN3e;
    DN ( 1 , 7 ) = DN4e;
    
    % Aloca��o das Derivadas das Fun��es de Forma -- LINHA 2    
    DN ( 2 , 1 ) = DN1n;
    DN ( 2 , 3 ) = DN2n;
    DN ( 2 , 5 ) = DN3n;
    DN ( 2 , 7 ) = DN4n;
    
    % Aloca��o das Derivadas das Fun��es de Forma -- LINHA 3
    DN ( 3 , 2 ) = DN1e;
    DN ( 3 , 4 ) = DN2e;
    DN ( 3 , 6 ) = DN3e;
    DN ( 3 , 8 ) = DN4e;
    
    % Aloca��o das Derivadas das Fun��es de Forma -- LINHA 4
    DN ( 4 , 2 ) = DN1n;
    DN ( 4 , 4 ) = DN2n;
    DN ( 4 , 6 ) = DN3n;
    DN ( 4 , 8 ) = DN4n;
    
    % Determina��o da Matriz de Correla��o Bm
    Bm  = A * DN;   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % Defini��o da Inversa da Matriz Jacobiana
    invJ = inv ( J );
    
    % Derivadas das Fun��es de Forma em Rela��o a X
    DN1x = ( DN1e * invJ ( 1 , 1 ) ) + ( DN1n * invJ ( 1 , 2 ) );
    DN2x = ( DN2e * invJ ( 1 , 1 ) ) + ( DN2n * invJ ( 1 , 2 ) );
    DN3x = ( DN3e * invJ ( 1 , 1 ) ) + ( DN3n * invJ ( 1 , 2 ) );
    DN4x = ( DN4e * invJ ( 1 , 1 ) ) + ( DN4n * invJ ( 1 , 2 ) );
    
    % Derivadas das Fun��es de Forma em Rela��o a Y
    DN1y = ( DN1e * invJ ( 2 , 1 ) ) + ( DN1n * invJ ( 2 , 2 ) );
    DN2y = ( DN2e * invJ ( 2 , 1 ) ) + ( DN2n * invJ ( 2 , 2 ) );
    DN3y = ( DN3e * invJ ( 2 , 1 ) ) + ( DN3n * invJ ( 2 , 2 ) );
    DN4y = ( DN4e * invJ ( 2 , 1 ) ) + ( DN4n * invJ ( 2 , 2 ) );
        
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento de Flex�o
    Bb = zeros ( 3 , 12 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Flex�o -- LINHA 1
    Bb ( 1 , 3  ) = + DN1x;
    Bb ( 1 , 6  ) = + DN2x;
    Bb ( 1 , 9  ) = + DN3x;
    Bb ( 1 , 12 ) = + DN4x;
    
    % Aloca��o dos Termos na Matriz de Correla��o de Flex�o -- LINHA 2
    Bb ( 2 , 2  ) = - DN1y;
    Bb ( 2 , 5  ) = - DN2y;
    Bb ( 2 , 8  ) = - DN3y;
    Bb ( 2 , 11 ) = - DN4y;
    
    % Aloca��o dos Termos na Matriz de Correla��o de Flex�o -- LINHA 3
    Bb ( 3 , 2  ) = - DN1x;
    Bb ( 3 , 3  ) = + DN1y;
    Bb ( 3 , 5  ) = - DN2x;
    Bb ( 3 , 6  ) = + DN2y;
    Bb ( 3 , 8  ) = - DN3x;
    Bb ( 3 , 9  ) = + DN3y;
    Bb ( 3 , 11 ) = - DN4x;
    Bb ( 3 , 12 ) = + DN4y;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO DE CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Defini��o das Fun��es de Forma do Elemento
    N1 = + ( 1 / 4 ) * ( 1 - e ) * ( 1 - n );
    N2 = + ( 1 / 4 ) * ( 1 + e ) * ( 1 - n );
    N3 = + ( 1 / 4 ) * ( 1 + e ) * ( 1 + n );
    N4 = + ( 1 / 4 ) * ( 1 - e ) * ( 1 + n );    
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento de Cisalhamento
    Bs = zeros ( 2 , 12 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Cisalhamento -- LINHA 1
    Bs ( 1 , 1  ) = + DN1x;
    Bs ( 1 , 3  ) = + N1;
    Bs ( 1 , 4  ) = + DN2x;
    Bs ( 1 , 6  ) = + N2;
    Bs ( 1 , 7  ) = + DN3x;
    Bs ( 1 , 9  ) = + N3;
    Bs ( 1 , 10 ) = + DN4x;
    Bs ( 1 , 12 ) = + N4;
    
    % Aloca��o dos Termos na Matriz de Correla��o de Cisalhamento -- LINHA 2
    Bs ( 2 , 1  ) = + DN1y;
    Bs ( 2 , 2  ) = - N1;
    Bs ( 2 , 4  ) = + DN2y;
    Bs ( 2 , 5  ) = - N2;
    Bs ( 2 , 7  ) = + DN3y;
    Bs ( 2 , 8  ) = - N3;
    Bs ( 2 , 10 ) = + DN4y;
    Bs ( 2 , 11 ) = - N4;
       
end

