%% Cria��o da Matriz de Transforma��o de Coordenadas do Elemento Quad4

%% INPUT
% Cg                - Matriz das Coordenadas Globais do Elemento Quad4

%% OUTPUT
% R                 - Matriz de Transforma��o de Coordenadas do Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Transforma��o de Coordenadas do Elemento Quad4
function [ R ] = matrix_R_quad4 ( Cg )
   
    % Inicializa��o do Vetor v1
    v1 = zeros ( 3 , 1 );
    
    % Inicializa��o do Vetor v2
    v2 = zeros ( 3 , 1 );
    
    % Defini��o do Vetor v1
    v1 ( 1 ) = Cg ( 2 , 1 ) - Cg ( 1 , 1 );
    v1 ( 2 ) = Cg ( 2 , 2 ) - Cg ( 1 , 2 );
    v1 ( 3 ) = Cg ( 2 , 3 ) - Cg ( 1 , 3 );
    
    % Defini��o do Vetor v2
    v2 ( 1 ) = Cg ( 4 , 1 ) - Cg ( 1 , 1 );
    v2 ( 2 ) = Cg ( 4 , 2 ) - Cg ( 1 , 2 );
    v2 ( 3 ) = Cg ( 4 , 3 ) - Cg ( 1 , 3 );
    
    % Defini�ao do Versor n1
    n1 = v1 / norm( v1 );
    
    % Defini�ao do Versor n2
    n2 = v2 / norm( v2 );
    
    % Defini��o do Versor n3
    n3 = cross ( n1 , n2 );
    
    % Defini��o da Matriz de Transforma��o Translacional
    T = [ n1 , n2 , n3 ];
    
    % Defini��o da Matriz de Transforma��o Nodal
    TT = blkdiag ( T , T );
    
    % Defini��o da Matriz de Transforma��o do Elemento
    R = blkdiag ( TT , TT , TT , TT );     
        
end

