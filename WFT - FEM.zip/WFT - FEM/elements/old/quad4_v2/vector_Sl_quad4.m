%% Cria��o do Vetor de Tens�es Locais do Elemento Quad4

%% INPUT
% ElE               - Vetor de Deforma��es Locais no Layer E
% ElF               - Vetor de Deforma��es Locais no Layer F
% ElG               - Vetor de Deforma��es Locais no Layer G
% Dm                - Matriz Constitutiva de Membrana do Elemento Quad4
% Db                - Matriz Constitutiva de Flex�o do Elemento Quad4
% Ds                - Matriz Constitutiva de Cisalhamento do Elemento Quad4
% t                 - Espessura do Elemento

%% OUTPUT
% SlE               - Vetor de Tens�es Locais no Layer E
% SlF               - Vetor de Tens�es Locais no Layer F
% SlG               - Vetor de Tens�es Locais no Layer G

%% Declara��o da Fun��o de Cria��o Vetor de Tens�es Locais do Elemento Quad4
function [ SlE , SlF , SlG ] = vector_Sl_quad4 ( ElE , ElF , ElG , Dm , Db , Ds , t )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES % MEMBRANA % LAYER E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deforma��es Locais de Membrana
    Elm = zeros ( 3 , 1 );
    
    % Aloca��o dos Termos no Vetor de Deforma��es Locais de Membrana
    Elm ( 1 ) = ElE ( 1 );
    Elm ( 2 ) = ElE ( 2 );
    Elm ( 3 ) = ElE ( 4 ) * 2.0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES % CISALHAMENTO % LAYER E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deforma��es Locais de Cisalhamento Layer E
    Elm2 = zeros ( 2 , 1 );
    
    % Aloca��o dos Termos no Vetor de Deforma��es Locais de Cisalhamento Layer E 
    Elm2 ( 1 ) = ElE ( 6 );
    Elm2 ( 2 ) = ElE ( 5 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES % FLEX�O % LAYER F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deforma��es Locais de Flex�o Layer F
    Elb1 = zeros ( 3 , 1 );
    
    % Aloca��o dos Termos no Vetor de Deforma��es Locais de Flex�o Layer F
    Elb1 ( 1 ) = ElF ( 1 );
    Elb1 ( 2 ) = ElF ( 2 );
    Elb1 ( 3 ) = ElF ( 4 );     
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES % FLEX�O % LAYER G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deforma��es Locais de Flex�o Layer G
    Elb2 = zeros ( 3 , 1 );
    
    % Aloca��o dos Termos no Vetor de Deforma��es Locais de Flex�o Layer G
    Elb2 ( 1 ) = ElG ( 1 );
    Elb2 ( 2 ) = ElG ( 2 );
    Elb2 ( 3 ) = ElG ( 4 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES % MEMBRANA % LAYER E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Tens�es Locais de Membrana
    Slm = Dm * Elm;
    
    % Vetor de For�as de Cisalhamento -- Membrana
    F1m = Ds * Elm2;
    
    % Aloca��o no Vetor de Tens�es Locais -- Layer E
    SlE ( 1 ) = Slm ( 1 );
    SlE ( 2 ) = Slm ( 2 );
    SlE ( 3 ) = 0;
    SlE ( 4 ) = Slm ( 3 );
    SlE ( 5 ) = ( 3 * F1m ( 2 ) ) / ( 2 * t );
    SlE ( 6 ) = ( 3 * F1m ( 1 ) ) / ( 2 * t );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES % FLEX�O % LAYER F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Momentos de Flex�o -- Layer F
    M1b1 = Db * Elb1;   
    
    % Aloca��o no Vetor de Tens�es Locais -- Layer F
    SlF ( 1 ) = 6 * M1b1 ( 1 ) / ( t * t );
    SlF ( 2 ) = 6 * M1b1 ( 2 ) / ( t * t );
    SlF ( 3 ) = 0;
    SlF ( 4 ) = 6 * M1b1 ( 3 ) / ( t * t );
    SlF ( 5 ) = ( 3 * F1m ( 2 ) ) / ( 2 * t );
    SlF ( 6 ) = ( 3 * F1m ( 2 ) ) / ( 2 * t );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES % FLEX�O % LAYER G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetro de Momentos de Flex�o -- Layer G
    M1b2 = Db * Elb2;
    
    % Aloca��o no Vetor de Tens�es Locais -- Layer G
    SlG ( 1 ) = 6 * M1b2 ( 1 ) / ( t * t );
    SlG ( 2 ) = 6 * M1b2 ( 2 ) / ( t * t );
    SlG ( 3 ) = 0;
    SlG ( 4 ) = 6 * M1b2 ( 3 ) / ( t * t );
    SlG ( 5 ) = ( 3 * F1m ( 2 ) ) / ( 2 * t );
    SlG ( 6 ) = ( 3 * F1m ( 1 ) ) / ( 2 * t );   
    
end

