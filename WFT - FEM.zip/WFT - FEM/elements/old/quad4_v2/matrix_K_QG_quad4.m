%% Cria��o da Matriz de Rigidez do Elemento Quad4 no Ponto da Quadratura de Gauss

%% INPUT
% t                 - Espessura do Elemento
% Jm                - Matriz Jacobiana do Elemento -- Membrana
% Jb                - Matriz Jacobiana do Elemento -- Placa
% Bm                - Matriz de Correla��o Deforma��o Deslocamento de Membrana do Elemento Quad4
% Bb                - Matriz de Correla��o Deforma��o Deslocamento de Flex�o do Elemento Quad4
% Bs                - Matriz de Correla��o Deforma��o Deslocamento de Cisalhamento do Elemento Quad4
% Dm                - Matriz Constitutiva de Membrana do Elemento Quad4
% Db                - Matriz Constitutiva de Flex�o do Elemento Quad4
% Ds                - Matriz Constitutiva de Cisalhamento do Elemento Quad4

%% OUTPUT
% K1                - Matriz de Rigidez do Elemento Quad4 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez do Elemento Quad4 no Ponto da Quadratura de Gauss
function [ K1 ] = matrix_K_QG_quad4 ( t , Jm , Jb , Bm , Bb , Bs , Dm , Db , Ds )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez de Membrana
    Km = t * ( transpose ( Bm ) * Dm * Bm ) * det ( Jm );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez de Flex�o
    Kb = ( ( transpose ( Bb ) * Db * Bb ) * det ( Jb ) ) + ( ( transpose ( Bs ) * Ds * Bs ) * det ( Jb ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local
    K1 = zeros ( 24 , 24 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 1
    K1 ( 1  , 1  ) = Km ( 1 , 1 );
    K1 ( 1  , 2  ) = Km ( 1 , 2 );
    K1 ( 1  , 7  ) = Km ( 1 , 3 );
    K1 ( 1  , 8  ) = Km ( 1 , 4 );
    K1 ( 1  , 13 ) = Km ( 1 , 5 );
    K1 ( 1  , 14 ) = Km ( 1 , 6 );
    K1 ( 1  , 19 ) = Km ( 1 , 7 );
    K1 ( 1  , 20 ) = Km ( 1 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 2
    K1 ( 2  , 1  ) = Km ( 2 , 1 );
    K1 ( 2  , 2  ) = Km ( 2 , 2 );
    K1 ( 2  , 7  ) = Km ( 2 , 3 );
    K1 ( 2  , 8  ) = Km ( 2 , 4 );
    K1 ( 2  , 13 ) = Km ( 2 , 5 );
    K1 ( 2  , 14 ) = Km ( 2 , 6 );
    K1 ( 2  , 19 ) = Km ( 2 , 7 );
    K1 ( 2  , 20 ) = Km ( 2 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 3
    K1 ( 7  , 1  ) = Km ( 3 , 1 );
    K1 ( 7  , 2  ) = Km ( 3 , 2 );
    K1 ( 7  , 7  ) = Km ( 3 , 3 );
    K1 ( 7  , 8  ) = Km ( 3 , 4 );
    K1 ( 7  , 13 ) = Km ( 3 , 5 );
    K1 ( 7  , 14 ) = Km ( 3 , 6 );
    K1 ( 7  , 19 ) = Km ( 3 , 7 );
    K1 ( 7  , 20 ) = Km ( 3 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 4
    K1 ( 8  , 1  ) = Km ( 4 , 1 );
    K1 ( 8  , 2  ) = Km ( 4 , 2 );
    K1 ( 8  , 7  ) = Km ( 4 , 3 );
    K1 ( 8  , 8  ) = Km ( 4 , 4 );
    K1 ( 8  , 13 ) = Km ( 4 , 5 );
    K1 ( 8  , 14 ) = Km ( 4 , 6 );
    K1 ( 8  , 19 ) = Km ( 4 , 7 );
    K1 ( 8  , 20 ) = Km ( 4 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 5
    K1 ( 13 , 1  ) = Km ( 5 , 1 );
    K1 ( 13 , 2  ) = Km ( 5 , 2 );
    K1 ( 13 , 7  ) = Km ( 5 , 3 );
    K1 ( 13 , 8  ) = Km ( 5 , 4 );
    K1 ( 13 , 13 ) = Km ( 5 , 5 );
    K1 ( 13 , 14 ) = Km ( 5 , 6 );
    K1 ( 13 , 19 ) = Km ( 5 , 7 );
    K1 ( 13 , 20 ) = Km ( 5 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 6
    K1 ( 14 , 1  ) = Km ( 6 , 1 );
    K1 ( 14 , 2  ) = Km ( 6 , 2 );
    K1 ( 14 , 7  ) = Km ( 6 , 3 );
    K1 ( 14 , 8  ) = Km ( 6 , 4 );
    K1 ( 14 , 13 ) = Km ( 6 , 5 );
    K1 ( 14 , 14 ) = Km ( 6 , 6 );
    K1 ( 14 , 19 ) = Km ( 6 , 7 );
    K1 ( 14 , 20 ) = Km ( 6 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 7
    K1 ( 19 , 1  ) = Km ( 7 , 1 );
    K1 ( 19 , 2  ) = Km ( 7 , 2 );
    K1 ( 19 , 7  ) = Km ( 7 , 3 );
    K1 ( 19 , 8  ) = Km ( 7 , 4 );
    K1 ( 19 , 13 ) = Km ( 7 , 5 );
    K1 ( 19 , 14 ) = Km ( 7 , 6 );
    K1 ( 19 , 19 ) = Km ( 7 , 7 );
    K1 ( 19 , 20 ) = Km ( 7 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 8
    K1 ( 20 , 1  ) = Km ( 8 , 1 );
    K1 ( 20 , 2  ) = Km ( 8 , 2 );
    K1 ( 20 , 7  ) = Km ( 8 , 3 );
    K1 ( 20 , 8  ) = Km ( 8 , 4 );
    K1 ( 20 , 13 ) = Km ( 8 , 5 );
    K1 ( 20 , 14 ) = Km ( 8 , 6 );
    K1 ( 20 , 19 ) = Km ( 8 , 7 );
    K1 ( 20 , 20 ) = Km ( 8 , 8 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 1
    K1 ( 3  , 3  ) = Kb ( 1  , 1  );
    K1 ( 3  , 4  ) = Kb ( 1  , 2  );
    K1 ( 3  , 5  ) = Kb ( 1  , 3  );
    K1 ( 3  , 9  ) = Kb ( 1  , 4  );
    K1 ( 3  , 10 ) = Kb ( 1  , 5  );
    K1 ( 3  , 11 ) = Kb ( 1  , 6  );
    K1 ( 3  , 15 ) = Kb ( 1  , 7  );
    K1 ( 3  , 16 ) = Kb ( 1  , 8  );
    K1 ( 3  , 17 ) = Kb ( 1  , 9  );
    K1 ( 3  , 21 ) = Kb ( 1  , 10 );
    K1 ( 3  , 22 ) = Kb ( 1  , 11 );
    K1 ( 3  , 23 ) = Kb ( 1  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 2
    K1 ( 4  , 3  ) = Kb ( 2  , 1  );
    K1 ( 4  , 4  ) = Kb ( 2  , 2  );
    K1 ( 4  , 5  ) = Kb ( 2  , 3  );
    K1 ( 4  , 9  ) = Kb ( 2  , 4  );
    K1 ( 4  , 10 ) = Kb ( 2  , 5  );
    K1 ( 4  , 11 ) = Kb ( 2  , 6  );
    K1 ( 4  , 15 ) = Kb ( 2  , 7  );
    K1 ( 4  , 16 ) = Kb ( 2  , 8  );
    K1 ( 4  , 17 ) = Kb ( 2  , 9  );
    K1 ( 4  , 21 ) = Kb ( 2  , 10 );
    K1 ( 4  , 22 ) = Kb ( 2  , 11 );
    K1 ( 4  , 23 ) = Kb ( 2  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 3
    K1 ( 5  , 3  ) = Kb ( 3  , 1  );
    K1 ( 5  , 4  ) = Kb ( 3  , 2  );
    K1 ( 5  , 5  ) = Kb ( 3  , 3  );
    K1 ( 5  , 9  ) = Kb ( 3  , 4  );
    K1 ( 5  , 10 ) = Kb ( 3  , 5  );
    K1 ( 5  , 11 ) = Kb ( 3  , 6  );
    K1 ( 5  , 15 ) = Kb ( 3  , 7  );
    K1 ( 5  , 16 ) = Kb ( 3  , 8  );
    K1 ( 5  , 17 ) = Kb ( 3  , 9  );
    K1 ( 5  , 21 ) = Kb ( 3  , 10 );
    K1 ( 5  , 22 ) = Kb ( 3  , 11 );
    K1 ( 5  , 23 ) = Kb ( 3  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 4
    K1 ( 9  , 3  ) = Kb ( 4  , 1  );
    K1 ( 9  , 4  ) = Kb ( 4  , 2  );
    K1 ( 9  , 5  ) = Kb ( 4  , 3  );
    K1 ( 9  , 9  ) = Kb ( 4  , 4  );
    K1 ( 9  , 10 ) = Kb ( 4  , 5  );
    K1 ( 9  , 11 ) = Kb ( 4  , 6  );
    K1 ( 9  , 15 ) = Kb ( 4  , 7  );
    K1 ( 9  , 16 ) = Kb ( 4  , 8  );
    K1 ( 9  , 17 ) = Kb ( 4  , 9  );
    K1 ( 9  , 21 ) = Kb ( 4  , 10 );
    K1 ( 9  , 22 ) = Kb ( 4  , 11 );
    K1 ( 9  , 23 ) = Kb ( 4  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 5
    K1 ( 10 , 3  ) = Kb ( 5  , 1  );
    K1 ( 10 , 4  ) = Kb ( 5  , 2  );
    K1 ( 10 , 5  ) = Kb ( 5  , 3  );
    K1 ( 10 , 9  ) = Kb ( 5  , 4  );
    K1 ( 10 , 10 ) = Kb ( 5  , 5  );
    K1 ( 10 , 11 ) = Kb ( 5  , 6  );
    K1 ( 10 , 15 ) = Kb ( 5  , 7  );
    K1 ( 10 , 16 ) = Kb ( 5  , 8  );
    K1 ( 10 , 17 ) = Kb ( 5  , 9  );
    K1 ( 10 , 21 ) = Kb ( 5  , 10 );
    K1 ( 10 , 22 ) = Kb ( 5  , 11 );
    K1 ( 10 , 23 ) = Kb ( 5  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 6
    K1 ( 11 , 3  ) = Kb ( 6  , 1  );
    K1 ( 11 , 4  ) = Kb ( 6  , 2  );
    K1 ( 11 , 5  ) = Kb ( 6  , 3  );
    K1 ( 11 , 9  ) = Kb ( 6  , 4  );
    K1 ( 11 , 10 ) = Kb ( 6  , 5  );
    K1 ( 11 , 11 ) = Kb ( 6  , 6  );
    K1 ( 11 , 15 ) = Kb ( 6  , 7  );
    K1 ( 11 , 16 ) = Kb ( 6  , 8  );
    K1 ( 11 , 17 ) = Kb ( 6  , 9  );
    K1 ( 11 , 21 ) = Kb ( 6  , 10 );
    K1 ( 11 , 22 ) = Kb ( 6  , 11 );
    K1 ( 11 , 23 ) = Kb ( 6  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 7
    K1 ( 15 , 3  ) = Kb ( 7  , 1  );
    K1 ( 15 , 4  ) = Kb ( 7  , 2  );
    K1 ( 15 , 5  ) = Kb ( 7  , 3  );
    K1 ( 15 , 9  ) = Kb ( 7  , 4  );
    K1 ( 15 , 10 ) = Kb ( 7  , 5  );
    K1 ( 15 , 11 ) = Kb ( 7  , 6  );
    K1 ( 15 , 15 ) = Kb ( 7  , 7  );
    K1 ( 15 , 16 ) = Kb ( 7  , 8  );
    K1 ( 15 , 17 ) = Kb ( 7  , 9  );
    K1 ( 15 , 21 ) = Kb ( 7  , 10 );
    K1 ( 15 , 22 ) = Kb ( 7  , 11 );
    K1 ( 15 , 23 ) = Kb ( 7  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 8
    K1 ( 16 , 3  ) = Kb ( 8  , 1  );
    K1 ( 16 , 4  ) = Kb ( 8  , 2  );
    K1 ( 16 , 5  ) = Kb ( 8  , 3  );
    K1 ( 16 , 9  ) = Kb ( 8  , 4  );
    K1 ( 16 , 10 ) = Kb ( 8  , 5  );
    K1 ( 16 , 11 ) = Kb ( 8  , 6  );
    K1 ( 16 , 15 ) = Kb ( 8  , 7  );
    K1 ( 16 , 16 ) = Kb ( 8  , 8  );
    K1 ( 16 , 17 ) = Kb ( 8  , 9  );
    K1 ( 16 , 21 ) = Kb ( 8  , 10 );
    K1 ( 16 , 22 ) = Kb ( 8  , 11 );
    K1 ( 16 , 23 ) = Kb ( 8  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 9
    K1 ( 17 , 3  ) = Kb ( 9  , 1  );
    K1 ( 17 , 4  ) = Kb ( 9  , 2  );
    K1 ( 17 , 5  ) = Kb ( 9  , 3  );
    K1 ( 17 , 9  ) = Kb ( 9  , 4  );
    K1 ( 17 , 10 ) = Kb ( 9  , 5  );
    K1 ( 17 , 11 ) = Kb ( 9  , 6  );
    K1 ( 17 , 15 ) = Kb ( 9  , 7  );
    K1 ( 17 , 16 ) = Kb ( 9  , 8  );
    K1 ( 17 , 17 ) = Kb ( 9  , 9  );
    K1 ( 17 , 21 ) = Kb ( 9  , 10 );
    K1 ( 17 , 22 ) = Kb ( 9  , 11 );
    K1 ( 17 , 23 ) = Kb ( 9  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 10
    K1 ( 21 , 3  ) = Kb ( 10 , 1  );
    K1 ( 21 , 4  ) = Kb ( 10 , 2  );
    K1 ( 21 , 5  ) = Kb ( 10 , 3  );
    K1 ( 21 , 9  ) = Kb ( 10 , 4  );
    K1 ( 21 , 10 ) = Kb ( 10 , 5  );
    K1 ( 21 , 11 ) = Kb ( 10 , 6  );
    K1 ( 21 , 15 ) = Kb ( 10 , 7  );
    K1 ( 21 , 16 ) = Kb ( 10 , 8  );
    K1 ( 21 , 17 ) = Kb ( 10 , 9  );
    K1 ( 21 , 21 ) = Kb ( 10 , 10 );
    K1 ( 21 , 22 ) = Kb ( 10 , 11 );
    K1 ( 21 , 23 ) = Kb ( 10 , 12 );

    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 11
    K1 ( 22 , 3  ) = Kb ( 11 , 1  );
    K1 ( 22 , 4  ) = Kb ( 11 , 2  );
    K1 ( 22 , 5  ) = Kb ( 11 , 3  );
    K1 ( 22 , 9  ) = Kb ( 11 , 4  );
    K1 ( 22 , 10 ) = Kb ( 11 , 5  );
    K1 ( 22 , 11 ) = Kb ( 11 , 6  );
    K1 ( 22 , 15 ) = Kb ( 11 , 7  );
    K1 ( 22 , 16 ) = Kb ( 11 , 8  );
    K1 ( 22 , 17 ) = Kb ( 11 , 9  );
    K1 ( 22 , 21 ) = Kb ( 11 , 10 );
    K1 ( 22 , 22 ) = Kb ( 11 , 11 );
    K1 ( 22 , 23 ) = Kb ( 11 , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 12
    K1 ( 23 , 3  ) = Kb ( 12 , 1  );
    K1 ( 23 , 4  ) = Kb ( 12 , 2  );
    K1 ( 23 , 5  ) = Kb ( 12 , 3  );
    K1 ( 23 , 9  ) = Kb ( 12 , 4  );
    K1 ( 23 , 10 ) = Kb ( 12 , 5  );
    K1 ( 23 , 11 ) = Kb ( 12 , 6  );
    K1 ( 23 , 15 ) = Kb ( 12 , 7  );
    K1 ( 23 , 16 ) = Kb ( 12 , 8  );
    K1 ( 23 , 17 ) = Kb ( 12 , 9  );
    K1 ( 23 , 21 ) = Kb ( 12 , 10 );
    K1 ( 23 , 22 ) = Kb ( 12 , 11 );
    K1 ( 23 , 23 ) = Kb ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA RIGIDEZ DE ROTA��O PERPENDICULAR A PLACA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % M�ximo Valor de Rigidez da Matriz do Elemento
    Kmax = max ( K1 ( : ) );
    
    % Rigidez de Rota��o Perpendicular a Placa
    Krot = Kmax / 1000;
    
    % Aloca��o da Rigidez de Rota��o Perpendicular a Placa na Matriz
    K1 ( 6  , 6  ) = Krot;
    K1 ( 12 , 12 ) = Krot;
    K1 ( 18 , 18 ) = Krot;
    K1 ( 24 , 24 ) = Krot;

end

