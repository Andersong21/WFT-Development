%% Cria��o da Estrutura de Deforma��es e Tens�es do Elemento Quad4

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento i

%% OUTPUT
% Elem_Strain       - Matriz de Deforma��es do Elemento i
% Elem_Stress       - Matriz de Tens�es do Elemento i

%% Declara��o da Fun��o de Cria��o da Estrutura de Deforma��es e Tens�es do Elemento Quad4
function [ Elem_Strain , Elem_Stress ] = strain_stress_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Estrutura de Dados das Deforma��es do Elemento
    Elem_Strain = struct;
    
    % Inicializa��o da Estrutura de Dados das Tens�es do Elemento
    Elem_Stress = struct;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_quad4 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_quad4 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_quad4 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva e Espessura do Elemento
    [ t , Dm , Db , Ds ] = matrix_D_quad4 ( Elem_Param , Mat_Param , Prop_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Globais do Elemento
    [ Ug ] = vector_Ug_quad4 ( Node_Param , Elem_Param , i );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS NODAIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Locais do Elemento
    [ Ul ] = vector_Ul_quad4 ( R , Ug );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFORMA��ES NOS N�S DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos N�s do Elemento
    for j = 1:4
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % COORDENADAS NATURAIS DOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % N� 1
        if ( j == 1 )
            
            % Coordenada Natural e
            e = - 0.577350269189626;

            % Coordenada Natural n
            n = - 0.577350269189626;
            
        end
        
        % N� 2
        if ( j == 2 )
            
            % Coordenada Natural e
            e = + 0.577350269189626;

            % Coordenada Natural n
            n = - 0.577350269189626;
            
        end
        
        % N� 3
        if ( j == 3 )
            
            % Coordenada Natural e
            e = + 0.577350269189626;

            % Coordenada Natural n
            n = + 0.577350269189626;
            
        end
        
        % N� 4
        if ( j == 4 )
            
            % Coordenada Natural e
            e = - 0.577350269189626;

            % Coordenada Natural n
            n = + 0.577350269189626;
            
        end
        
        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ Jm , Jb ] = matrix_J_quad4 ( e , n , Cl );            

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bm , Bb , Bs ] = matrix_B_quad4 ( e , n , Jm , Jb );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE DEFORMA��ES LOCAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Deforma��es Locais do Elemento
        [ ElE , ElF , ElG ] = vector_El_quad4 ( Bm , Bb , Bs , Ul , t );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE TENS�ES LOCAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Tens�es Locais do Elemento
        [ SlE , SlF , SlG ] = vector_Sl_quad4 ( ElE , ElF , ElG , Dm , Db , Ds , t ); 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE DEFORMA��ES GLOBAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Deforma��es Globais do Elemento
        [ EgE , EgF , EgG ] = vector_Eg_quad4 ( ElE , ElF , ElG , R );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE TENS�ES GLOBAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Tens�es Globais do Elemento
        [ SgE , SgF , SgG ] = vector_Sg_quad4 ( SlE , SlF , SlG , R );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ALOCA��O NA ESTRUTURA DE DADOS DOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Id do N�
        Elem_Strain ( j ).id = Elem_Param ( i ).node ( j );
        Elem_Stress ( j ).id = Elem_Param ( i ).node ( j );
        
        % Varredura na Lista das Deforma��es e Tens�es Globais -- Layers
        for k = 1:3
           
            % Varredura no Vetor de Deforma��es e Tens�es
            for l = 1:6
                
                % Layer E
                if k == 1
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgE ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgE ( l );
                    
                    % Continuar
                    continue;
                    
                end
                
                % Layer F
                if k == 2
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgF ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgF ( l );
                    
                    % Continuar
                    continue;
                    
                end
                
                % Layer G
                if k == 3
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgG ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgG ( l );
                    
                    % Continuar
                    continue;
                    
                end

            end
            
        end
        
    end
    
end

