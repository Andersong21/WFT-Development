%% Cria��o da Densidade do Elemento Quad4

%% INPUT
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento i na Estrutura de Dados

%% OUTPUT
% t                 - Espessura do Elemento
% rho               - Densidade do Elemento
% I                 - Matriz de Densidade de Placa do Elemento

%% Declara��o da Fun��o de Cria��o da Densidade do Elemento Quad4
function [ t , rho , I ] = matrix_P_quad4 ( Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%
    % PAR�METROS %
    %%%%%%%%%%%%%%
    
    % Id da Propriedade do Elemento
    Idp = Elem_Param ( i ).prop_id;
    
    % Id do Material
    Idm = Mat_Param ( 1 ).id;
    
    % Espessura do Elemento
    t = Prop_Param ( Idp ).thick;
    
    % Densidade
    rho = Mat_Param ( Idm ).rho;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DENSIDADE DA PLACA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Densidade da Placa
    I = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos na Matriz de Densidade de Placa
    I ( 1 , 1 ) = rho * t;
    I ( 2 , 2 ) = rho * t * t * t / 12;
    I ( 3 , 3 ) = rho * t * t * t / 12;

end

