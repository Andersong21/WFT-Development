%% Cria��o da Matriz de Coordenadas Nodais Globais do Elemento Quad4

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% i                 - Posi��o i do Elemento

%% OUTPUT
% Cg                - Matriz das Coordenadas Globais do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Coordenadas Nodais Globais do Elemento Quad4
function [ Cg ] = matrix_Cg_quad4 ( Node_Param , Elem_Param , i )

    % Inicializa��o da Matriz de Coordenadas Nodais Globais do Quad4
    Cg = zeros ( 4 , 3 );
    
    % Varredura nos N�s do Elemento
    for j = 1:4
    
        % Id do N�
        Node_Id = Elem_Param ( i ).node ( j );
        
        % Aloca��o da Coordenada X do n�
        Cg ( j , 1 ) = Node_Param ( Node_Id ).coord ( 1 );
        
        % Aloca��o da Coordenada Y do n�
        Cg ( j , 2 ) = Node_Param ( Node_Id ).coord ( 2 );
        
        % Aloca��o da Coordenada Z do n�
        Cg ( j , 3 ) = Node_Param ( Node_Id ).coord ( 3 );
    
    end      
        
end

