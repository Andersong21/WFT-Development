%% Cria��o da Matriz Jacobiana do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Jm                - Matriz Jacobiana do Elemento Quad4 - Membrana
% Jb                - Matriz Jacobiana do Elemento Quad4 - Placa

%% Declara��o da Fun��o de Cria��o da Matriz Jacobiana do Elemento Quad4
function [ Jm , Jb ] = matrix_J_quad4 ( e , n , Cl )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ JACOBIANA % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Inicializa��o da Matriz Jacobiana -- Membrana
    Jm = zeros ( 2 , 2 );
    
    % Aloca��o da Matriz Jacobiana -- Membrana
    Jm ( 1 , 1 ) = DN1e * Cl ( 1 , 1 ) + DN2e * Cl ( 2 , 1 ) + DN3e * Cl ( 3 , 1 ) + DN4e * Cl ( 4 , 1 );
    Jm ( 1 , 2 ) = DN1e * Cl ( 1 , 2 ) + DN2e * Cl ( 2 , 2 ) + DN3e * Cl ( 3 , 2 ) + DN4e * Cl ( 4 , 2 );
    Jm ( 2 , 1 ) = DN1n * Cl ( 1 , 1 ) + DN2n * Cl ( 2 , 1 ) + DN3n * Cl ( 3 , 1 ) + DN4n * Cl ( 4 , 1 );
    Jm ( 2 , 2 ) = DN1n * Cl ( 1 , 2 ) + DN2n * Cl ( 2 , 2 ) + DN3n * Cl ( 3 , 2 ) + DN4n * Cl ( 4 , 2 );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DA MATRIZ JACOBIANA % PLACA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Par�metros Geom�tricos
    x12 = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    x23 = Cl ( 3 , 1 ) - Cl ( 2 , 1 );
    x34 = Cl ( 4 , 1 ) - Cl ( 3 , 1 ); 
    x41 = Cl ( 1 , 1 ) - Cl ( 4 , 1 );
    y12 = Cl ( 2 , 2 ) - Cl ( 1 , 2 );
    y23 = Cl ( 3 , 2 ) - Cl ( 2 , 2 );
    y34 = Cl ( 4 , 2 ) - Cl ( 3 , 2 );
    y41 = Cl ( 1 , 2 ) - Cl ( 4 , 2 );
    
    % Inicializa��o da Matriz Jacobiana -- Placa
    Jb = zeros ( 2 , 2 );
    
    % Aloca��o da Matriz Jacobiana -- Placa
    Jb ( 1 , 1 ) = ( 1 / 4 ) * ( - x12 + x34 + ( n * ( x12 + x34 ) ) );
    Jb ( 1 , 2 ) = ( 1 / 4 ) * ( - y12 + y34 + ( n * ( y12 + y34 ) ) );
    Jb ( 2 , 1 ) = ( 1 / 4 ) * ( - x23 + x41 + ( e * ( x12 + x34 ) ) );
    Jb ( 2 , 2 ) = ( 1 / 4 ) * ( - y23 + y41 + ( e * ( y12 + y34 ) ) );
    
end

