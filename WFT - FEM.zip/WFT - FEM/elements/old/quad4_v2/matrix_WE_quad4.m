%% Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Quad4

%% OUTPUT
% WE                - Matriz dos Pesos na Quadratura de Gauss do Quad4

%% Declara��o da Fun��o de Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Quad4
function [ WE ] = matrix_WE_quad4 ()
   
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss
    WE = zeros ( 2 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss
    WE ( 1 ) = 1.0;
    WE ( 2 ) = 1.0;        
   
end

