%% Cria��o do Vetor de Deforma��es Globais do Elemento Quad4

%% INPUT
% ElE               - Vetor de Deforma��o Local no Layer E
% ElF               - Vetor de Deforma��o Local no Layer F
% ElG               - Vetor de Deforma��o Local no Layer G
% R                 - Matriz de Transforma�ao de Coordenada do Elemento

%% OUTPUT
% EgE               - Vetor de Deforma��o Global no Layer E
% EgF               - Vetor de Deforma��o Global no Layer F
% EgG               - Vetor de Deforma��o Global no Layer G

%% Declara��o da Fun��o de Cria��o Vetor de Deforma��es Globais do Elemento Quad4
function [ EgE , EgF , EgG ] = vector_Eg_quad4 ( ElE , ElF , ElG , R )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Layer E
    matrix_El_E = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em E -- Linha 1
    matrix_El_E ( 1 , 1 ) = ElE ( 1 );
    matrix_El_E ( 1 , 2 ) = ElE ( 4 );
    matrix_El_E ( 1 , 3 ) = ElE ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em E -- Linha 2
    matrix_El_E ( 2 , 1 ) = ElE ( 4 );
    matrix_El_E ( 2 , 2 ) = ElE ( 2 );
    matrix_El_E ( 2 , 3 ) = ElE ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em E -- Linha 3
    matrix_El_E ( 3 , 1 ) = ElE ( 6 );
    matrix_El_E ( 3 , 2 ) = ElE ( 5 );
    matrix_El_E ( 3 , 3 ) = ElE ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Global no Layer E
    matrix_Eg_E = R ( 1:3 , 1:3 ) * matrix_El_E * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em E
    EgE ( 1 ) = matrix_Eg_E ( 1 , 1 );
    EgE ( 2 ) = matrix_Eg_E ( 2 , 2 );
    EgE ( 3 ) = matrix_Eg_E ( 3 , 3 );
    EgE ( 4 ) = matrix_Eg_E ( 1 , 2 );
    EgE ( 5 ) = matrix_Eg_E ( 2 , 3 );
    EgE ( 6 ) = matrix_Eg_E ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Layer F
    matrix_El_F = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em F -- Linha 1
    matrix_El_F ( 1 , 1 ) = ElF ( 1 );
    matrix_El_F ( 1 , 2 ) = ElF ( 4 );
    matrix_El_F ( 1 , 3 ) = ElF ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em F -- Linha 2
    matrix_El_F ( 2 , 1 ) = ElF ( 4 );
    matrix_El_F ( 2 , 2 ) = ElF ( 2 );
    matrix_El_F ( 2 , 3 ) = ElF ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em F -- Linha 3
    matrix_El_F ( 3 , 1 ) = ElF ( 6 );
    matrix_El_F ( 3 , 2 ) = ElF ( 5 );
    matrix_El_F ( 3 , 3 ) = ElF ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Layer F
    matrix_Eg_F = R ( 1:3 , 1:3 ) * matrix_El_F * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em F
    EgF ( 1 ) = matrix_Eg_F ( 1 , 1 );
    EgF ( 2 ) = matrix_Eg_F ( 2 , 2 );
    EgF ( 3 ) = matrix_Eg_F ( 3 , 3 );
    EgF ( 4 ) = matrix_Eg_F ( 1 , 2 );
    EgF ( 5 ) = matrix_Eg_F ( 2 , 3 );
    EgF ( 6 ) = matrix_Eg_F ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Layer G
    matrix_El_G = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em G -- Linha 1
    matrix_El_G ( 1 , 1 ) = ElG ( 1 );
    matrix_El_G ( 1 , 2 ) = ElG ( 4 );
    matrix_El_G ( 1 , 3 ) = ElG ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em G -- Linha 2
    matrix_El_G ( 2 , 1 ) = ElG ( 4 );
    matrix_El_G ( 2 , 2 ) = ElG ( 2 );
    matrix_El_G ( 2 , 3 ) = ElG ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em G -- Linha 3
    matrix_El_G ( 3 , 1 ) = ElG ( 6 );
    matrix_El_G ( 3 , 2 ) = ElG ( 5 );
    matrix_El_G ( 3 , 3 ) = ElG ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Layer G
    matrix_Eg_G = R ( 1:3 , 1:3 ) * matrix_El_G * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em G
    EgG ( 1 ) = matrix_Eg_G ( 1 , 1 );
    EgG ( 2 ) = matrix_Eg_G ( 2 , 2 );
    EgG ( 3 ) = matrix_Eg_G ( 3 , 3 );
    EgG ( 4 ) = matrix_Eg_G ( 1 , 2 );
    EgG ( 5 ) = matrix_Eg_G ( 2 , 3 );
    EgG ( 6 ) = matrix_Eg_G ( 1 , 3 );
    
end

