%% Cria��o da Matriz dos Pontos da Quadratura de Gauss do Elemento Quad4

%% OUTPUT
% WE                - Matriz dos Pontos da Quadratura de Gauss do Quad4

%% Declara��o da Fun��o de Cria��o da Matriz dos Pontos da Quadratura de Gauss do Elemento Quad4
function [ PO ] = matrix_PO_quad4 ()
   
    % Inicializa��o da Matriz dos Pontos da Quadratura de Gauss
    PO = zeros ( 2 , 1 );
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 1
    PO ( 1 , 1 ) = + 0.577350269189626;
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 2
    PO ( 2 , 1 ) = - 0.577350269189626;
    
end

