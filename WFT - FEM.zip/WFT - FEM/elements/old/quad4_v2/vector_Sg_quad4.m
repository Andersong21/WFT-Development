%% Cria��o do Vetor de Tens�es Globais do Elemento Quad4

%% INPUT
% SlE               - Vetor de Tens�o Local no Layer E
% SlF               - Vetor de Tens�o Local no Layer F
% SlG               - Vetor de Tens�o Local no Layer G
% R                 - Matriz de Transforma�ao de Coordenada do Elemento

%% OUTPUT
% SgE               - Vetor de Tens�o Global no Layer E
% SgF               - Vetor de Tens�o Global no Layer F
% SgG               - Vetor de Tens�o Global no Layer G

%% Declara��o da Fun��o de Cria��o Vetor de Tens�es Globais do Elemento Quad4
function [ SgE , SgF , SgG ] = vector_Sg_quad4 ( SlE , SlF , SlG , R )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Layer E
    matrix_Sl_E = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em E -- Linha 1
    matrix_Sl_E ( 1 , 1 ) = SlE ( 1 );
    matrix_Sl_E ( 1 , 2 ) = SlE ( 4 );
    matrix_Sl_E ( 1 , 3 ) = SlE ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em E -- Linha 2
    matrix_Sl_E ( 2 , 1 ) = SlE ( 4 );
    matrix_Sl_E ( 2 , 2 ) = SlE ( 2 );
    matrix_Sl_E ( 2 , 3 ) = SlE ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em E -- Linha 3
    matrix_Sl_E ( 3 , 1 ) = SlE ( 6 );
    matrix_Sl_E ( 3 , 2 ) = SlE ( 5 );
    matrix_Sl_E ( 3 , 3 ) = SlE ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM E %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Global no Layer E
    matrix_Sg_E = R ( 1:3 , 1:3 ) * matrix_Sl_E * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em E
    SgE ( 1 ) = matrix_Sg_E ( 1 , 1 );
    SgE ( 2 ) = matrix_Sg_E ( 2 , 2 );
    SgE ( 3 ) = matrix_Sg_E ( 3 , 3 );
    SgE ( 4 ) = matrix_Sg_E ( 1 , 2 );
    SgE ( 5 ) = matrix_Sg_E ( 2 , 3 );
    SgE ( 6 ) = matrix_Sg_E ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Layer F
    matrix_Sl_F = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em F -- Linha 1
    matrix_Sl_F ( 1 , 1 ) = SlF ( 1 );
    matrix_Sl_F ( 1 , 2 ) = SlF ( 4 );
    matrix_Sl_F ( 1 , 3 ) = SlF ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em F -- Linha 2
    matrix_Sl_F ( 2 , 1 ) = SlF ( 4 );
    matrix_Sl_F ( 2 , 2 ) = SlF ( 2 );
    matrix_Sl_F ( 2 , 3 ) = SlF ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em F -- Linha 3
    matrix_Sl_F ( 3 , 1 ) = SlF ( 6 );
    matrix_Sl_F ( 3 , 2 ) = SlF ( 5 );
    matrix_Sl_F ( 3 , 3 ) = SlF ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM F %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Layer F
    matrix_Sg_F = R ( 1:3 , 1:3 ) * matrix_Sl_F * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em F
    SgF ( 1 ) = matrix_Sg_F ( 1 , 1 );
    SgF ( 2 ) = matrix_Sg_F ( 2 , 2 );
    SgF ( 3 ) = matrix_Sg_F ( 3 , 3 );
    SgF ( 4 ) = matrix_Sg_F ( 1 , 2 );
    SgF ( 5 ) = matrix_Sg_F ( 2 , 3 );
    SgF ( 6 ) = matrix_Sg_F ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Layer G
    matrix_Sl_G = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em G -- Linha 1
    matrix_Sl_G ( 1 , 1 ) = SlG ( 1 );
    matrix_Sl_G ( 1 , 2 ) = SlG ( 4 );
    matrix_Sl_G ( 1 , 3 ) = SlG ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em G -- Linha 2
    matrix_Sl_G ( 2 , 1 ) = SlG ( 4 );
    matrix_Sl_G ( 2 , 2 ) = SlG ( 2 );
    matrix_Sl_G ( 2 , 3 ) = SlG ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em G -- Linha 3
    matrix_Sl_G ( 3 , 1 ) = SlG ( 6 );
    matrix_Sl_G ( 3 , 2 ) = SlG ( 5 );
    matrix_Sl_G ( 3 , 3 ) = SlG ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM G %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Layer G
    matrix_Sg_G = R ( 1:3 , 1:3 ) * matrix_Sl_G * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em G
    SgG ( 1 ) = matrix_Sg_G ( 1 , 1 );
    SgG ( 2 ) = matrix_Sg_G ( 2 , 2 );
    SgG ( 3 ) = matrix_Sg_G ( 3 , 3 );
    SgG ( 4 ) = matrix_Sg_G ( 1 , 2 );
    SgG ( 5 ) = matrix_Sg_G ( 2 , 3 );
    SgG ( 6 ) = matrix_Sg_G ( 1 , 3 );
    
end

