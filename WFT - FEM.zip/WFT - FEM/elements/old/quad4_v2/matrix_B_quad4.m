%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Jm                - Matriz Jacobiana do Elemento -- Membrana
% Jb                - Matriz Jacobiana do Elemento -- Flex�o
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Bm                - Matriz de Correla��o Deslocamento Deforma��o de Membrana do Elemento Quad4
% Bb                - Matriz de Correla��o Deslocamento Deforma��o de Flex�o do Elemento Quad4
% Bs                - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o do Elemento Quad4
function [ Bm , Bb , Bs ] = matrix_B_quad4 ( e , n , Jm , Jb )

    %%%%%%%%%%%%
    % MEMBRANA %
    %%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4;
    
    % Inicializa��o da Matriz das Derivadas das Fun��es de Forma
    DN = zeros ( 4 , 8 );
    
    % Aloca��o das Derivadas das Fun��es de Forma
    DN ( 1 , 1 ) = DN1e;
    DN ( 1 , 3 ) = DN2e;
    DN ( 1 , 5 ) = DN3e;
    DN ( 1 , 7 ) = DN4e;
    
    DN ( 2 , 1 ) = DN1n;
    DN ( 2 , 3 ) = DN2n;
    DN ( 2 , 5 ) = DN3n;
    DN ( 2 , 7 ) = DN4n;
    
    DN ( 3 , 2 ) = DN1e;
    DN ( 3 , 4 ) = DN2e;
    DN ( 3 , 6 ) = DN3e;
    DN ( 3 , 8 ) = DN4e;
    
    DN ( 4 , 2 ) = DN1n;
    DN ( 4 , 4 ) = DN2n;
    DN ( 4 , 6 ) = DN3n;
    DN ( 4 , 8 ) = DN4n;    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO DA MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o A
    A = zeros ( 3 , 4 );
    
    % Aloca��o dos Termos na Matriz A
    A ( 1 , 1 ) = + Jm ( 2 , 2 );
    A ( 1 , 2 ) = - Jm ( 1 , 2 );
    
    A ( 2 , 3 ) = - Jm ( 2 , 1 );
    A ( 2 , 4 ) = + Jm ( 1 , 1 );
    
    A ( 3 , 1 ) = - Jm ( 2 , 1 );
    A ( 3 , 2 ) = + Jm ( 1 , 1 );
    A ( 3 , 3 ) = + Jm ( 2 , 2 );
    A ( 3 , 4 ) = - Jm ( 1 , 2 );
    
    % Multiplica��o pelo Determinante do Jacobiana
    A = ( 1 / det ( Jm ) ) * A;   
    
    % Determina��o da Matriz de Correla��o Bm
    Bm  = A * DN; 
    
    %%%%%%%%%
    % PLACA %
    %%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%
    % FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%
    
    % Determina��o das Fun��es de Forma
    N1 = ( 1 / 4 ) * ( 1 - e ) * ( 1 - n );
    N2 = ( 1 / 4 ) * ( 1 + e ) * ( 1 - n );
    N3 = ( 1 / 4 ) * ( 1 + e ) * ( 1 + n );
    N4 = ( 1 / 4 ) * ( 1 - e ) * ( 1 + n );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ JACOBIANA INVERSA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz Jacobiana Inversa
    Ji = inv ( Jb );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADAS DAS FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a X
    DN1x = ( DN1e * Ji ( 1 , 1 ) ) + ( DN1n * Ji ( 1 , 2 ) );
    DN2x = ( DN2e * Ji ( 1 , 1 ) ) + ( DN2n * Ji ( 1 , 2 ) );
    DN3x = ( DN3e * Ji ( 1 , 1 ) ) + ( DN3n * Ji ( 1 , 2 ) );
    DN4x = ( DN4e * Ji ( 1 , 1 ) ) + ( DN4n * Ji ( 1 , 2 ) );
    
    % Derivadas das Fun��es de Forma em Rela��o a Y
    DN1y = ( DN1e * Ji ( 2 , 1 ) ) + ( DN1n * Ji ( 2 , 2 ) );
    DN2y = ( DN2e * Ji ( 2 , 1 ) ) + ( DN2n * Ji ( 2 , 2 ) );
    DN3y = ( DN3e * Ji ( 2 , 1 ) ) + ( DN3n * Ji ( 2 , 2 ) );
    DN4y = ( DN4e * Ji ( 2 , 1 ) ) + ( DN4n * Ji ( 2 , 2 ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento - Flex�o
    Bb = zeros ( 3 , 12 );
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 1 , 2  ) = DN1x;
    Bb ( 1 , 5  ) = DN2x;
    Bb ( 1 , 8  ) = DN3x;
    Bb ( 1 , 11 ) = DN4x;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 2 , 3  ) = DN1y;
    Bb ( 2 , 6  ) = DN2y;
    Bb ( 2 , 9  ) = DN3y;
    Bb ( 2 , 12 ) = DN4y;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 3 , 2  ) = DN1y;
    Bb ( 3 , 5  ) = DN2y;
    Bb ( 3 , 8  ) = DN3y;
    Bb ( 3 , 11 ) = DN4y;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 3 , 3  ) = DN1x;
    Bb ( 3 , 6  ) = DN2x;
    Bb ( 3 , 9  ) = DN3x;
    Bb ( 3 , 12 ) = DN4x;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento - Cisalhamento
    Bs = zeros ( 2 , 12 );
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 1 , 1  ) = DN1x;
    Bs ( 1 , 4  ) = DN2x;
    Bs ( 1 , 7  ) = DN3x;
    Bs ( 1 , 10 ) = DN4x;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 1 , 2  ) = - N1;
    Bs ( 1 , 5  ) = - N2;
    Bs ( 1 , 8  ) = - N3;
    Bs ( 1 , 11 ) = - N4;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 2 , 1  ) = DN1y;
    Bs ( 2 , 4  ) = DN2y;
    Bs ( 2 , 7  ) = DN3y;
    Bs ( 2 , 10 ) = DN4y;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 2 , 3  ) = - N1;
    Bs ( 2 , 6  ) = - N2;
    Bs ( 2 , 9  ) = - N3;
    Bs ( 2 , 12 ) = - N4;   
    
end

