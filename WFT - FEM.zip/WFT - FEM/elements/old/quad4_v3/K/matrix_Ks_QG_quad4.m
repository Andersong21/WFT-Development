%% Cria��o da Matriz de Rigidez de Cisalhamento do Elemento Quad4 no Ponto da Quadratura de Gauss

%% INPUT
% Js                - Matriz Jacobiana do Elemento -- Cisalhamento
% Bs                - Matriz de Correla��o Deforma��o Deslocamento de Cisalhamento do Elemento Quad4
% Ds                - Matriz Constitutiva de Cisalhamento do Elemento Quad4

%% OUTPUT
% K1s               - Matriz de Rigidez de Cisalhamento do Elemento Quad4 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez de Cisalhamento do Elemento Quad4 no Ponto da Quadratura de Gauss
function [ K1s ] = matrix_Ks_QG_quad4 ( Js , Bs , Ds )
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DE CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez de Cisalhamento
    Ks = ( ( transpose ( Bs ) * Ds * Bs ) * det ( Js ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local
    K1s = zeros ( 24 , 24 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 1
    K1s ( 3  , 3  ) = Ks ( 1  , 1  );
    K1s ( 3  , 4  ) = Ks ( 1  , 2  );
    K1s ( 3  , 5  ) = Ks ( 1  , 3  );
    K1s ( 3  , 9  ) = Ks ( 1  , 4  );
    K1s ( 3  , 10 ) = Ks ( 1  , 5  );
    K1s ( 3  , 11 ) = Ks ( 1  , 6  );
    K1s ( 3  , 15 ) = Ks ( 1  , 7  );
    K1s ( 3  , 16 ) = Ks ( 1  , 8  );
    K1s ( 3  , 17 ) = Ks ( 1  , 9  );
    K1s ( 3  , 21 ) = Ks ( 1  , 10 );
    K1s ( 3  , 22 ) = Ks ( 1  , 11 );
    K1s ( 3  , 23 ) = Ks ( 1  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 2
    K1s ( 4  , 3  ) = Ks ( 2  , 1  );
    K1s ( 4  , 4  ) = Ks ( 2  , 2  );
    K1s ( 4  , 5  ) = Ks ( 2  , 3  );
    K1s ( 4  , 9  ) = Ks ( 2  , 4  );
    K1s ( 4  , 10 ) = Ks ( 2  , 5  );
    K1s ( 4  , 11 ) = Ks ( 2  , 6  );
    K1s ( 4  , 15 ) = Ks ( 2  , 7  );
    K1s ( 4  , 16 ) = Ks ( 2  , 8  );
    K1s ( 4  , 17 ) = Ks ( 2  , 9  );
    K1s ( 4  , 21 ) = Ks ( 2  , 10 );
    K1s ( 4  , 22 ) = Ks ( 2  , 11 );
    K1s ( 4  , 23 ) = Ks ( 2  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 3
    K1s ( 5  , 3  ) = Ks ( 3  , 1  );
    K1s ( 5  , 4  ) = Ks ( 3  , 2  );
    K1s ( 5  , 5  ) = Ks ( 3  , 3  );
    K1s ( 5  , 9  ) = Ks ( 3  , 4  );
    K1s ( 5  , 10 ) = Ks ( 3  , 5  );
    K1s ( 5  , 11 ) = Ks ( 3  , 6  );
    K1s ( 5  , 15 ) = Ks ( 3  , 7  );
    K1s ( 5  , 16 ) = Ks ( 3  , 8  );
    K1s ( 5  , 17 ) = Ks ( 3  , 9  );
    K1s ( 5  , 21 ) = Ks ( 3  , 10 );
    K1s ( 5  , 22 ) = Ks ( 3  , 11 );
    K1s ( 5  , 23 ) = Ks ( 3  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 4
    K1s ( 9  , 3  ) = Ks ( 4  , 1  );
    K1s ( 9  , 4  ) = Ks ( 4  , 2  );
    K1s ( 9  , 5  ) = Ks ( 4  , 3  );
    K1s ( 9  , 9  ) = Ks ( 4  , 4  );
    K1s ( 9  , 10 ) = Ks ( 4  , 5  );
    K1s ( 9  , 11 ) = Ks ( 4  , 6  );
    K1s ( 9  , 15 ) = Ks ( 4  , 7  );
    K1s ( 9  , 16 ) = Ks ( 4  , 8  );
    K1s ( 9  , 17 ) = Ks ( 4  , 9  );
    K1s ( 9  , 21 ) = Ks ( 4  , 10 );
    K1s ( 9  , 22 ) = Ks ( 4  , 11 );
    K1s ( 9  , 23 ) = Ks ( 4  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 5
    K1s ( 10 , 3  ) = Ks ( 5  , 1  );
    K1s ( 10 , 4  ) = Ks ( 5  , 2  );
    K1s ( 10 , 5  ) = Ks ( 5  , 3  );
    K1s ( 10 , 9  ) = Ks ( 5  , 4  );
    K1s ( 10 , 10 ) = Ks ( 5  , 5  );
    K1s ( 10 , 11 ) = Ks ( 5  , 6  );
    K1s ( 10 , 15 ) = Ks ( 5  , 7  );
    K1s ( 10 , 16 ) = Ks ( 5  , 8  );
    K1s ( 10 , 17 ) = Ks ( 5  , 9  );
    K1s ( 10 , 21 ) = Ks ( 5  , 10 );
    K1s ( 10 , 22 ) = Ks ( 5  , 11 );
    K1s ( 10 , 23 ) = Ks ( 5  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 6
    K1s ( 11 , 3  ) = Ks ( 6  , 1  );
    K1s ( 11 , 4  ) = Ks ( 6  , 2  );
    K1s ( 11 , 5  ) = Ks ( 6  , 3  );
    K1s ( 11 , 9  ) = Ks ( 6  , 4  );
    K1s ( 11 , 10 ) = Ks ( 6  , 5  );
    K1s ( 11 , 11 ) = Ks ( 6  , 6  );
    K1s ( 11 , 15 ) = Ks ( 6  , 7  );
    K1s ( 11 , 16 ) = Ks ( 6  , 8  );
    K1s ( 11 , 17 ) = Ks ( 6  , 9  );
    K1s ( 11 , 21 ) = Ks ( 6  , 10 );
    K1s ( 11 , 22 ) = Ks ( 6  , 11 );
    K1s ( 11 , 23 ) = Ks ( 6  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 7
    K1s ( 15 , 3  ) = Ks ( 7  , 1  );
    K1s ( 15 , 4  ) = Ks ( 7  , 2  );
    K1s ( 15 , 5  ) = Ks ( 7  , 3  );
    K1s ( 15 , 9  ) = Ks ( 7  , 4  );
    K1s ( 15 , 10 ) = Ks ( 7  , 5  );
    K1s ( 15 , 11 ) = Ks ( 7  , 6  );
    K1s ( 15 , 15 ) = Ks ( 7  , 7  );
    K1s ( 15 , 16 ) = Ks ( 7  , 8  );
    K1s ( 15 , 17 ) = Ks ( 7  , 9  );
    K1s ( 15 , 21 ) = Ks ( 7  , 10 );
    K1s ( 15 , 22 ) = Ks ( 7  , 11 );
    K1s ( 15 , 23 ) = Ks ( 7  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 8
    K1s ( 16 , 3  ) = Ks ( 8  , 1  );
    K1s ( 16 , 4  ) = Ks ( 8  , 2  );
    K1s ( 16 , 5  ) = Ks ( 8  , 3  );
    K1s ( 16 , 9  ) = Ks ( 8  , 4  );
    K1s ( 16 , 10 ) = Ks ( 8  , 5  );
    K1s ( 16 , 11 ) = Ks ( 8  , 6  );
    K1s ( 16 , 15 ) = Ks ( 8  , 7  );
    K1s ( 16 , 16 ) = Ks ( 8  , 8  );
    K1s ( 16 , 17 ) = Ks ( 8  , 9  );
    K1s ( 16 , 21 ) = Ks ( 8  , 10 );
    K1s ( 16 , 22 ) = Ks ( 8  , 11 );
    K1s ( 16 , 23 ) = Ks ( 8  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 9
    K1s ( 17 , 3  ) = Ks ( 9  , 1  );
    K1s ( 17 , 4  ) = Ks ( 9  , 2  );
    K1s ( 17 , 5  ) = Ks ( 9  , 3  );
    K1s ( 17 , 9  ) = Ks ( 9  , 4  );
    K1s ( 17 , 10 ) = Ks ( 9  , 5  );
    K1s ( 17 , 11 ) = Ks ( 9  , 6  );
    K1s ( 17 , 15 ) = Ks ( 9  , 7  );
    K1s ( 17 , 16 ) = Ks ( 9  , 8  );
    K1s ( 17 , 17 ) = Ks ( 9  , 9  );
    K1s ( 17 , 21 ) = Ks ( 9  , 10 );
    K1s ( 17 , 22 ) = Ks ( 9  , 11 );
    K1s ( 17 , 23 ) = Ks ( 9  , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 10
    K1s ( 21 , 3  ) = Ks ( 10 , 1  );
    K1s ( 21 , 4  ) = Ks ( 10 , 2  );
    K1s ( 21 , 5  ) = Ks ( 10 , 3  );
    K1s ( 21 , 9  ) = Ks ( 10 , 4  );
    K1s ( 21 , 10 ) = Ks ( 10 , 5  );
    K1s ( 21 , 11 ) = Ks ( 10 , 6  );
    K1s ( 21 , 15 ) = Ks ( 10 , 7  );
    K1s ( 21 , 16 ) = Ks ( 10 , 8  );
    K1s ( 21 , 17 ) = Ks ( 10 , 9  );
    K1s ( 21 , 21 ) = Ks ( 10 , 10 );
    K1s ( 21 , 22 ) = Ks ( 10 , 11 );
    K1s ( 21 , 23 ) = Ks ( 10 , 12 );

    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 11
    K1s ( 22 , 3  ) = Ks ( 11 , 1  );
    K1s ( 22 , 4  ) = Ks ( 11 , 2  );
    K1s ( 22 , 5  ) = Ks ( 11 , 3  );
    K1s ( 22 , 9  ) = Ks ( 11 , 4  );
    K1s ( 22 , 10 ) = Ks ( 11 , 5  );
    K1s ( 22 , 11 ) = Ks ( 11 , 6  );
    K1s ( 22 , 15 ) = Ks ( 11 , 7  );
    K1s ( 22 , 16 ) = Ks ( 11 , 8  );
    K1s ( 22 , 17 ) = Ks ( 11 , 9  );
    K1s ( 22 , 21 ) = Ks ( 11 , 10 );
    K1s ( 22 , 22 ) = Ks ( 11 , 11 );
    K1s ( 22 , 23 ) = Ks ( 11 , 12 );
    
    % Aloca��o dos Termos da Matriz de Flex�o -- LINHA 12
    K1s ( 23 , 3  ) = Ks ( 12 , 1  );
    K1s ( 23 , 4  ) = Ks ( 12 , 2  );
    K1s ( 23 , 5  ) = Ks ( 12 , 3  );
    K1s ( 23 , 9  ) = Ks ( 12 , 4  );
    K1s ( 23 , 10 ) = Ks ( 12 , 5  );
    K1s ( 23 , 11 ) = Ks ( 12 , 6  );
    K1s ( 23 , 15 ) = Ks ( 12 , 7  );
    K1s ( 23 , 16 ) = Ks ( 12 , 8  );
    K1s ( 23 , 17 ) = Ks ( 12 , 9  );
    K1s ( 23 , 21 ) = Ks ( 12 , 10 );
    K1s ( 23 , 22 ) = Ks ( 12 , 11 );
    K1s ( 23 , 23 ) = Ks ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA RIGIDEZ DE ROTA��O PERPENDICULAR A PLACA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % M�ximo Valor de Rigidez da Matriz do Elemento
    Kmax = max ( K1s ( : ) );
    
    % Rigidez de Rota��o Perpendicular a Placa
    Krot = Kmax / 1000;
    
    % Aloca��o da Rigidez de Rota��o Perpendicular a Placa na Matriz
    K1s ( 6  , 6  ) = Krot;
    K1s ( 12 , 12 ) = Krot;
    K1s ( 18 , 18 ) = Krot;
    K1s ( 24 , 24 ) = Krot;

end

