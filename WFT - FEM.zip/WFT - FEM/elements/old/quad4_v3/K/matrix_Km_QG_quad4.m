%% Cria��o da Matriz de Rigidez de Membrana do Elemento Quad4 no Ponto da Quadratura de Gauss

%% INPUT
% t                 - Espessura do Elemento
% Jm                - Matriz Jacobiana do Elemento -- Membrana
% Bm                - Matriz de Correla��o Deforma��o Deslocamento de Membrana do Elemento Quad4
% Dm                - Matriz Constitutiva de Membrana do Elemento Quad4

%% OUTPUT
% K1m                - Matriz de Rigidez do Elemento Quad4 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez de Membrana do Elemento Quad4 no Ponto da Quadratura de Gauss
function [ K1m ] = matrix_Km_QG_quad4 ( t , Jm , Bm , Dm )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez de Membrana
    Km = t * ( transpose ( Bm ) * Dm * Bm ) * det ( Jm );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local
    K1m = zeros ( 24 , 24 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 1
    K1m ( 1  , 1  ) = Km ( 1 , 1 );
    K1m ( 1  , 2  ) = Km ( 1 , 2 );
    K1m ( 1  , 7  ) = Km ( 1 , 3 );
    K1m ( 1  , 8  ) = Km ( 1 , 4 );
    K1m ( 1  , 13 ) = Km ( 1 , 5 );
    K1m ( 1  , 14 ) = Km ( 1 , 6 );
    K1m ( 1  , 19 ) = Km ( 1 , 7 );
    K1m ( 1  , 20 ) = Km ( 1 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 2
    K1m ( 2  , 1  ) = Km ( 2 , 1 );
    K1m ( 2  , 2  ) = Km ( 2 , 2 );
    K1m ( 2  , 7  ) = Km ( 2 , 3 );
    K1m ( 2  , 8  ) = Km ( 2 , 4 );
    K1m ( 2  , 13 ) = Km ( 2 , 5 );
    K1m ( 2  , 14 ) = Km ( 2 , 6 );
    K1m ( 2  , 19 ) = Km ( 2 , 7 );
    K1m ( 2  , 20 ) = Km ( 2 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 3
    K1m ( 7  , 1  ) = Km ( 3 , 1 );
    K1m ( 7  , 2  ) = Km ( 3 , 2 );
    K1m ( 7  , 7  ) = Km ( 3 , 3 );
    K1m ( 7  , 8  ) = Km ( 3 , 4 );
    K1m ( 7  , 13 ) = Km ( 3 , 5 );
    K1m ( 7  , 14 ) = Km ( 3 , 6 );
    K1m ( 7  , 19 ) = Km ( 3 , 7 );
    K1m ( 7  , 20 ) = Km ( 3 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 4
    K1m ( 8  , 1  ) = Km ( 4 , 1 );
    K1m ( 8  , 2  ) = Km ( 4 , 2 );
    K1m ( 8  , 7  ) = Km ( 4 , 3 );
    K1m ( 8  , 8  ) = Km ( 4 , 4 );
    K1m ( 8  , 13 ) = Km ( 4 , 5 );
    K1m ( 8  , 14 ) = Km ( 4 , 6 );
    K1m ( 8  , 19 ) = Km ( 4 , 7 );
    K1m ( 8  , 20 ) = Km ( 4 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 5
    K1m ( 13 , 1  ) = Km ( 5 , 1 );
    K1m ( 13 , 2  ) = Km ( 5 , 2 );
    K1m ( 13 , 7  ) = Km ( 5 , 3 );
    K1m ( 13 , 8  ) = Km ( 5 , 4 );
    K1m ( 13 , 13 ) = Km ( 5 , 5 );
    K1m ( 13 , 14 ) = Km ( 5 , 6 );
    K1m ( 13 , 19 ) = Km ( 5 , 7 );
    K1m ( 13 , 20 ) = Km ( 5 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 6
    K1m ( 14 , 1  ) = Km ( 6 , 1 );
    K1m ( 14 , 2  ) = Km ( 6 , 2 );
    K1m ( 14 , 7  ) = Km ( 6 , 3 );
    K1m ( 14 , 8  ) = Km ( 6 , 4 );
    K1m ( 14 , 13 ) = Km ( 6 , 5 );
    K1m ( 14 , 14 ) = Km ( 6 , 6 );
    K1m ( 14 , 19 ) = Km ( 6 , 7 );
    K1m ( 14 , 20 ) = Km ( 6 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 7
    K1m ( 19 , 1  ) = Km ( 7 , 1 );
    K1m ( 19 , 2  ) = Km ( 7 , 2 );
    K1m ( 19 , 7  ) = Km ( 7 , 3 );
    K1m ( 19 , 8  ) = Km ( 7 , 4 );
    K1m ( 19 , 13 ) = Km ( 7 , 5 );
    K1m ( 19 , 14 ) = Km ( 7 , 6 );
    K1m ( 19 , 19 ) = Km ( 7 , 7 );
    K1m ( 19 , 20 ) = Km ( 7 , 8 );
    
    % Aloca��o dos Termos da Matriz de Rigidez de Membrana -- LINHA 8
    K1m ( 20 , 1  ) = Km ( 8 , 1 );
    K1m ( 20 , 2  ) = Km ( 8 , 2 );
    K1m ( 20 , 7  ) = Km ( 8 , 3 );
    K1m ( 20 , 8  ) = Km ( 8 , 4 );
    K1m ( 20 , 13 ) = Km ( 8 , 5 );
    K1m ( 20 , 14 ) = Km ( 8 , 6 );
    K1m ( 20 , 19 ) = Km ( 8 , 7 );
    K1m ( 20 , 20 ) = Km ( 8 , 8 );
    
end
    
    