%% Cria��o da Matriz de Rigidez do Elemento Quad4

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento i

%% OUTPUT
% Ki                - Termo i da Matriz de Rigidez Global
% Kj                - Termo j da Matriz de Rigidez Global
% Kv                - Valor ( i , j ) da Matriz de Rigidez Global

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez do Elemento
function [ Ki , Kj , Kv ] = matrix_K_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE PESOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Pesos na Quadratura de Gauss
    [ WEm , WEb , WEs ] = matrix_WE_quad4 ();
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DOS PONTOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz dos Pontos na Quadratura de Gauss
    [ POm , POb , POs ] = matrix_PO_quad4 ();

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_quad4 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_quad4 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_quad4 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva e Espessura do Elemento
    [ t , Dm , Db , Ds ] = matrix_D_quad4 ( Elem_Param , Mat_Param , Prop_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez de Membrana Local Final
    Klm = zeros ( 24 , 24 );
    
    % Varredura nos Pontos e da Quadratura de Gauss
    for j = 1:2
        
        % Varredura nos Pontos n da Quadratura de Gauss
        for k = 1:2
                            
            % Ponto na Quadratura -- e
            e = POm ( j , 1 );

            % Ponto na Quadratura -- n
            n = POm ( k , 1 );

            %%%%%%%%%%%%%%%%%%%%
            % MATRIZ JACOBIANA %
            %%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz Jacobiana
            [ Jm ] = matrix_Jm_quad4 ( e , n , Cl );         

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
            [ Bm ] = matrix_Bm_quad4 ( e , n , Jm );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz de Rigidez de Membrana no Ponto de Integra��o
            [ K1m ] = matrix_Km_QG_quad4 ( t , Jm , Bm , Dm );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Matriz de Rigidez de Membrana no Ponto de Integra��o
            Klm = Klm + ( WEm ( j ) * WEm ( k ) * K1m ); 
            
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez de Flex�o Local Final
    Klb = zeros ( 24 , 24 );
    
    % Varredura nos Pontos e da Quadratura de Gauss
    for j = 1:2
        
        % Varredura nos Pontos n da Quadratura de Gauss
        for k = 1:2
                            
            % Ponto na Quadratura -- e
            e = POb ( j , 1 );

            % Ponto na Quadratura -- n
            n = POb ( k , 1 );

            %%%%%%%%%%%%%%%%%%%%
            % MATRIZ JACOBIANA %
            %%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz Jacobiana
            [ Jb ] = matrix_Jb_quad4 ( e , n , Cl );         

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
            [ Bb ] = matrix_Bb_quad4 ( e , n , Jb );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz de Rigidez de Flex�o no Ponto de Integra��o
            [ K1b ] = matrix_Kb_QG_quad4 ( Jb , Bb , Db );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Matriz de Rigidez de Flex�o no Ponto de Integra��o
            Klb = Klb + ( WEb ( j ) * WEb ( k ) * K1b ); 
            
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez de Flex�o Local Final
    Kls = zeros ( 24 , 24 );
    
    % Varredura nos Pontos e da Quadratura de Gauss
    for j = 1:1
        
        % Varredura nos Pontos n da Quadratura de Gauss
        for k = 1:1
                            
            % Ponto na Quadratura -- e
            e = POs ( j , 1 );

            % Ponto na Quadratura -- n
            n = POs ( k , 1 );

            %%%%%%%%%%%%%%%%%%%%
            % MATRIZ JACOBIANA %
            %%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz Jacobiana
            [ Js ] = matrix_Js_quad4 ( e , n , Cl );         

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
            [ Bs ] = matrix_Bs_quad4 ( e , n , Js );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Retorno da Matriz de Rigidez de Flex�o no Ponto de Integra��o
            [ K1s ] = matrix_Ks_QG_quad4 ( Js , Bs , Ds );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Matriz de Rigidez de Flex�o no Ponto de Integra��o
            Kls = Kls + ( WEs ( j ) * WEs ( k ) * K1s ); 
            
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Rigidez Local do Elemento
    Kl = Klm + Klb + Kls;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO % GLOBAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Global do Elemento
    Kg = R * Kl * transpose ( R );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE GRAUS DE LIBERDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador de Graus de Liberdade do Elemento
    Ndof = 1;
    
    % Inicializa��o do Vetor de Graus de Liberdade
    DOF = zeros ( 24 , 1 );
    
    % Varredura nos N�s do Elemento
    for j = 1:length( Elem_Param ( i ).node )
       
        % Id do N�
        Idn = Elem_Param ( i ).node ( j );
        
        % Varredura nos Graus de Liberdade dos N�s do Elemento
        for k = 1:length ( Node_Param ( Idn ).dof )            
            
            % Aloca��o no Vetor de Graus de Liberdade
            DOF ( Ndof ) = Node_Param ( Idn ).dof ( k );
            
            % Incremento na Contagem de Graus de Liberdade
            Ndof = Ndof + 1;
            
        end         
        
    end
    
    % Inicializa��o do Contador
    cont = 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o na Matriz de Rigidez Global do Problema
    for j = 1:24
        
        % Verifica��o se o Grau de Liberdade � nulo
        if ( DOF ( j ) == 0 )
            
            % Continuar
            continue;
            
        else      
            
            % Aloca��o na Matriz de Rigidez Global do Problema        
            for k = 1:24

                % Verifica��o se o Grau de Liberdade � nulo
                if ( DOF ( k ) == 0 )
                    
                    % Continuar
                    continue;
                
                else
                    
                    % Aloca��o Sim�trica
                    if ( j > k )
                        
                        % Continuar
                        continue;
                    end
                    
                    % Aloca��o de Termo Nulo
                    if ( Kg ( j , k ) == 0 )
                        
                        % Continuar
                        continue;
                        
                    end

                    % Aloca��o dos Termos da Matriz na Posi��o Global
                    Ki ( cont ) = DOF ( j );
                    Kj ( cont ) = DOF ( k );
                    Kv ( cont ) = Kg ( j , k );
                    
                    % Incremento do Contador
                    cont = cont + 1;

                end
                
            end
            
        end
        
    end
    
end

