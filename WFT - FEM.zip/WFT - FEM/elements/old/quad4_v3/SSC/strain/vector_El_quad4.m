%% Cria��o do Vetor de Deforma��es Locais do Elemento Quad4

%% INPUT
% Bm                - Matriz de Correla��o Deslocamento Deforma��o de Membrana do Elemento Quad4
% Bb                - Matriz de Correla��o Deslocamento Deforma��o de Flex�o do Elemento Quad4
% Bs                - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento do Elemento Quad4
% Ul                - Vetor de Deforma��es Locais
% t                 - Espessura do Elemento

%% OUTPUT
% ElE               - Vetor de Deforma��o Local no Layer E
% ElF               - Vetor de Deforma��o Local no Layer F
% ElG               - Vetor de Deforma��o Local no Layer G

%% Declara��o da Fun��o de Cria��o Vetor de Deforma��es Locais do Elemento Quad4
function [ ElE , ElF , ElG ] = vector_El_quad4 ( Bm , Bb , Bs , Ul , t )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos de Membrana
    Ulm = zeros ( 8 , 1 );
    
    % Aloca��o do Vetor de Deslocamento de Membrana
    Ulm ( 1 , 1 ) = Ul ( 1   , 1 );
    Ulm ( 2 , 1 ) = Ul ( 2   , 1 );
    Ulm ( 3 , 1 ) = Ul ( 7   , 1 );
    Ulm ( 4 , 1 ) = Ul ( 8   , 1 );
    Ulm ( 5 , 1 ) = Ul ( 13  , 1 );
    Ulm ( 6 , 1 ) = Ul ( 14  , 1 );
    Ulm ( 7 , 1 ) = Ul ( 19  , 1 );
    Ulm ( 8 , 1 ) = Ul ( 20  , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos de Flex�o
    Ulb = zeros ( 12 , 1 );
    
    % Aloca��o do Vetor de Deslocamento de Flex�o
    Ulb ( 1  , 1 ) = Ul ( 3   , 1 );
    Ulb ( 2  , 1 ) = Ul ( 4   , 1 );
    Ulb ( 3  , 1 ) = Ul ( 5   , 1 );
    Ulb ( 4  , 1 ) = Ul ( 9   , 1 );
    Ulb ( 5  , 1 ) = Ul ( 10  , 1 );
    Ulb ( 6  , 1 ) = Ul ( 11  , 1 );
    Ulb ( 7  , 1 ) = Ul ( 15  , 1 );
    Ulb ( 8  , 1 ) = Ul ( 16  , 1 );
    Ulb ( 9  , 1 ) = Ul ( 17  , 1 );
    Ulb ( 10 , 1 ) = Ul ( 21  , 1 );
    Ulb ( 11 , 1 ) = Ul ( 22  , 1 );
    Ulb ( 12 , 1 ) = Ul ( 23  , 1 );  
    
    %%%%%%%%%%%
    % LAYER E %
    %%%%%%%%%%%
    
    % Determina��o do Vetor de Deforma��es de Membrana
    E_mem  = Bm * Ulm;
    
    % Determina��o do Vetor de Deforma��es de Cisalhamento
    E_mem2 = ( Bs * Ulb );
    
    % Vetor de Deforma��es Locais do Layer E
    ElE ( 1 ) = E_mem  ( 1 ); 
    ElE ( 2 ) = E_mem  ( 2 );
    ElE ( 3 ) = 0;
    ElE ( 4 ) = E_mem  ( 3 ) / 2;
%     ElE ( 5 ) = E_mem2 ( 2 );
%     ElE ( 6 ) = E_mem2 ( 1 );
    ElE ( 5 ) = 0;
    ElE ( 6 ) = 0;
    
    %%%%%%%%%%%
    % LAYER F %
    %%%%%%%%%%%
    
    % Espessura
    z = + ( t / 2 );
    
    % Determina��o do Vetor de Deforma��es de Flex�o
    E_b1 = - z  * ( Bb * Ulb );
    
    % Vetor de Deforma��es Locais do Layer F
    ElF ( 1 ) = E_b1 ( 1 ); 
    ElF ( 2 ) = E_b1 ( 2 );
    ElF ( 3 ) = 0;
    ElF ( 4 ) = E_b1 ( 3 );
%     ElF ( 5 ) = E_mem2 ( 2 );
%     ElF ( 6 ) = E_mem2 ( 1 );
    ElF ( 5 ) = 0;
    ElF ( 6 ) = 0;

    
    %%%%%%%%%%%
    % LAYER G %
    %%%%%%%%%%%
    
    % Espessura
    z = - ( t / 2 );
    
    % Determina��o do Vetor de Deforma��es de Flex�o
    E_b2 = - z * ( Bb * Ulb );
    
    % Vetor de Deforma��es Locais do Layer G
    ElG ( 1 ) = E_b2 ( 1 ); 
    ElG ( 2 ) = E_b2 ( 2 );
    ElG ( 3 ) = 0;
    ElG ( 4 ) = E_b2 ( 3 );
%     ElG ( 5 ) = E_mem2 ( 2 );
%     ElG ( 6 ) = E_mem2 ( 1 );  
    ElG ( 5 ) = 0;
    ElG ( 6 ) = 0;
    
end

