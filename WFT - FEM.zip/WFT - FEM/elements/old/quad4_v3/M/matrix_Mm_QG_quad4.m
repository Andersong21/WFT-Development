%% Cria��o da Matriz de Massa de Membrana do Elemento Quad4 no Ponto da Quadratura de Gauss

%% INPUT
% rho               - Densidade do Elemento Quad4
% t                 - Espessura do Elemento
% Jm                - Matriz Jacobiana do Elemento -- Membrana
% Hm                - Matriz de Fun��es de Forma de Membrana do Elemento Quad4

%% OUTPUT
% M1m               - Matriz de Massa de Membrana do Elemento Quad4 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa de Membrana do Elemento Quad4 no Ponto da Quadratura de Gauss
function [ M1m ] = matrix_Mm_QG_quad4 ( rho , t , Jm , Hm )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa de Membrana
    Mm = ( t * rho ) * ( transpose ( Hm ) * Hm ) * det ( Jm );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local
    M1m = zeros ( 24 , 24 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 1
    M1m ( 1  , 1  ) = Mm ( 1 , 1 );
    M1m ( 1  , 2  ) = Mm ( 1 , 2 );
    M1m ( 1  , 7  ) = Mm ( 1 , 3 );
    M1m ( 1  , 8  ) = Mm ( 1 , 4 );
    M1m ( 1  , 13 ) = Mm ( 1 , 5 );
    M1m ( 1  , 14 ) = Mm ( 1 , 6 );
    M1m ( 1  , 19 ) = Mm ( 1 , 7 );
    M1m ( 1  , 20 ) = Mm ( 1 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 2
    M1m ( 2  , 1  ) = Mm ( 2 , 1 );
    M1m ( 2  , 2  ) = Mm ( 2 , 2 );
    M1m ( 2  , 7  ) = Mm ( 2 , 3 );
    M1m ( 2  , 8  ) = Mm ( 2 , 4 );
    M1m ( 2  , 13 ) = Mm ( 2 , 5 );
    M1m ( 2  , 14 ) = Mm ( 2 , 6 );
    M1m ( 2  , 19 ) = Mm ( 2 , 7 );
    M1m ( 2  , 20 ) = Mm ( 2 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 3
    M1m ( 7  , 1  ) = Mm ( 3 , 1 );
    M1m ( 7  , 2  ) = Mm ( 3 , 2 );
    M1m ( 7  , 7  ) = Mm ( 3 , 3 );
    M1m ( 7  , 8  ) = Mm ( 3 , 4 );
    M1m ( 7  , 13 ) = Mm ( 3 , 5 );
    M1m ( 7  , 14 ) = Mm ( 3 , 6 );
    M1m ( 7  , 19 ) = Mm ( 3 , 7 );
    M1m ( 7  , 20 ) = Mm ( 3 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 4
    M1m ( 8  , 1  ) = Mm ( 4 , 1 );
    M1m ( 8  , 2  ) = Mm ( 4 , 2 );
    M1m ( 8  , 7  ) = Mm ( 4 , 3 );
    M1m ( 8  , 8  ) = Mm ( 4 , 4 );
    M1m ( 8  , 13 ) = Mm ( 4 , 5 );
    M1m ( 8  , 14 ) = Mm ( 4 , 6 );
    M1m ( 8  , 19 ) = Mm ( 4 , 7 );
    M1m ( 8  , 20 ) = Mm ( 4 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 5
    M1m ( 13 , 1  ) = Mm ( 5 , 1 );
    M1m ( 13 , 2  ) = Mm ( 5 , 2 );
    M1m ( 13 , 7  ) = Mm ( 5 , 3 );
    M1m ( 13 , 8  ) = Mm ( 5 , 4 );
    M1m ( 13 , 13 ) = Mm ( 5 , 5 );
    M1m ( 13 , 14 ) = Mm ( 5 , 6 );
    M1m ( 13 , 19 ) = Mm ( 5 , 7 );
    M1m ( 13 , 20 ) = Mm ( 5 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 6
    M1m ( 14 , 1  ) = Mm ( 6 , 1 );
    M1m ( 14 , 2  ) = Mm ( 6 , 2 );
    M1m ( 14 , 7  ) = Mm ( 6 , 3 );
    M1m ( 14 , 8  ) = Mm ( 6 , 4 );
    M1m ( 14 , 13 ) = Mm ( 6 , 5 );
    M1m ( 14 , 14 ) = Mm ( 6 , 6 );
    M1m ( 14 , 19 ) = Mm ( 6 , 7 );
    M1m ( 14 , 20 ) = Mm ( 6 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 7
    M1m ( 19 , 1  ) = Mm ( 7 , 1 );
    M1m ( 19 , 2  ) = Mm ( 7 , 2 );
    M1m ( 19 , 7  ) = Mm ( 7 , 3 );
    M1m ( 19 , 8  ) = Mm ( 7 , 4 );
    M1m ( 19 , 13 ) = Mm ( 7 , 5 );
    M1m ( 19 , 14 ) = Mm ( 7 , 6 );
    M1m ( 19 , 19 ) = Mm ( 7 , 7 );
    M1m ( 19 , 20 ) = Mm ( 7 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 8
    M1m ( 20 , 1  ) = Mm ( 8 , 1 );
    M1m ( 20 , 2  ) = Mm ( 8 , 2 );
    M1m ( 20 , 7  ) = Mm ( 8 , 3 );
    M1m ( 20 , 8  ) = Mm ( 8 , 4 );
    M1m ( 20 , 13 ) = Mm ( 8 , 5 );
    M1m ( 20 , 14 ) = Mm ( 8 , 6 );
    M1m ( 20 , 19 ) = Mm ( 8 , 7 );
    M1m ( 20 , 20 ) = Mm ( 8 , 8 );   

end

