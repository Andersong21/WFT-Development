%% Cria��o da Matriz de Massa de Flex�o do Elemento Quad4 no Ponto da Quadratura de Gauss

%% INPUT
% I                 - Matriz de Densidade de Placa do Elemento Quad4
% t                 - Espessura do Elemento
% Jb                - Matriz Jacobiana do Elemento -- Placa
% Hb                - Matriz de Fun��es de Forma de Flex�o do Elemento Quad4

%% OUTPUT
% M1b               - Matriz de Massa de Flex�o do Elemento Quad4 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa de Flex�o do Elemento Quad4 no Ponto da Quadratura de Gauss
function [ M1b ] = matrix_Mb_QG_quad4 ( I , t , Jb , Hb )
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa de Flex�o
    Mb = ( t ) * ( transpose ( Hb ) * I * Hb ) * ( det ( Jb ) / 2 );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local
    M1b = zeros ( 24 , 24 );   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 1
    M1b ( 3  , 3  ) = Mb ( 1  , 1  );
    M1b ( 3  , 4  ) = Mb ( 1  , 2  );
    M1b ( 3  , 5  ) = Mb ( 1  , 3  );
    M1b ( 3  , 9  ) = Mb ( 1  , 4  );
    M1b ( 3  , 10 ) = Mb ( 1  , 5  );
    M1b ( 3  , 11 ) = Mb ( 1  , 6  );
    M1b ( 3  , 15 ) = Mb ( 1  , 7  );
    M1b ( 3  , 16 ) = Mb ( 1  , 8  );
    M1b ( 3  , 17 ) = Mb ( 1  , 9  );
    M1b ( 3  , 21 ) = Mb ( 1  , 10 );
    M1b ( 3  , 22 ) = Mb ( 1  , 11 );
    M1b ( 3  , 23 ) = Mb ( 1  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 2
    M1b ( 4  , 3  ) = Mb ( 2  , 1  );
    M1b ( 4  , 4  ) = Mb ( 2  , 2  );
    M1b ( 4  , 5  ) = Mb ( 2  , 3  );
    M1b ( 4  , 9  ) = Mb ( 2  , 4  );
    M1b ( 4  , 10 ) = Mb ( 2  , 5  );
    M1b ( 4  , 11 ) = Mb ( 2  , 6  );
    M1b ( 4  , 15 ) = Mb ( 2  , 7  );
    M1b ( 4  , 16 ) = Mb ( 2  , 8  );
    M1b ( 4  , 17 ) = Mb ( 2  , 9  );
    M1b ( 4  , 21 ) = Mb ( 2  , 10 );
    M1b ( 4  , 22 ) = Mb ( 2  , 11 );
    M1b ( 4  , 23 ) = Mb ( 2  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 3
    M1b ( 5  , 3  ) = Mb ( 3  , 1  );
    M1b ( 5  , 4  ) = Mb ( 3  , 2  );
    M1b ( 5  , 5  ) = Mb ( 3  , 3  );
    M1b ( 5  , 9  ) = Mb ( 3  , 4  );
    M1b ( 5  , 10 ) = Mb ( 3  , 5  );
    M1b ( 5  , 11 ) = Mb ( 3  , 6  );
    M1b ( 5  , 15 ) = Mb ( 3  , 7  );
    M1b ( 5  , 16 ) = Mb ( 3  , 8  );
    M1b ( 5  , 17 ) = Mb ( 3  , 9  );
    M1b ( 5  , 21 ) = Mb ( 3  , 10 );
    M1b ( 5  , 22 ) = Mb ( 3  , 11 );
    M1b ( 5  , 23 ) = Mb ( 3  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 4
    M1b ( 9  , 3  ) = Mb ( 4  , 1  );
    M1b ( 9  , 4  ) = Mb ( 4  , 2  );
    M1b ( 9  , 5  ) = Mb ( 4  , 3  );
    M1b ( 9  , 9  ) = Mb ( 4  , 4  );
    M1b ( 9  , 10 ) = Mb ( 4  , 5  );
    M1b ( 9  , 11 ) = Mb ( 4  , 6  );
    M1b ( 9  , 15 ) = Mb ( 4  , 7  );
    M1b ( 9  , 16 ) = Mb ( 4  , 8  );
    M1b ( 9  , 17 ) = Mb ( 4  , 9  );
    M1b ( 9  , 21 ) = Mb ( 4  , 10 );
    M1b ( 9  , 22 ) = Mb ( 4  , 11 );
    M1b ( 9  , 23 ) = Mb ( 4  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 5
    M1b ( 10 , 3  ) = Mb ( 5  , 1  );
    M1b ( 10 , 4  ) = Mb ( 5  , 2  );
    M1b ( 10 , 5  ) = Mb ( 5  , 3  );
    M1b ( 10 , 9  ) = Mb ( 5  , 4  );
    M1b ( 10 , 10 ) = Mb ( 5  , 5  );
    M1b ( 10 , 11 ) = Mb ( 5  , 6  );
    M1b ( 10 , 15 ) = Mb ( 5  , 7  );
    M1b ( 10 , 16 ) = Mb ( 5  , 8  );
    M1b ( 10 , 17 ) = Mb ( 5  , 9  );
    M1b ( 10 , 21 ) = Mb ( 5  , 10 );
    M1b ( 10 , 22 ) = Mb ( 5  , 11 );
    M1b ( 10 , 23 ) = Mb ( 5  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 6
    M1b ( 11 , 3  ) = Mb ( 6  , 1  );
    M1b ( 11 , 4  ) = Mb ( 6  , 2  );
    M1b ( 11 , 5  ) = Mb ( 6  , 3  );
    M1b ( 11 , 9  ) = Mb ( 6  , 4  );
    M1b ( 11 , 10 ) = Mb ( 6  , 5  );
    M1b ( 11 , 11 ) = Mb ( 6  , 6  );
    M1b ( 11 , 15 ) = Mb ( 6  , 7  );
    M1b ( 11 , 16 ) = Mb ( 6  , 8  );
    M1b ( 11 , 17 ) = Mb ( 6  , 9  );
    M1b ( 11 , 21 ) = Mb ( 6  , 10 );
    M1b ( 11 , 22 ) = Mb ( 6  , 11 );
    M1b ( 11 , 23 ) = Mb ( 6  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 7
    M1b ( 15 , 3  ) = Mb ( 7  , 1  );
    M1b ( 15 , 4  ) = Mb ( 7  , 2  );
    M1b ( 15 , 5  ) = Mb ( 7  , 3  );
    M1b ( 15 , 9  ) = Mb ( 7  , 4  );
    M1b ( 15 , 10 ) = Mb ( 7  , 5  );
    M1b ( 15 , 11 ) = Mb ( 7  , 6  );
    M1b ( 15 , 15 ) = Mb ( 7  , 7  );
    M1b ( 15 , 16 ) = Mb ( 7  , 8  );
    M1b ( 15 , 17 ) = Mb ( 7  , 9  );
    M1b ( 15 , 21 ) = Mb ( 7  , 10 );
    M1b ( 15 , 22 ) = Mb ( 7  , 11 );
    M1b ( 15 , 23 ) = Mb ( 7  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 8
    M1b ( 16 , 3  ) = Mb ( 8  , 1  );
    M1b ( 16 , 4  ) = Mb ( 8  , 2  );
    M1b ( 16 , 5  ) = Mb ( 8  , 3  );
    M1b ( 16 , 9  ) = Mb ( 8  , 4  );
    M1b ( 16 , 10 ) = Mb ( 8  , 5  );
    M1b ( 16 , 11 ) = Mb ( 8  , 6  );
    M1b ( 16 , 15 ) = Mb ( 8  , 7  );
    M1b ( 16 , 16 ) = Mb ( 8  , 8  );
    M1b ( 16 , 17 ) = Mb ( 8  , 9  );
    M1b ( 16 , 21 ) = Mb ( 8  , 10 );
    M1b ( 16 , 22 ) = Mb ( 8  , 11 );
    M1b ( 16 , 23 ) = Mb ( 8  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 9
    M1b ( 17 , 3  ) = Mb ( 9  , 1  );
    M1b ( 17 , 4  ) = Mb ( 9  , 2  );
    M1b ( 17 , 5  ) = Mb ( 9  , 3  );
    M1b ( 17 , 9  ) = Mb ( 9  , 4  );
    M1b ( 17 , 10 ) = Mb ( 9  , 5  );
    M1b ( 17 , 11 ) = Mb ( 9  , 6  );
    M1b ( 17 , 15 ) = Mb ( 9  , 7  );
    M1b ( 17 , 16 ) = Mb ( 9  , 8  );
    M1b ( 17 , 17 ) = Mb ( 9  , 9  );
    M1b ( 17 , 21 ) = Mb ( 9  , 10 );
    M1b ( 17 , 22 ) = Mb ( 9  , 11 );
    M1b ( 17 , 23 ) = Mb ( 9  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 10
    M1b ( 21 , 3  ) = Mb ( 10 , 1  );
    M1b ( 21 , 4  ) = Mb ( 10 , 2  );
    M1b ( 21 , 5  ) = Mb ( 10 , 3  );
    M1b ( 21 , 9  ) = Mb ( 10 , 4  );
    M1b ( 21 , 10 ) = Mb ( 10 , 5  );
    M1b ( 21 , 11 ) = Mb ( 10 , 6  );
    M1b ( 21 , 15 ) = Mb ( 10 , 7  );
    M1b ( 21 , 16 ) = Mb ( 10 , 8  );
    M1b ( 21 , 17 ) = Mb ( 10 , 9  );
    M1b ( 21 , 21 ) = Mb ( 10 , 10 );
    M1b ( 21 , 22 ) = Mb ( 10 , 11 );
    M1b ( 21 , 23 ) = Mb ( 10 , 12 );

    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 11
    M1b ( 22 , 3  ) = Mb ( 11 , 1  );
    M1b ( 22 , 4  ) = Mb ( 11 , 2  );
    M1b ( 22 , 5  ) = Mb ( 11 , 3  );
    M1b ( 22 , 9  ) = Mb ( 11 , 4  );
    M1b ( 22 , 10 ) = Mb ( 11 , 5  );
    M1b ( 22 , 11 ) = Mb ( 11 , 6  );
    M1b ( 22 , 15 ) = Mb ( 11 , 7  );
    M1b ( 22 , 16 ) = Mb ( 11 , 8  );
    M1b ( 22 , 17 ) = Mb ( 11 , 9  );
    M1b ( 22 , 21 ) = Mb ( 11 , 10 );
    M1b ( 22 , 22 ) = Mb ( 11 , 11 );
    M1b ( 22 , 23 ) = Mb ( 11 , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 12
    M1b ( 23 , 3  ) = Mb ( 12 , 1  );
    M1b ( 23 , 4  ) = Mb ( 12 , 2  );
    M1b ( 23 , 5  ) = Mb ( 12 , 3  );
    M1b ( 23 , 9  ) = Mb ( 12 , 4  );
    M1b ( 23 , 10 ) = Mb ( 12 , 5  );
    M1b ( 23 , 11 ) = Mb ( 12 , 6  );
    M1b ( 23 , 15 ) = Mb ( 12 , 7  );
    M1b ( 23 , 16 ) = Mb ( 12 , 8  );
    M1b ( 23 , 17 ) = Mb ( 12 , 9  );
    M1b ( 23 , 21 ) = Mb ( 12 , 10 );
    M1b ( 23 , 22 ) = Mb ( 12 , 11 );
    M1b ( 23 , 23 ) = Mb ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MASSA DE ROTA��O PERPENDICULAR A PLACA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % M�ximo Valor de Massa da Matriz do Elemento
    Mmax = max ( M1b ( : ) );
    
    % Massa de Rota��o Perpendicular a Placa
    Mrot = Mmax / 100;
    
    % Aloca��o da Massa de Rota��o Perpendicular a Placa na Matriz
    M1b ( 6  , 6  ) = Mrot;
    M1b ( 12 , 12 ) = Mrot;
    M1b ( 18 , 18 ) = Mrot;
    M1b ( 24 , 24 ) = Mrot;

end

