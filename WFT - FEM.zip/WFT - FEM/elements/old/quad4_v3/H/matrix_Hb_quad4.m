%% Cria��o da Matriz de Fun��es de Forma de Flex�o do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Hb                - Matriz de Fun��es de Forma de Flex�o do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Fun��es de Forma de Flex�o do Elemento Quad4
function [ Hb ] = matrix_Hb_quad4 ( e , n )
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma
    Hb = zeros ( 3 , 12 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma -- GL TZ
    Hb ( 1 , 1  ) = + ( 1 / 4 ) * ( 1 - e ) * ( 1 - n );
    Hb ( 1 , 4  ) = + ( 1 / 4 ) * ( 1 + e ) * ( 1 - n );
    Hb ( 1 , 7  ) = + ( 1 / 4 ) * ( 1 + e ) * ( 1 + n );
    Hb ( 1 , 10 ) = + ( 1 / 4 ) * ( 1 - e ) * ( 1 + n );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma -- GL RX
    Hb ( 2 , 2  ) = + ( 1 / 4 ) * ( 1 - e ) * ( 1 - n );
    Hb ( 2 , 5  ) = + ( 1 / 4 ) * ( 1 + e ) * ( 1 - n );
    Hb ( 2 , 8  ) = + ( 1 / 4 ) * ( 1 + e ) * ( 1 + n );
    Hb ( 2 , 11 ) = + ( 1 / 4 ) * ( 1 - e ) * ( 1 + n );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma -- GL RY
    Hb ( 3 , 3  ) = + ( 1 / 4 ) * ( 1 - e ) * ( 1 - n );
    Hb ( 3 , 6  ) = + ( 1 / 4 ) * ( 1 + e ) * ( 1 - n );
    Hb ( 3 , 9  ) = + ( 1 / 4 ) * ( 1 + e ) * ( 1 + n );
    Hb ( 3 , 12 ) = + ( 1 / 4 ) * ( 1 - e ) * ( 1 + n );
    
end

