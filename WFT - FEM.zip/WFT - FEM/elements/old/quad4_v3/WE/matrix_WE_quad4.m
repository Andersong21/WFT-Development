%% Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Quad4

%% OUTPUT
% WEm               - Matriz dos Pesos na Quadratura de Gauss do Quad4 -- Parcela Membrana
% WEb               - Matriz dos Pesos na Quadratura de Gauss do Quad4 -- Parcela Flex�o
% WEs               - Matriz dos Pesos na Quadratura de Gauss do Quad4 -- Parcela Cisalhamento

%% Declara��o da Fun��o de Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Quad4
function [ WEm , WEb , WEs ] = matrix_WE_quad4 ()

    %%%%%%%%%%%%
    % MEMBRANA %
    %%%%%%%%%%%%
   
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss -- Membrana
    WEm = zeros ( 2 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss
    WEm ( 1 ) = 1.0;
    WEm ( 2 ) = 1.0;  
    
    %%%%%%%%%%
    % FLEX�O %
    %%%%%%%%%%
   
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss -- Flex�o
    WEb = zeros ( 2 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss
    WEb ( 1 ) = 1.0;
    WEb ( 2 ) = 1.0; 
    
    %%%%%%%%%%%%%%%%
    % CISALHAMENTO %
    %%%%%%%%%%%%%%%%
   
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss -- Cisalhamento
    WEs = zeros ( 1 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss
    WEs ( 1 ) = 2.0;
   
end

