%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o de Flex�o do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Jb                - Matriz Jacobiana do Elemento -- Flex�o

%% OUTPUT
% Bb                - Matriz de Correla��o Deslocamento Deforma��o de Flex�o do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o de Flex�o do Elemento Quad4
function [ Bb ] = matrix_Bb_quad4 ( e , n , Jb )
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4;    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ JACOBIANA INVERSA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz Jacobiana Inversa
    Ji = inv ( Jb );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADAS DAS FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a X
    DN1x = ( DN1e * Ji ( 1 , 1 ) ) + ( DN1n * Ji ( 1 , 2 ) );
    DN2x = ( DN2e * Ji ( 1 , 1 ) ) + ( DN2n * Ji ( 1 , 2 ) );
    DN3x = ( DN3e * Ji ( 1 , 1 ) ) + ( DN3n * Ji ( 1 , 2 ) );
    DN4x = ( DN4e * Ji ( 1 , 1 ) ) + ( DN4n * Ji ( 1 , 2 ) );
    
    % Derivadas das Fun��es de Forma em Rela��o a Y
    DN1y = ( DN1e * Ji ( 2 , 1 ) ) + ( DN1n * Ji ( 2 , 2 ) );
    DN2y = ( DN2e * Ji ( 2 , 1 ) ) + ( DN2n * Ji ( 2 , 2 ) );
    DN3y = ( DN3e * Ji ( 2 , 1 ) ) + ( DN3n * Ji ( 2 , 2 ) );
    DN4y = ( DN4e * Ji ( 2 , 1 ) ) + ( DN4n * Ji ( 2 , 2 ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento - Flex�o
    Bb = zeros ( 3 , 12 );
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 1 , 2  ) = DN1x;
    Bb ( 1 , 5  ) = DN2x;
    Bb ( 1 , 8  ) = DN3x;
    Bb ( 1 , 11 ) = DN4x;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 2 , 3  ) = DN1y;
    Bb ( 2 , 6  ) = DN2y;
    Bb ( 2 , 9  ) = DN3y;
    Bb ( 2 , 12 ) = DN4y;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 3 , 2  ) = DN1y;
    Bb ( 3 , 5  ) = DN2y;
    Bb ( 3 , 8  ) = DN3y;
    Bb ( 3 , 11 ) = DN4y;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Flex�o
    Bb ( 3 , 3  ) = DN1x;
    Bb ( 3 , 6  ) = DN2x;
    Bb ( 3 , 9  ) = DN3x;
    Bb ( 3 , 12 ) = DN4x;
    
end

