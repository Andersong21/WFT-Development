%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Js                - Matriz Jacobiana do Elemento -- Cisalhamento

%% OUTPUT
% Bs                - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento do Elemento Quad4
function [ Bs ] = matrix_Bs_quad4 ( e , n , Js )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4; 
   
    %%%%%%%%%%%%%%%%%%%%
    % FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%
    
    % Determina��o das Fun��es de Forma
    N1 = ( 1 / 4 ) * ( 1 - e ) * ( 1 - n );
    N2 = ( 1 / 4 ) * ( 1 + e ) * ( 1 - n );
    N3 = ( 1 / 4 ) * ( 1 + e ) * ( 1 + n );
    N4 = ( 1 / 4 ) * ( 1 - e ) * ( 1 + n );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ JACOBIANA INVERSA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz Jacobiana Inversa
    Ji = inv ( Js );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADAS DAS FUN��ES DE FORMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a X
    DN1x = ( DN1e * Ji ( 1 , 1 ) ) + ( DN1n * Ji ( 1 , 2 ) );
    DN2x = ( DN2e * Ji ( 1 , 1 ) ) + ( DN2n * Ji ( 1 , 2 ) );
    DN3x = ( DN3e * Ji ( 1 , 1 ) ) + ( DN3n * Ji ( 1 , 2 ) );
    DN4x = ( DN4e * Ji ( 1 , 1 ) ) + ( DN4n * Ji ( 1 , 2 ) );
    
    % Derivadas das Fun��es de Forma em Rela��o a Y
    DN1y = ( DN1e * Ji ( 2 , 1 ) ) + ( DN1n * Ji ( 2 , 2 ) );
    DN2y = ( DN2e * Ji ( 2 , 1 ) ) + ( DN2n * Ji ( 2 , 2 ) );
    DN3y = ( DN3e * Ji ( 2 , 1 ) ) + ( DN3n * Ji ( 2 , 2 ) );
    DN4y = ( DN4e * Ji ( 2 , 1 ) ) + ( DN4n * Ji ( 2 , 2 ) );   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o Deforma��o Deslocamento - Cisalhamento
    Bs = zeros ( 2 , 12 );
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 1 , 1  ) = DN1x;
    Bs ( 1 , 4  ) = DN2x;
    Bs ( 1 , 7  ) = DN3x;
    Bs ( 1 , 10 ) = DN4x;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 1 , 2  ) = - N1;
    Bs ( 1 , 5  ) = - N2;
    Bs ( 1 , 8  ) = - N3;
    Bs ( 1 , 11 ) = - N4;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 2 , 1  ) = DN1y;
    Bs ( 2 , 4  ) = DN2y;
    Bs ( 2 , 7  ) = DN3y;
    Bs ( 2 , 10 ) = DN4y;
    
    % Aloca��o na Matriz de Correla��o Deforma��o Deslocamento Cisalhamento
    Bs ( 2 , 3  ) = - N1;
    Bs ( 2 , 6  ) = - N2;
    Bs ( 2 , 9  ) = - N3;
    Bs ( 2 , 12 ) = - N4;   
    
end

