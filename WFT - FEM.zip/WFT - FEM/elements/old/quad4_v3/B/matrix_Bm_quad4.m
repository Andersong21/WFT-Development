%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o de Membrana do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Jm                - Matriz Jacobiana do Elemento -- Membrana

%% OUTPUT
% Bm                - Matriz de Correla��o Deslocamento Deforma��o de Membrana do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o de Membrana do Elemento Quad4
function [ Bm ] = matrix_Bm_quad4 ( e , n , Jm )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4;
    
    % Inicializa��o da Matriz das Derivadas das Fun��es de Forma
    DN = zeros ( 4 , 8 );
    
    % Aloca��o das Derivadas das Fun��es de Forma
    DN ( 1 , 1 ) = DN1e;
    DN ( 1 , 3 ) = DN2e;
    DN ( 1 , 5 ) = DN3e;
    DN ( 1 , 7 ) = DN4e;
    
    DN ( 2 , 1 ) = DN1n;
    DN ( 2 , 3 ) = DN2n;
    DN ( 2 , 5 ) = DN3n;
    DN ( 2 , 7 ) = DN4n;
    
    DN ( 3 , 2 ) = DN1e;
    DN ( 3 , 4 ) = DN2e;
    DN ( 3 , 6 ) = DN3e;
    DN ( 3 , 8 ) = DN4e;
    
    DN ( 4 , 2 ) = DN1n;
    DN ( 4 , 4 ) = DN2n;
    DN ( 4 , 6 ) = DN3n;
    DN ( 4 , 8 ) = DN4n;    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO DA MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o A
    A = zeros ( 3 , 4 );
    
    % Aloca��o dos Termos na Matriz A
    A ( 1 , 1 ) = + Jm ( 2 , 2 );
    A ( 1 , 2 ) = - Jm ( 1 , 2 );
    
    A ( 2 , 3 ) = - Jm ( 2 , 1 );
    A ( 2 , 4 ) = + Jm ( 1 , 1 );
    
    A ( 3 , 1 ) = - Jm ( 2 , 1 );
    A ( 3 , 2 ) = + Jm ( 1 , 1 );
    A ( 3 , 3 ) = + Jm ( 2 , 2 );
    A ( 3 , 4 ) = - Jm ( 1 , 2 );
    
    % Multiplica��o pelo Determinante do Jacobiana
    A = ( 1 / det ( Jm ) ) * A;   
    
    % Determina��o da Matriz de Correla��o Bm
    Bm  = A * DN;     
    
end