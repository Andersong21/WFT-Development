%% Cria��o da Matriz Jacobiana de Flex�o do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Jb                - Matriz Jacobiana do Elemento Quad4 - Flex�o

%% Declara��o da Fun��o de Cria��o da Matriz Jacobiana de Flex�o do Elemento Quad4
function [ Jb ] = matrix_Jb_quad4 ( e , n , Cl )  
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DA MATRIZ JACOBIANA % FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Par�metros Geom�tricos
    x12 = Cl ( 2 , 1 ) - Cl ( 1 , 1 );
    x23 = Cl ( 3 , 1 ) - Cl ( 2 , 1 );
    x34 = Cl ( 4 , 1 ) - Cl ( 3 , 1 ); 
    x41 = Cl ( 1 , 1 ) - Cl ( 4 , 1 );
    y12 = Cl ( 2 , 2 ) - Cl ( 1 , 2 );
    y23 = Cl ( 3 , 2 ) - Cl ( 2 , 2 );
    y34 = Cl ( 4 , 2 ) - Cl ( 3 , 2 );
    y41 = Cl ( 1 , 2 ) - Cl ( 4 , 2 );
    
    % Inicializa��o da Matriz Jacobiana -- Flex�o
    Jb = zeros ( 2 , 2 );
    
    % Aloca��o da Matriz Jacobiana -- Flex�o
    Jb ( 1 , 1 ) = ( 1 / 4 ) * ( - x12 + x34 + ( n * ( x12 + x34 ) ) );
    Jb ( 1 , 2 ) = ( 1 / 4 ) * ( - y12 + y34 + ( n * ( y12 + y34 ) ) );
    Jb ( 2 , 1 ) = ( 1 / 4 ) * ( - x23 + x41 + ( e * ( x12 + x34 ) ) );
    Jb ( 2 , 2 ) = ( 1 / 4 ) * ( - y23 + y41 + ( e * ( y12 + y34 ) ) );
    
end

