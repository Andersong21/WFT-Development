%% Cria��o da Matriz Jacobiana de Membrana do Elemento Quad4

%% INPUT
% e                 - Posi��o da Coordenada Natural e no Elemento
% n                 - Posi��o da Coordenada Natural n no Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Jm                - Matriz Jacobiana do Elemento Quad4 - Membrana

%% Declara��o da Fun��o de Cria��o da Matriz Jacobiana de Membrana do Elemento Quad4
function [ Jm ] = matrix_Jm_quad4 ( e , n , Cl )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DERIVADA DAS FUN��ES DE FORMA % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Derivadas das Fun��es de Forma em Rela��o a e
    DN1e = - ( 1 - n ) / 4;
    DN2e = + ( 1 - n ) / 4;
    DN3e = + ( 1 + n ) / 4;
    DN4e = - ( 1 + n ) / 4;

    % Derivadas das Fun��es de Forma em Rela��o a n
    DN1n = - ( 1 - e ) / 4;
    DN2n = - ( 1 + e ) / 4;
    DN3n = + ( 1 + e ) / 4;
    DN4n = + ( 1 - e ) / 4;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ JACOBIANA % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Inicializa��o da Matriz Jacobiana -- Membrana
    Jm = zeros ( 2 , 2 );
    
    % Aloca��o da Matriz Jacobiana -- Membrana
    Jm ( 1 , 1 ) = DN1e * Cl ( 1 , 1 ) + DN2e * Cl ( 2 , 1 ) + DN3e * Cl ( 3 , 1 ) + DN4e * Cl ( 4 , 1 );
    Jm ( 1 , 2 ) = DN1e * Cl ( 1 , 2 ) + DN2e * Cl ( 2 , 2 ) + DN3e * Cl ( 3 , 2 ) + DN4e * Cl ( 4 , 2 );
    Jm ( 2 , 1 ) = DN1n * Cl ( 1 , 1 ) + DN2n * Cl ( 2 , 1 ) + DN3n * Cl ( 3 , 1 ) + DN4n * Cl ( 4 , 1 );
    Jm ( 2 , 2 ) = DN1n * Cl ( 1 , 2 ) + DN2n * Cl ( 2 , 2 ) + DN3n * Cl ( 3 , 2 ) + DN4n * Cl ( 4 , 2 );    
    
end

