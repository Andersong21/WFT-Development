%% Cria��o da Matriz de Massa Tor��o do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% rho               - Densidade do Elemento
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Ht                - Matriz de Fun��es de Forma Tor��o do Elemento Beam2

%% OUTPUT
% M1t               - Matriz de Massa Tor��o do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa Tor��o do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ M1t ] = matrix_Mt_QG_beam2 ( rho , b , h , J , Ht )

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Tor��o
    Mt = rho * ( ( b * h * h * h / 12 ) + ( h * b * b * b / 12 ) ) * ( transpose ( Ht ) * Ht ) * J;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA TOR��O DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Tor��o Local
    M1t = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa Tor��o -- LINHA 1
    M1t ( 1  , 1  ) = Mt ( 1 , 1 );
    M1t ( 1  , 7  ) = Mt ( 1 , 2 );
    
    % Aloca��o dos Termos da Matriz de Massa Tor��o -- LINHA 2
    M1t ( 7  , 1  ) = Mt ( 2 , 1 );
    M1t ( 7  , 7  ) = Mt ( 2 , 2 );   
  
end

