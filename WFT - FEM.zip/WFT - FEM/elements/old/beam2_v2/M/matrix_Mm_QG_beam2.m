%% Cria��o da Matriz de Massa Membrana do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% rho               - Densidade do Elemento
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Hmy               - Matriz de Fun��es de Forma Membrana Iyy do Elemento Beam2
% Hmz               - Matriz de Fun��es de Forma Membrana Izz do Elemento Beam2


%% OUTPUT
% M1m               - Matriz de Massa Membrana do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa Membrana do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ M1m ] = matrix_Mm_QG_beam2 ( rho , b , h , J , Hmy , Hmz )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA MEMBRANA IYY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Membrana Iyy
    Mmy = rho * b * h * ( transpose ( Hmy ) * Hmy ) * J;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA MEMBRANA IZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Membrana Izz
    Mmz = rho * b * h * ( transpose ( Hmz ) * Hmz ) * J;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA MEMBRANA DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Membrana Local
    M1m = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA MEMBRANA YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 1
    M1m ( 3  , 3  ) = Mmy ( 1 , 1 );
    M1m ( 3  , 5  ) = Mmy ( 1 , 2 );
    M1m ( 3  , 9  ) = Mmy ( 1 , 3 );
    M1m ( 3  , 11 ) = Mmy ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 2
    M1m ( 5  , 3  ) = Mmy ( 2 , 1 );
    M1m ( 5  , 5  ) = Mmy ( 2 , 2 );
    M1m ( 5  , 9  ) = Mmy ( 2 , 3 );
    M1m ( 5  , 11 ) = Mmy ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 3
    M1m ( 9  , 3  ) = Mmy ( 3 , 1 );
    M1m ( 9  , 5  ) = Mmy ( 3 , 2 );
    M1m ( 9  , 9  ) = Mmy ( 3 , 3 );
    M1m ( 9  , 11 ) = Mmy ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 4
    M1m ( 11 , 3  ) = Mmy ( 4 , 1 );
    M1m ( 11 , 5  ) = Mmy ( 4 , 2 );
    M1m ( 11 , 9  ) = Mmy ( 4 , 3 );
    M1m ( 11 , 11 ) = Mmy ( 4 , 4 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA MEMBRANA ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 1
    M1m ( 2  , 2  ) = Mmz ( 1 , 1 );
    M1m ( 2  , 6  ) = Mmz ( 1 , 2 );
    M1m ( 2  , 8  ) = Mmz ( 1 , 3 );
    M1m ( 2  , 12 ) = Mmz ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 2
    M1m ( 6  , 2  ) = Mmz ( 2 , 1 );
    M1m ( 6  , 6  ) = Mmz ( 2 , 2 );
    M1m ( 6  , 8  ) = Mmz ( 2 , 3 );
    M1m ( 6  , 12 ) = Mmz ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 3
    M1m ( 8  , 2  ) = Mmz ( 3 , 1 );
    M1m ( 8  , 6  ) = Mmz ( 3 , 2 );
    M1m ( 8  , 8  ) = Mmz ( 3 , 3 );
    M1m ( 8  , 12 ) = Mmz ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 4
    M1m ( 12 , 2  ) = Mmz ( 4 , 1 );
    M1m ( 12 , 6  ) = Mmz ( 4 , 2 );
    M1m ( 12 , 8  ) = Mmz ( 4 , 3 );
    M1m ( 12 , 12 ) = Mmz ( 4 , 4 );  
  
end

