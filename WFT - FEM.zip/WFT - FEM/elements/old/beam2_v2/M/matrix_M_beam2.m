%% Cria��o da Matriz de Massa do Elemento Tapered Beam2

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Elemento i

%% OUTPUT
% Mi                - Termo i da Matriz de Massa Global
% Mj                - Termo j da Matriz de Massa Global
% Mv                - Valor ( i , j ) da Matriz de Massa Global

%% Declara��o da Fun��o de Cria��o da Matriz de Massa do Elemento
function [ Mi , Mj , Mv ] = matrix_M_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno das Defini��es Iniciais da Propriedade
    [ b , h ] = get_section_param ( Elem_Param , Prop_Param , i );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE PESOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Pesos na Quadratura de Gauss
    [ WEa , WEi , WEm , WEt ] = matrix_WE_beam2 ();
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DOS PONTOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz dos Pontos na Quadratura de Gauss
    [ POa , POi , POm , POt ] = matrix_PO_beam2 ();    
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_beam2 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_beam2 ( Cg );
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_beam2 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva do Elemento
    [ E , G ] = matrix_D_beam2 ( Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DENSIDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Densidade do Elemento
    [ rho ] = matrix_P_beam2 ( Mat_Param );     
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local Final -- Axial
    Mla = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Axial
    for j = 1:1  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POa ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );         

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE FUN��ES DE FORMA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Fun��es de Forma
        [ Ha ] = matrix_Ha_beam2 ( Cl , r );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Massa no Ponto de Integra��o
        [ M1a ] = matrix_Ma_QG_beam2 ( rho , b , h , J , Ha );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Massa no Ponto de Integra��o
        Mla = Mla + ( WEa ( j ) * M1a );
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % IN�RCIA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local Final -- In�rica
    Mli = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- In�rcia
    for j = 1:2  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POi ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE FUN��ES DE FORMA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Fun��es de Forma
        [ Hiy , Hiz ] = matrix_Hi_beam2 ( E , G , b , h , Cl , r );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Massa no Ponto de Integra��o
        [ M1i ] = matrix_Mi_QG_beam2 ( rho , b , h , J , Hiy , Hiz );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Massa no Ponto de Integra��o
        Mli = Mli + ( WEi ( j ) * M1i ); 
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local Final -- Membrana
    Mlm = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Membrana
    for j = 1:1  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POm ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );        

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE FUN��ES DE FORMA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Fun��es de Forma
        [ Hmy , Hmz ] = matrix_Hm_beam2 ( E , G , b , h , Cl , r );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Massa no Ponto de Integra��o
        [ M1m ] = matrix_Mm_QG_beam2 ( rho , b , h , J , Hmy , Hmz );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Massa no Ponto de Integra��o
        Mlm = Mlm + ( WEm ( j ) * M1m ); 
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local Final -- Tor��o
    Mlt = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Tor��o
    for j = 1:1  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POt ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );       

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE FUN��ES DE FORMA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Fun��es de Forma
        [ Ht ] = matrix_Ht_beam2 ( Cl , r );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Massa no Ponto de Integra��o
        [ M1t ] = matrix_Mt_QG_beam2 ( rho , b , h , J , Ht );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE MASSA DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Massa no Ponto de Integra��o
        Mlt = Mlt + ( WEt ( j ) * M1t ); 
        
    end  
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Massa Local do Elemento
    Ml = Mla + Mli + Mlm + Mlt;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO % GLOBAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Global do Elemento
    Mg = R * Ml * transpose ( R );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE GRAUS DE LIBERDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador de Graus de Liberdade do Elemento
    Ndof = 1;
    
    % Varredura nos N�s do Elemento
    for j = 1:length( Elem_Param ( i ).node )
       
        % Id do N�
        Idn = Elem_Param ( i ).node ( j );
        
        % Varredura nos Graus de Liberdade dos N�s do Elemento
        for k = 1:length ( Node_Param ( Idn ).dof )            
            
            % Aloca��o no Vetor de Graus de Liberdade
            DOF ( Ndof ) = Node_Param ( Idn ).dof ( k );
            
            % Incremento na Contagem de Graus de Liberdade
            Ndof = Ndof + 1;
            
        end         
        
    end
    
    % Inicializa��o do Contador
    cont = 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o na Matriz de Massa Global do Problema
    for j = 1:12
        
        % Verifica��o se o Grau de Liberdade � nulo
        if ( DOF ( j ) == 0 )
            
            % Continuar
            continue;
            
        else      
            
            % Aloca��o na Matriz de Massa Global do Problema        
            for k = 1:12

                % Verifica��o se o Grau de Liberdade � nulo
                if ( DOF ( k ) == 0 )
                    
                    % Continuar
                    continue;
                
                else

                    % Aloca��o dos Termos da Matriz na Posi��o Global
                    Mi ( cont ) = DOF ( j );
                    Mj ( cont ) = DOF ( k );
                    Mv ( cont ) = Mg ( j , k );
                    
                    % Incremento do Contador
                    cont = cont + 1;

                end
                
            end
            
        end
        
    end 
    
end

