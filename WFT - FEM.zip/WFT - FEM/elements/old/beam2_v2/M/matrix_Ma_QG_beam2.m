%% Cria��o da Matriz de Massa Axial do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% rho               - Densidade do Elemento
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Ha                - Matriz de Fun��es de Forma Axial do Elemento Beam2


%% OUTPUT
% M1a               - Matriz de Massa Axial do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa Axial do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ M1a ] = matrix_Ma_QG_beam2 ( rho , b , h , J , Ha )

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Axial
    Ma = rho * b * h * ( transpose ( Ha ) * Ha ) * J;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA AXIAL DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Axial Local
    M1a = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa Axial -- LINHA 1
    M1a ( 1  , 1  ) = Ma ( 1 , 1 );
    M1a ( 1  , 7  ) = Ma ( 1 , 2 );
    
    % Aloca��o dos Termos da Matriz de Massa Axial -- LINHA 2
    M1a ( 7  , 1  ) = Ma ( 2 , 1 );
    M1a ( 7  , 7  ) = Ma ( 2 , 2 );   
  
end

