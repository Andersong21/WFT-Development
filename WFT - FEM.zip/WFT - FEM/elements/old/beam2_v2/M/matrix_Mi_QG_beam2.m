%% Cria��o da Matriz de Massa Inercia do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% rho               - Densidade do Elemento
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Hiy               - Matriz de Fun��es de Forma Inercia Iyy do Elemento Beam2
% Hiz               - Matriz de Fun��es de Forma Inercia Izz do Elemento Beam2


%% OUTPUT
% M1i               - Matriz de Massa Inercia do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa Inercia do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ M1i ] = matrix_Mi_QG_beam2 ( rho , b , h , J , Hiy , Hiz )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA IN�RCIA IYY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa In�rcia Iyy
    Miy = rho * ( h * b * b * b / 12 ) * ( transpose ( Hiy ) * Hiy ) * J;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA IN�RCIA IZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa In�rcia Izz
    Miz = rho * ( b * h * h * h / 12 ) * ( transpose ( Hiz ) * Hiz ) * J;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA IN�RCIA DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa In�rcia Local
    M1i = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA IN�RCIA YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 1
    M1i ( 3  , 3  ) = Miy ( 1 , 1 );
    M1i ( 3  , 5  ) = Miy ( 1 , 2 );
    M1i ( 3  , 9  ) = Miy ( 1 , 3 );
    M1i ( 3  , 11 ) = Miy ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 2
    M1i ( 5  , 3  ) = Miy ( 2 , 1 );
    M1i ( 5  , 5  ) = Miy ( 2 , 2 );
    M1i ( 5  , 9  ) = Miy ( 2 , 3 );
    M1i ( 5  , 11 ) = Miy ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 3
    M1i ( 9  , 3  ) = Miy ( 3 , 1 );
    M1i ( 9  , 5  ) = Miy ( 3 , 2 );
    M1i ( 9  , 9  ) = Miy ( 3 , 3 );
    M1i ( 9  , 11 ) = Miy ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica YY -- LINHA 4
    M1i ( 11 , 3  ) = Miy ( 4 , 1 );
    M1i ( 11 , 5  ) = Miy ( 4 , 2 );
    M1i ( 11 , 9  ) = Miy ( 4 , 3 );
    M1i ( 11 , 11 ) = Miy ( 4 , 4 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA IN�RCIA ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 1
    M1i ( 2  , 2  ) = Miz ( 1 , 1 );
    M1i ( 2  , 6  ) = Miz ( 1 , 2 );
    M1i ( 2  , 8  ) = Miz ( 1 , 3 );
    M1i ( 2  , 12 ) = Miz ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 2
    M1i ( 6  , 2  ) = Miz ( 2 , 1 );
    M1i ( 6  , 6  ) = Miz ( 2 , 2 );
    M1i ( 6  , 8  ) = Miz ( 2 , 3 );
    M1i ( 6  , 12 ) = Miz ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 3
    M1i ( 8  , 2  ) = Miz ( 3 , 1 );
    M1i ( 8  , 6  ) = Miz ( 3 , 2 );
    M1i ( 8  , 8  ) = Miz ( 3 , 3 );
    M1i ( 8  , 12 ) = Miz ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Massa In�rica ZZ -- LINHA 4
    M1i ( 12 , 2  ) = Miz ( 4 , 1 );
    M1i ( 12 , 6  ) = Miz ( 4 , 2 );
    M1i ( 12 , 8  ) = Miz ( 4 , 3 );
    M1i ( 12 , 12 ) = Miz ( 4 , 4 );  
  
end

