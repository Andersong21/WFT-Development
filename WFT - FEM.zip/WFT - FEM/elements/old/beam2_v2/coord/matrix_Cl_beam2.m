%% Cria��o da Matriz de Coordenadas Nodais Locais do Elemento Beam2

%% INPUT
% R                 - Matriz de Transforma��o de Coordenadas do Beam2
% Cg                - Matriz das Coordenadas Globais do Elemento Beam2

%% OUTPUT
% Cl                - Matriz das Coordenadas Locais do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Coordenadas Nodais Globais do Elemento Beam2
function [ Cl ] = matrix_Cl_beam2 ( R , Cg )

    % Vetoriza��o da Matriz de Coordenadas Globais do Elemento
    for i = 1:2
    
        % Aloca��o das Coordenadas Globais no Vetor
        Ug ( ( 3 * ( i - 1 ) ) + 1 ) = Cg ( i , 1 );
        Ug ( ( 3 * ( i - 1 ) ) + 2 ) = Cg ( i , 2 );
        Ug ( ( 3 * ( i - 1 ) ) + 3 ) = Cg ( i , 3 );
    
    end
    
    % Vetoriza��o da Matriz de Coordenadas Locais do Elemento
    Ul = transpose ( R ( 1:6 , 1:6 ) ) * transpose ( Ug );
    
    % Matriz de Coordenadas Nodais Locais do Elemento
    for i = 1:2
    
        % Aloca��o dos Termos na Matriz de Coordenadas Locais
        Cl ( i , 1 ) = Ul ( ( 3 * ( i - 1 ) ) + 1 );
        Cl ( i , 2 ) = Ul ( ( 3 * ( i - 1 ) ) + 2 );
        Cl ( i , 3 ) = Ul ( ( 3 * ( i - 1 ) ) + 3 );        
        
    end

end

