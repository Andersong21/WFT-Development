%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o Cisalhamento do Elemento Beam2

%% INPUT
% E                 - M�dulo de Elasticidade do Elemento
% G                 - M�dulo de Elasticidade Transversal do Elemento
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento
% r                 - Coordenada Natural r do Elemento

%% OUTPUT
% Bsy               - Matriz de Correla��o Deslocamento Deforma��o Cisalhamento YY do Elemento Beam2
% Bsz               - Matriz de Correla��o Deslocamento Deforma��o Cisalhamento ZZ do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o CIsalhamento do Elemento Beam2
function [ Bsy , Bsz ] = matrix_Bs_beam2 ( E , G , b , h , Cl , r )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenadas X do Elemento
    x1 = Cl ( 1 , 1 );
    x2 = Cl ( 2 , 1 );
    
    % Comprimento do Elemento
    L = x2 - x1;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % CISALHAMENTO YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o de Cisalhamento YY
    Bsy = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Cisalhamento YY
    Bsy ( 1 , 1 ) = ( - 6 * ( b^2 ) * E ) / ( 6 * ( b^2 ) * E * L + 5 * G * ( L^3 ) );
    Bsy ( 1 , 2 ) = ( + 3 * ( b^2 ) * E ) / ( 6 * ( b^2 ) * E     + 5 * G * ( L^2 ) );
    Bsy ( 1 , 3 ) = ( + 6 * ( b^2 ) * E ) / ( 6 * ( b^2 ) * E * L + 5 * G * ( L^3 ) );
    Bsy ( 1 , 4 ) = ( + 3 * ( b^2 ) * E ) / ( 6 * ( b^2 ) * E     + 5 * G * ( L^2 ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % CISALHAMENTO ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o de Cisalhamento ZZ
    Bsz = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Cisalhamento ZZ
    Bsz ( 1 , 1 ) = ( - 6 * ( h^2 ) * E ) / ( 6 * ( h^2 ) * E * L + 5 * G * ( L^3 ) ); 
    Bsz ( 1 , 2 ) = ( - 3 * ( h^2 ) * E ) / ( 6 * ( h^2 ) * E     + 5 * G * ( L^2 ) );
    Bsz ( 1 , 3 ) = ( + 6 * ( h^2 ) * E ) / ( 6 * ( h^2 ) * E * L + 5 * G * ( L^3 ) ); 
    Bsz ( 1 , 4 ) = ( - 3 * ( h^2 ) * E ) / ( 6 * ( h^2 ) * E     + 5 * G * ( L^2 ) );
    
end