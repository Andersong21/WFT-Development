%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o Flex�o do Elemento Beam2

%% INPUT
% E                 - M�dulo de Elasticidade do Elemento
% G                 - M�dulo de Elasticidade Transversal do Elemento
% b                 - Base M�dia do Elemento
% h                 - Altura M�dia do Elemento
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento
% r                 - Coordenada Natural r do Elemento

%% OUTPUT
% Bby               - Matriz de Correla��o Deslocamento Deforma��o Flex�o YY do Elemento Beam2
% Bbz               - Matriz de Correla��o Deslocamento Deforma��o Flex�o ZZ do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o Flex�o do Elemento Beam2
function [ Bby , Bbz ] = matrix_Bb_beam2 ( E , G , b , h , Cl , r )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenadas X do Elemento
    x1 = Cl ( 1 , 1 );
    x2 = Cl ( 2 , 1 );
    
    % Comprimento do Elemento
    L = x2 - x1;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o de Flex�o YY
    Bby = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Flex�o YY
    Bby ( 1 , 1 ) = ( - 30 * G * ( L - 2 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( b^2 ) * E * L + 5 * G * ( L^3 ) ); 
    Bby ( 1 , 2 ) = ( + 6 * ( b^2 ) * E + 10 * G * L * ( 2 * L - 3 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( b^2 ) * E * L + 5 * G * ( L^3 ) );
    Bby ( 1 , 3 ) = ( + 30 * G * ( L - 2 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( b^2 ) * E * L + 5 * G * ( L^3 ) ); 
    Bby ( 1 , 4 ) = ( - 6 * ( b^2 ) * E + 10 * G * L * ( L - 3 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( b^2 ) * E * L + 5 * G * ( L^3 ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o de Flex�o ZZ
    Bbz = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Flex�o ZZ
    Bbz ( 1 , 1 ) = ( - 30 * G * ( L - 2 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( h^2 ) * E * L + 5 * G * ( L^3 ) ); 
    Bbz ( 1 , 2 ) = ( - 6 * ( h^2 ) * E + 10 * G * L * ( - 2 * L + 3 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( h^2 ) * E * L + 5 * G * ( L^3 ) );
    Bbz ( 1 , 3 ) = ( + 30 * G * ( L - 2 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( h^2 ) * E * L + 5 * G * ( L^3 ) ); 
    Bbz ( 1 , 4 ) = ( + 6 * ( h^2 ) * E - 10 * G * L * ( L - 3 * ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) ) ) / ( 6 * ( h^2 ) * E * L + 5 * G * ( L^3 ) );    
    
end


