%% Cria��o da Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2

%% INPUT
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% Ba                - Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2
function [ Ba ] = matrix_Ba_beam2 ( Cl )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O DESLOCAMENTO % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Correla��o de Axial
    Ba = zeros ( 1 , 2 );
    
    % Aloca��o dos Termos na Matriz de Correla��o de Axial
    Ba ( 1 , 1 ) = - ( 1 / L );
    Ba ( 1 , 2 ) = + ( 1 / L );
    
end

