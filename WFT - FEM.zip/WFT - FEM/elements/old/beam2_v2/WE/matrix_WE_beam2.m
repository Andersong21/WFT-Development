%% Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Beam2

%% OUTPUT
% WEa               - Matriz dos Pesos na Quadratura de Gauss do Beam2 -- Parcela Axial
% WEb               - Matriz dos Pesos na Quadratura de Gauss do Beam2 -- Parcela Flex�o
% WEs               - Matriz dos Pesos na Quadratura de Gauss do Beam2 -- Parcela Cisalhamento
% WEt               - Matriz dos Pesos na Quadratura de Gauss do Beam2 -- Parcela Tor��o

%% Declara��o da Fun��o de Cria��o da Matriz dos Pesos na Quadratura de Gauss do Elemento Beam2
function [ WEa , WEb , WEs , WEt ] = matrix_WE_beam2 ()
   
    %%%%%%%%%
    % AXIAL %
    %%%%%%%%%

    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss --  Tra�ao
    WEa = zeros ( 1 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss -- Tra��o
    WEa ( 1 ) = 2.0;
    
    %%%%%%%%%%
    % FLEX�O %
    %%%%%%%%%%

    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss -- Flex�o
    WEb = zeros ( 2 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss -- Flex�o
    WEb ( 1 ) = 1.0;
    WEb ( 2 ) = 1.0;     
    
    %%%%%%%%%%%%%%%%
    % CISALHAMENTO %
    %%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss --  Cisalhamento
    WEs = zeros ( 1 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss -- Cisalhamento
    WEs ( 1 ) = 2.0;
    
    %%%%%%%%%%
    % TOR��O %
    %%%%%%%%%%
    
    % Inicializa��o da Matriz de Pesos na Quadratura de Gauss --  Tor��o
    WEt = zeros ( 1 , 1 );
    
    % Defini��o dos Pesos na Quadratura de Gauss -- Tor��o
    WEt ( 1 ) = 2.0;
   
end

