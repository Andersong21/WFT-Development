%% Cria��o da Matriz de Rigidez Cisalhamento do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% G                 - M�dulo de Elasticidade Transversal do Elemento Beam2
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Bsy               - Matriz de Correla��o Deforma��o Deslocamento Cisalhamento YY do Elemento Beam2
% Bsz               - Matriz de Correla��o Deforma��o Deslocamento Cisalhamento ZZ do Elemento Beam2

%% OUTPUT
% K1s               - Matriz de Rigidez Cisalhamento do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez Cisalhamento do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ K1s ] = matrix_Ks_QG_beam2 ( G , b , h , J , Bsy , Bsz )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ CISALHAMENTO IYY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Cisalhamento Iyy
    Ksy = ( 5 / 6 ) * G * b * h * ( transpose ( Bsy ) * Bsy ) * J;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ CISALHAMENTO IZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Cisalhamento Izz
    Ksz = ( 5 / 6 ) * G * b * h * ( transpose ( Bsz ) * Bsz ) * J;
       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ CISALHAMENTO DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Cisalhamento Local
    K1s = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ CISALHAMENTO YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento YY -- LINHA 1
    K1s ( 3  , 3  ) = Ksy ( 1 , 1 );
    K1s ( 3  , 5  ) = Ksy ( 1 , 2 );
    K1s ( 3  , 9  ) = Ksy ( 1 , 3 );
    K1s ( 3  , 11 ) = Ksy ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento YY -- LINHA 2
    K1s ( 5  , 3  ) = Ksy ( 2 , 1 );
    K1s ( 5  , 5  ) = Ksy ( 2 , 2 );
    K1s ( 5  , 9  ) = Ksy ( 2 , 3 );
    K1s ( 5  , 11 ) = Ksy ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento YY -- LINHA 3
    K1s ( 9  , 3  ) = Ksy ( 3 , 1 );
    K1s ( 9  , 5  ) = Ksy ( 3 , 2 );
    K1s ( 9  , 9  ) = Ksy ( 3 , 3 );
    K1s ( 9  , 11 ) = Ksy ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento YY -- LINHA 4
    K1s ( 11 , 3  ) = Ksy ( 4 , 1 );
    K1s ( 11 , 5  ) = Ksy ( 4 , 2 );
    K1s ( 11 , 9  ) = Ksy ( 4 , 3 );
    K1s ( 11 , 11 ) = Ksy ( 4 , 4 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ CISALHAMENTO ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento ZZ -- LINHA 1
    K1s ( 2  , 2  ) = Ksz ( 1 , 1 );
    K1s ( 2  , 6  ) = Ksz ( 1 , 2 );
    K1s ( 2  , 8  ) = Ksz ( 1 , 3 );
    K1s ( 2  , 12 ) = Ksz ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento ZZ -- LINHA 2
    K1s ( 6  , 2  ) = Ksz ( 2 , 1 );
    K1s ( 6  , 6  ) = Ksz ( 2 , 2 );
    K1s ( 6  , 8  ) = Ksz ( 2 , 3 );
    K1s ( 6  , 12 ) = Ksz ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento ZZ -- LINHA 3
    K1s ( 8  , 2  ) = Ksz ( 3 , 1 );
    K1s ( 8  , 6  ) = Ksz ( 3 , 2 );
    K1s ( 8  , 8  ) = Ksz ( 3 , 3 );
    K1s ( 8  , 12 ) = Ksz ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Cisalhamento ZZ -- LINHA 4
    K1s ( 12 , 2  ) = Ksz ( 4 , 1 );
    K1s ( 12 , 6  ) = Ksz ( 4 , 2 );
    K1s ( 12 , 8  ) = Ksz ( 4 , 3 );
    K1s ( 12 , 12 ) = Ksz ( 4 , 4 );
   
end

