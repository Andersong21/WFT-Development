%% Cria��o da Matriz de Rigidez Flex�o do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% E                 - M�dulo de Elasticidade do Elemento Beam2
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Bby               - Matriz de Correla��o Deforma��o Deslocamento Flex�o YY do Elemento Beam2
% Bbz               - Matriz de Correla��o Deforma��o Deslocamento Flex�o ZZ do Elemento Beam2

%% OUTPUT
% K1b               - Matriz de Rigidez Flex�o do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez Flex�o do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ K1b ] = matrix_Kb_QG_beam2 ( E , b , h , J , Bby , Bbz )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ FLEX�O IYY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Flex�o Iyy
    Kby = E * ( h * b * b * b / 12 ) * ( transpose ( Bby ) * Bby ) * J;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ FLEX�O IZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Flex�o Izz
    Kbz = E * ( b * h * h * h / 12 ) * ( transpose ( Bbz ) * Bbz ) * J;
       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ FLEX�O DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Flex�o Local
    K1b = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o YY -- LINHA 1
    K1b ( 3  , 3  ) = Kby ( 1 , 1 );
    K1b ( 3  , 5  ) = Kby ( 1 , 2 );
    K1b ( 3  , 9  ) = Kby ( 1 , 3 );
    K1b ( 3  , 11 ) = Kby ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o YY -- LINHA 2
    K1b ( 5  , 3  ) = Kby ( 2 , 1 );
    K1b ( 5  , 5  ) = Kby ( 2 , 2 );
    K1b ( 5  , 9  ) = Kby ( 2 , 3 );
    K1b ( 5  , 11 ) = Kby ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o YY -- LINHA 3
    K1b ( 9  , 3  ) = Kby ( 3 , 1 );
    K1b ( 9  , 5  ) = Kby ( 3 , 2 );
    K1b ( 9  , 9  ) = Kby ( 3 , 3 );
    K1b ( 9  , 11 ) = Kby ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o YY -- LINHA 4
    K1b ( 11 , 3  ) = Kby ( 4 , 1 );
    K1b ( 11 , 5  ) = Kby ( 4 , 2 );
    K1b ( 11 , 9  ) = Kby ( 4 , 3 );
    K1b ( 11 , 11 ) = Kby ( 4 , 4 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o ZZ -- LINHA 1
    K1b ( 2  , 2  ) = Kbz ( 1 , 1 );
    K1b ( 2  , 6  ) = Kbz ( 1 , 2 );
    K1b ( 2  , 8  ) = Kbz ( 1 , 3 );
    K1b ( 2  , 12 ) = Kbz ( 1 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o ZZ -- LINHA 2
    K1b ( 6  , 2  ) = Kbz ( 2 , 1 );
    K1b ( 6  , 6  ) = Kbz ( 2 , 2 );
    K1b ( 6  , 8  ) = Kbz ( 2 , 3 );
    K1b ( 6  , 12 ) = Kbz ( 2 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o ZZ -- LINHA 3
    K1b ( 8  , 2  ) = Kbz ( 3 , 1 );
    K1b ( 8  , 6  ) = Kbz ( 3 , 2 );
    K1b ( 8  , 8  ) = Kbz ( 3 , 3 );
    K1b ( 8  , 12 ) = Kbz ( 3 , 4 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Flex�o ZZ -- LINHA 4
    K1b ( 12 , 2  ) = Kbz ( 4 , 1 );
    K1b ( 12 , 6  ) = Kbz ( 4 , 2 );
    K1b ( 12 , 8  ) = Kbz ( 4 , 3 );
    K1b ( 12 , 12 ) = Kbz ( 4 , 4 );
   
end

