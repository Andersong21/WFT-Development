%% Cria��o da Matriz de Rigidez Axial do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% E                 - M�dulo de Elasticidade do Elemento Beam2
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Ba                - Matriz de Correla��o Deforma��o Deslocamento Axial do Elemento Beam2


%% OUTPUT
% K1a               - Matriz de Rigidez Axial do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez Axial do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ K1a ] = matrix_Ka_QG_beam2 ( E , b , h , J , Ba )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Axial
    Ka = E * b * h * ( transpose ( Ba ) * Ba ) * J;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ AXIAL DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Axial Local
    K1a = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez Axial -- LINHA 1
    K1a ( 1  , 1  ) = Ka ( 1 , 1 );
    K1a ( 1  , 7  ) = Ka ( 1 , 2 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Axial -- LINHA 2
    K1a ( 7  , 1  ) = Ka ( 2 , 1 );
    K1a ( 7  , 7  ) = Ka ( 2 , 2 );   
   
end

