%% Cria��o da Matriz de Rigidez do Elemento Tapered Beam2

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Elemento i

%% OUTPUT
% Ki                - Termo i da Matriz de Rigidez Global
% Kj                - Termo j da Matriz de Rigidez Global
% Kv                - Valor ( i , j ) da Matriz de Rigidez Global

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez do Elemento
function [ Ki , Kj , Kv ] = matrix_K_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno das Defini��es Iniciais da Propriedade
    [ b , h ] = get_section_param ( Elem_Param , Prop_Param , i );    
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE PESOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Pesos na Quadratura de Gauss
    [ WEa , WEb , WEs , WEt ] = matrix_WE_beam2 ();    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DOS PONTOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz dos Pontos na Quadratura de Gauss
    [ POa , POb , POs , POt ] = matrix_PO_beam2 ();    
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_beam2 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_beam2 ( Cg );
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_beam2 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva do Elemento
    [ E , G ] = matrix_D_beam2 ( Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local Final -- Axial
    Kla = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Axial
    for j = 1:1  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POa ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );         

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Ba ] = matrix_Ba_beam2 ( Cl );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Rigidez no Ponto de Integra��o
        [ K1a ] = matrix_Ka_QG_beam2 ( E , b , h , J , Ba );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Rigidez no Ponto de Integra��o
        Kla = Kla + ( WEa ( j ) * K1a );
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local Final -- Flex�o
    Klb = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Flex�o
    for j = 1:2  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POb ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bby , Bbz ] = matrix_Bb_beam2 ( E , G , b , h , Cl , r );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Rigidez no Ponto de Integra��o
        [ K1b ] = matrix_Kb_QG_beam2 ( E , b , h , J , Bby , Bbz );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Rigidez no Ponto de Integra��o
        Klb = Klb + ( WEb ( j ) * K1b ); 
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local Final -- Cisalhamento
    Kls = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Cisalhamento
    for j = 1:1  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POs ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );        

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bsy , Bsz ] = matrix_Bs_beam2 ( E , G , b , h , Cl , r );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Rigidez no Ponto de Integra��o
        [ K1s ] = matrix_Ks_QG_beam2 ( G , b , h , J , Bsy , Bsz );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Rigidez no Ponto de Integra��o
        Kls = Kls + ( WEs ( j ) * K1s ); 
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Local Final -- Tor��o
    Klt = zeros ( 12 , 12 );
    
    % Varredura nos Pontos e da Quadratura de Gauss -- Tor��o
    for j = 1:1  
        
        %%%%%%%%%%%%%%%%%%%%%
        % PONTOS QUADRATURA %
        %%%%%%%%%%%%%%%%%%%%%
         
        % Ponto na Quadratura -- r
        r = POt ( j , 1 );

        %%%%%%%%%%%%%%%%%%%%
        % MATRIZ JACOBIANA %
        %%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz Jacobiana
        [ J ] = matrix_J_beam2 ( Cl );       

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bt ] = matrix_Bt_beam2 ( Cl );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % QUADRATURA DE GAUSS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Rigidez no Ponto de Integra��o
        [ K1t ] = matrix_Kt_QG_beam2 ( G , b , h , J , Bt );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE RIGIDEZ DO ELEMENTO % LOCAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Matriz de Rigidez no Ponto de Integra��o
        Klt = Klt + ( WEt ( j ) * K1t ); 
        
    end 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Rigidez Local do Elemento
    Kl = Kla + Klb + Kls + Klt;   
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO % GLOBAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Global do Elemento
    Kg = R * Kl * transpose ( R );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE GRAUS DE LIBERDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador de Graus de Liberdade do Elemento
    Ndof = 1;
    
    % Inicializa��o do Vetor de Graus de Liberdade
    DOF = zeros ( 12 , 1 );
    
    % Varredura nos N�s do Elemento
    for j = 1:length( Elem_Param ( i ).node )
       
        % Id do N�
        Idn = Elem_Param ( i ).node ( j );
        
        % Varredura nos Graus de Liberdade dos N�s do Elemento
        for k = 1:length ( Node_Param ( Idn ).dof )            
            
            % Aloca��o no Vetor de Graus de Liberdade
            DOF ( Ndof ) = Node_Param ( Idn ).dof ( k );
            
            % Incremento na Contagem de Graus de Liberdade
            Ndof = Ndof + 1;
            
        end         
        
    end
    
    % Inicializa��o do Contador
    cont = 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o na Matriz de Rigidez Global do Problema
    for j = 1:12
        
        % Verifica��o se o Grau de Liberdade � nulo
        if ( DOF ( j ) == 0 )
            
            % Continuar
            continue;
            
        else      
            
            % Aloca��o na Matriz de Rigidez Global do Problema        
            for k = 1:12

                % Verifica��o se o Grau de Liberdade � nulo
                if ( DOF ( k ) == 0 )
                    
                    % Continuar
                    continue;
                
                else
                    
                    % Aloca��o Sim�trica
                    if ( j > k )
                        
                        % Continuar
                        continue;
                    end
                    
                    % Aloca��o de Termo Nulo
                    if ( Kg ( j , k ) == 0 )
                        
                        % Continuar
                        continue;
                        
                    end

                    % Aloca��o dos Termos da Matriz na Posi��o Global
                    Ki ( cont ) = DOF ( j );
                    Kj ( cont ) = DOF ( k );
                    Kv ( cont ) = Kg ( j , k );
                    
                    % Incremento do Contador
                    cont = cont + 1;

                end
                
            end
            
        end
        
    end
    
end

