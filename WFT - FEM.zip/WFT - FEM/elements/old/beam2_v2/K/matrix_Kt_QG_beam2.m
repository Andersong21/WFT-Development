%% Cria��o da Matriz de Rigidez Tor��o do Elemento Beam2 no Ponto da Quadratura de Gauss

%% INPUT
% G                 - M�dulo de Elasticidade Transversal do Elemento Beam2
% b                 - Base M�dia do Elemento Beam2
% h                 - Altura M�dia do Elemento Beam2
% J                 - Matriz Jacobiana do Elemento
% Bt                - Matriz de Correla��o Deforma��o Deslocamento Tor��o do Elemento Beam2


%% OUTPUT
% K1t               - Matriz de Rigidez Tor��o do Elemento Beam2 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Rigidez Tor��o do Elemento Beam2 no Ponto da Quadratura de Gauss
function [ K1t ] = matrix_Kt_QG_beam2 ( G , b , h , J , Bt )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Rigidez Tor��o
    Kt = G * ( ( b * h * h * h / 12 ) + ( h * b * b * b / 12 ) ) * ( transpose ( Bt ) * Bt ) * J;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE RIGIDEZ TOR��O DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Rigidez Tor��o Local
    K1t = zeros ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE RIGIDEZ TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Rigidez Tor��o -- LINHA 1
    K1t ( 4  , 4  ) = Kt ( 1 , 1 );
    K1t ( 4  , 10 ) = Kt ( 1 , 2 );
    
    % Aloca��o dos Termos da Matriz de Rigidez Tor��o -- LINHA 2
    K1t ( 10 , 4  ) = Kt ( 2 , 1 );
    K1t ( 10 , 10 ) = Kt ( 2 , 2 );   
   
end

