%% Cria��o da Matriz dos Pontos da Quadratura de Gauss do Elemento Beam2

%% OUTPUT
% POa               - Matriz dos Pontos da Quadratura de Gauss do Beam2 -- Parcela Tra��o
% POb               - Matriz dos Pontos da Quadratura de Gauss do Beam2 -- Parcela Flex�o
% POs               - Matriz dos Pontos da Quadratura de Gauss do Beam2 -- Parcela Cisalhamento
% POt               - Matriz dos Pontos da Quadratura de Gauss do Beam2 -- Parcela Tor��o

%% Declara��o da Fun��o de Cria��o da Matriz dos Pontos da Quadratura de Gauss do Elemento Quad4
function [ POa , POb , POs , POt ] = matrix_PO_beam2 ()
   
    %%%%%%%%%
    % AXIAL %
    %%%%%%%%%

    % Inicializa��o da Matriz dos Pontos da Quadratura de Gauss -- Axial
    POa = zeros ( 1 , 1 );
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 1 -- Axial
    POa ( 1 , 1 ) = 0.0;
    
    %%%%%%%%%%
    % FLEX�O %
    %%%%%%%%%%

    % Inicializa��o da Matriz dos Pontos da Quadratura de Gauss -- Flex�o
    POb = zeros ( 2 , 1 );
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 1 -- Flex�o
    POb ( 1 , 1 ) = + 0.577350269189626;
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 2 -- Flex�o
    POb ( 2 , 1 ) = - 0.577350269189626;
    
    %%%%%%%%%%%%%%%%
    % CISALHAMENTO %
    %%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz dos Pontos da Quadratura de Gauss -- Cisalhamento
    POs = zeros ( 1 , 1 );

    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 1 -- Cisalhamento
    POs ( 1 , 1 ) = 0.0;  
    
    %%%%%%%%%%
    % TOR��O %
    %%%%%%%%%%
        
    % Inicializa��o da Matriz dos Pontos da Quadratura de Gauss -- Tor��o
    POt = zeros ( 1 , 1 );
    
    % Defini��o dos Pontos da Quadratura de Gauss -- PONTO 1 -- Tor��o
    POt ( 1 , 1 ) = 0.0;
    
end

