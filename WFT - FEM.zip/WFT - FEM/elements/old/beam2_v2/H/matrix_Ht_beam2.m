%% Cria��o da Matriz de Fun��es de Forma Tor��o do Elemento Beam2

%% INPUT
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento
% r                 - Coordenada natural r do Elemento

%% OUTPUT
% Ht                - Matriz de Fun��es de Forma Tor��o do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Fun��es de Forma Tor��o do Elemento Beam2
function [ Ht ] = matrix_Ht_beam2 ( Cl , r )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenadas X do Elemento
    x1 = Cl ( 1 , 1 );
    x2 = Cl ( 2 , 1 );
    
    % Comprimento do Elemento
    L = Cl ( 2 , 1 ) - Cl ( 1 , 1 );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma de Tor��o
    Ht = zeros ( 1 , 2 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma de Tor��o
    Ht ( 1 , 1 ) = 1 - ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) / L;
    Ht ( 1 , 2 ) = ( ( ( 1 - r ) * x1 ) / 2 + ( ( 1 + r ) * x2 ) / 2 ) / L;
    
end


