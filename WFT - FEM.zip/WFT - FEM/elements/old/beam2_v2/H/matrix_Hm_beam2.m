%% Cria��o da Matriz de Fun��es de Forma Membrana do Eemento Beam2

%% INPUT
% E                 - M�dulo de Easticidade do Eemento
% G                 - M�dulo de Easticidade Transversal do Eemento
% rho               - Densidade do Eemento
% b                 - Base M�dia do Eemento
% h                 - Altura M�dia do Eemento
% Cl                - Matriz de Coordenadas Nodais Locais do Eemento
% r                 - Coordenada Natural r do Eemento

%% OUTPUT
% Hmy               - Matriz de Fun��es de Forma Membrana YY do Eemento Beam2
% Hmz               - Matriz de Fun��es de Forma Membrana ZZ do Eemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Fun��es de Forma Membrana do Eemento Beam2
function [ Hmy , Hmz ] = matrix_Hm_beam2 ( E , G , b , h , Cl , r )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenadas X do Eemento
    x1 = Cl ( 1 , 1 );
    x2 = Cl ( 2 , 1 );
    
    % Comprimento do Eemento
    L = x2 - x1;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA % MEMBRANA YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma Membrana Iyy
    Hmy = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma Membrana Iyy
    Hmy ( 1 , 1 ) = ( + 5 * G*(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.)*(L + ((1 - r)*x1)/2. + ((1 + r)*x2)/2.))/(6*power(b,2)*E + 5*G*power(L,2));
    Hmy ( 1 , 2 ) = ( ( L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.)*(3*power(b,2)*E*(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.) - 5*G*power(L,2)*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.)))/(6*power(b,2)*E*L + 5*G*power(L,3));
    Hmy ( 1 , 3 ) = ( + 6 * power(b,2)*E + 5*G*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2))/(6*power(b,2)*E + 5*G*power(L,2));
    Hmy ( 1 , 4 ) = ( + 3 * power(b,2)*E*(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.)*(L + ((1 - r)*x1)/2. + ((1 + r)*x2)/2.)) / ( 6*power(b,2)*E*L + 5*G*power(L,3));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA % MEMBRANA ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma Membrana Izz
    Hmz = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma Membrana Iyy
    Hmz ( 1 , 1 ) = ( + 5 * G*(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.)*(L + ((1 - r)*x1)/2. + ((1 + r)*x2)/2.))/(6*E*power(h,2) + 5*G*power(L,2));
    Hmz ( 1 , 2 ) = ( ( L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.)*(5*G*power(L,2)*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.) + 3*E*power(h,2)*(-L + ((1 - r)*x1)/2. + ((1 + r)*x2)/2.)))/(6*E*power(h,2)*L + 5*G*power(L,3));
    Hmz ( 1 , 3 ) = ( + 6 * E*power(h,2) + 5*G*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2))/(6*E*power(h,2) + 5*G*power(L,2));
    Hmz ( 1 , 4 ) = ( + 3 * E*power(h,2)*(-power(L,2) + power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2)))/(6*E*power(h,2)*L + 5*G*power(L,3));
    
end

