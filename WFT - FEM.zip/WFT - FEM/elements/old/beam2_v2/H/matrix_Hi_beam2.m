%% Cria��o da Matriz de Fun��es de Forma In�rcia do Eemento Beam2

%% INPUT
% E                 - M�dulo de Elasticidade do Eemento
% G                 - M�dulo de Elasticidade Transversal do Eemento
% rho               - Densidade do Eemento
% b                 - Base M�dia do Eemento
% h                 - Altura M�dia do Eemento
% Cl                - Matriz de Coordenadas Nodais Locais do Eemento
% r                 - Coordenada Natural r do Eemento

%% OUTPUT
% Hiy               - Matriz de Fun��es de Forma In�rcia YY do Eemento Beam2
% Hiz               - Matriz de Fun��es de Forma In�rcia ZZ do Eemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz de Fun��es de Forma In�rcia do Eemento Beam2
function [ Hiy , Hiz ] = matrix_Hi_beam2 ( E , G , b , h , Cl , r )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenadas X do Eemento
    x1 = Cl ( 1 , 1 );
    x2 = Cl ( 2 , 1 );
    
    % Comprimento do Eemento
    L = x2 - x1;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA % IN�RCIA YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma In�rcia Iyy
    Hiy = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma In�rcia Iyy
    Hiy ( 1 , 1 ) = ( + 3 * power(b,2)*E*L + 5*G*power(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.,2)*(L + 2*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.))) / (6*power(b,2)*E*L + 5*G*power(L,3));
    Hiy ( 1 , 2 ) = ( + 3 * power(b,4)*power(E,2) - 25*power(G,2)*L*power(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.,2)*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.) + 5*power(b,2)*E*G*(2*power(L,2) - 6*L*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.) + 3*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2)))/(5.*G*L*(6*power(b,2)*E + 5*G*power(L,2)));
    Hiy ( 1 , 3 ) = ( + 3 * power(b,2)*E*L + 5*G* power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2)* (3*L - 2*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.)))/ (6*power(b,2)*E*L + 5*G*power(L,3));
    Hiy ( 1 , 4 ) = ( - 3 * power(b,4)*power(E,2) + 25*power(G,2)*L*(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.)* power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2) + 5*power(b,2)*E*G*(power(L,2) - 3*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2)))/ (5.*G*L*(6*power(b,2)*E + 5*G*power(L,2)));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE FUN��ES DE FORMA % IN�RCIA ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Fun��es de Forma In�rcia Izz
    Hiz = zeros ( 1 , 4 );
    
    % Aloca��o dos Termos na Matriz de Fun��es de Forma In�rcia Iyy
    Hiz ( 1 , 1 ) = ( + 3 * E*power(h,2)*L + 5*G* power(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.,2)* (L + 2*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.)))/(6*E*power(h,2)*L + 5*G*power(L,3));
    Hiz ( 1 , 2 ) = ( - 3 * power(E,2)*power(h,4) + 25*power(G,2)*L*power(L - ((1 - r)*x1)/2. - ((1 + r)*x2)/2.,2) * (((1 - r)*x1)/2. + ((1 + r)*x2)/2.) - 5*E*G*power(h,2) * (2*power(L,2) - 6*L * (((1 - r)*x1)/2. + ((1 + r)*x2)/2.) + 3*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2)))/ (5.*G*L*(6*E*power(h,2) + 5*G*power(L,2)));
    Hiz ( 1 , 3 ) = ( + 3 * E*power(h,2)*L + 5*G * power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2) * (3*L - 2*(((1 - r)*x1)/2. + ((1 + r)*x2)/2.))) / (6*E*power(h,2)*L + 5*G*power(L,3));
    Hiz ( 1 , 4 ) = ( + 3 * power(E,2)*power(h,4) + 25*power(G,2)*L*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2) * (-L + ((1 - r)*x1)/2. + ((1 + r)*x2)/2.) - 5*E*G*power(h,2) * (power(L,2) - 3*power(((1 - r)*x1)/2. + ((1 + r)*x2)/2.,2))) / (5.*G*L*(6*E*power(h,2) + 5*G*power(L,2)));
    
end

