%% Cria��o do Vetor de For�as Nodais Locais do Elemento Beam2

%% INPUT
% R                 - Matriz de Rota��o do Elemento
% Fg                - Vetor de For�as Nodais Globais do Elemento

%% OUTPUT
% Fl                - Vetor de For�as Nodais Locais do Elemento

%% Declara��o da Fun��o de Cria��o do Vetor de For�as Nodais Locais do Elemento Beam2
function [ Fl ] = vector_Fl_beam2 ( R , Fg )    

    % Inicializa��o do Vetor de For�as Nodais Locais
    Fl = transpose ( R ) * Fg;    
        
end

