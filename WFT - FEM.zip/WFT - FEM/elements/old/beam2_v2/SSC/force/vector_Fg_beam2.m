%% Cria��o do Vetor de For�as Nodais Globais do Elemento Beam2

%% INPUT
% Kg                - Matriz de Rigidez Global do Elemento
% Ug                - Vetor de Deslocamentos Globais do Elemento

%% OUTPUT
% Ug                - Vetor de For�as Nodais Globais do Elemento

%% Declara��o da Fun��o de Cria��o do Vetor de For�as Nodais Globais do Elemento Beam2
function [ Fg ] = vector_Fg_beam2 ( Kg , Ug )    
   
    % C�lculo do Vetor de For�as Nodais do Elemento
    Fg = Kg * Ug;
    
end

