%% Cria��o do Vetor de Tens�es Globais do Elemento Beam2

%% INPUT
% SlA               - Vetor de Tens�es Locais no Ponto A
% SlB               - Vetor de Tens�es Locais no Ponto B
% SlC               - Vetor de Tens�es Locais no Ponto C
% SlD               - Vetor de Tens�es Locais no Ponto D
% R                 - Matriz de Transforma�ao de Coordenada do Elemento

%% OUTPUT
% SgA               - Vetor de Tens�es Globais no Ponto A
% SgB               - Vetor de Tens�es Globais no Ponto B
% SgC               - Vetor de Tens�es Globais no Ponto C
% SgD               - Vetor de Tens�es Globais no Ponto D

%% Declara��o da Fun��o de Cria��o Vetor de Tens�es Globais do Elemento Beam2
function [ SgA , SgB , SgC , SgD ] = vector_Sg_beam2 ( SlA , SlB , SlC , SlD , R )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Ponto A
    matrix_Sl_A = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em A -- Linha 1
    matrix_Sl_A ( 1 , 1 ) = SlA ( 1 );
    matrix_Sl_A ( 1 , 2 ) = SlA ( 4 );
    matrix_Sl_A ( 1 , 3 ) = SlA ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em A -- Linha 2
    matrix_Sl_A ( 2 , 1 ) = SlA ( 4 );
    matrix_Sl_A ( 2 , 2 ) = SlA ( 2 );
    matrix_Sl_A ( 2 , 3 ) = SlA ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em A -- Linha 3
    matrix_Sl_A ( 3 , 1 ) = SlA ( 6 );
    matrix_Sl_A ( 3 , 2 ) = SlA ( 5 );
    matrix_Sl_A ( 3 , 3 ) = SlA ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Global no Ponto A
    matrix_Sg_A = R ( 1:3 , 1:3 ) * matrix_Sl_A * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em A
    SgA ( 1 ) = matrix_Sg_A ( 1 , 1 );
    SgA ( 2 ) = matrix_Sg_A ( 2 , 2 );
    SgA ( 3 ) = matrix_Sg_A ( 3 , 3 );
    SgA ( 4 ) = matrix_Sg_A ( 1 , 2 );
    SgA ( 5 ) = matrix_Sg_A ( 2 , 3 );
    SgA ( 6 ) = matrix_Sg_A ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Ponto B
    matrix_Sl_B = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em B -- Linha 1
    matrix_Sl_B ( 1 , 1 ) = SlB ( 1 );
    matrix_Sl_B ( 1 , 2 ) = SlB ( 4 );
    matrix_Sl_B ( 1 , 3 ) = SlB ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em B -- Linha 2
    matrix_Sl_B ( 2 , 1 ) = SlB ( 4 );
    matrix_Sl_B ( 2 , 2 ) = SlB ( 2 );
    matrix_Sl_B ( 2 , 3 ) = SlB ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em B -- Linha 3
    matrix_Sl_B ( 3 , 1 ) = SlB ( 6 );
    matrix_Sl_B ( 3 , 2 ) = SlB ( 5 );
    matrix_Sl_B ( 3 , 3 ) = SlB ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Global no Ponto B
    matrix_Sg_B = R ( 1:3 , 1:3 ) * matrix_Sl_B * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em B
    SgB ( 1 ) = matrix_Sg_B ( 1 , 1 );
    SgB ( 2 ) = matrix_Sg_B ( 2 , 2 );
    SgB ( 3 ) = matrix_Sg_B ( 3 , 3 );
    SgB ( 4 ) = matrix_Sg_B ( 1 , 2 );
    SgB ( 5 ) = matrix_Sg_B ( 2 , 3 );
    SgB ( 6 ) = matrix_Sg_B ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM C %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Ponto C
    matrix_Sl_C = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em C -- Linha 1
    matrix_Sl_C ( 1 , 1 ) = SlC ( 1 );
    matrix_Sl_C ( 1 , 2 ) = SlC ( 4 );
    matrix_Sl_C ( 1 , 3 ) = SlC ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em C -- Linha 2
    matrix_Sl_C ( 2 , 1 ) = SlC ( 4 );
    matrix_Sl_C ( 2 , 2 ) = SlC ( 2 );
    matrix_Sl_C ( 2 , 3 ) = SlC ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em C -- Linha 3
    matrix_Sl_C ( 3 , 1 ) = SlC ( 6 );
    matrix_Sl_C ( 3 , 2 ) = SlC ( 5 );
    matrix_Sl_C ( 3 , 3 ) = SlC ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM C %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Global no Ponto C
    matrix_Sg_C = R ( 1:3 , 1:3 ) * matrix_Sl_C * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em C
    SgC ( 1 ) = matrix_Sg_C ( 1 , 1 );
    SgC ( 2 ) = matrix_Sg_C ( 2 , 2 );
    SgC ( 3 ) = matrix_Sg_C ( 3 , 3 );
    SgC ( 4 ) = matrix_Sg_C ( 1 , 2 );
    SgC ( 5 ) = matrix_Sg_C ( 2 , 3 );
    SgC ( 6 ) = matrix_Sg_C ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O LOCAL EM D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Local no Ponto D
    matrix_Sl_D = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Tens�o Local em D -- Linha 1
    matrix_Sl_D ( 1 , 1 ) = SlD ( 1 );
    matrix_Sl_D ( 1 , 2 ) = SlD ( 4 );
    matrix_Sl_D ( 1 , 3 ) = SlD ( 6 );
    
    % Aloca��o dos Termos de Tens�o Local em D -- Linha 2
    matrix_Sl_D ( 2 , 1 ) = SlD ( 4 );
    matrix_Sl_D ( 2 , 2 ) = SlD ( 2 );
    matrix_Sl_D ( 2 , 3 ) = SlD ( 5 );
    
    % Aloca��o dos Termos de Tens�o Local em D -- Linha 3
    matrix_Sl_D ( 3 , 1 ) = SlD ( 6 );
    matrix_Sl_D ( 3 , 2 ) = SlD ( 5 );
    matrix_Sl_D ( 3 , 3 ) = SlD ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TENS�O GLOBAL EM D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Tens�o Global no Ponto D
    matrix_Sg_D = R ( 1:3 , 1:3 ) * matrix_Sl_D * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Tens�es Globais em D
    SgD ( 1 ) = matrix_Sg_D ( 1 , 1 );
    SgD ( 2 ) = matrix_Sg_D ( 2 , 2 );
    SgD ( 3 ) = matrix_Sg_D ( 3 , 3 );
    SgD ( 4 ) = matrix_Sg_D ( 1 , 2 );
    SgD ( 5 ) = matrix_Sg_D ( 2 , 3 );
    SgD ( 6 ) = matrix_Sg_D ( 1 , 3 );   

end

