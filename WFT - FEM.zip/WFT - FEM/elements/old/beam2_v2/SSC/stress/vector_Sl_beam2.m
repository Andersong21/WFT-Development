%% Cria��o do Vetor de Tens�es Locais do Elemento Beam2

%% INPUT
% Ba                - Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2
% Bby               - Matriz de Correla��o Deslocamento Deforma��o de Flex�o YY do Elemento Beam2
% Bbz               - Matriz de Correla��o Deslocamento Deforma��o de Flex�o ZZ do Elemento Beam2
% Bsy               - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento YY do Elemento Beam2
% Bsz               - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento ZZ do Elemento Beam2
% Bt                - Matriz de Correla��o Deslocamento Deforma��o de Tor��o do Elemento Beam2
% Ul                - Vetor de Deslocamento Nodais Locais do Elemento
% b                 - Base do Elemento no Ponto de Coordenada Natural e
% h                 - Altura do Elemento no Ponto de Coordenada Natural e
% E                 - M�dulo de Elasticidade
% G                 - M�dulo de Elasticidade Transversal
% local             - Local de C�lculo das Deforma��es na Viga
%                   - [ C ] = Canto
%                   - [ E ] = Extremidade  

%% OUTPUT
% SlA               - Vetor de Tens�es Locais no Ponto A
% SlB               - Vetor de Tens�es Locais no Ponto B
% SlC               - Vetor de Tens�es Locais no Ponto C
% SlD               - Vetor de Tens�es Locais no Ponto D

%% Declara��o da Fun��o de Cria��o Vetor de Tens�es Locais do Elemento Beam2
function [ SlA , SlB , SlC , SlD ] = vector_Sl_beam2 ( Ba , Bby , Bbz , Bsy , Bsz , Bt , Ul , b , h , E , G , local )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Axial
    Ula = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Axial
    Ula ( 1 , 1 ) = Ul ( 1  , 1 );
    Ula ( 2 , 1 ) = Ul ( 7  , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o YY
    Uly = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o YY
    Uly ( 1 , 1 ) = Ul ( 3  , 1 );
    Uly ( 2 , 1 ) = Ul ( 5  , 1 );
    Uly ( 3 , 1 ) = Ul ( 9  , 1 );
    Uly ( 4 , 1 ) = Ul ( 11 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o ZZ
    Ulz = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o ZZ
    Ulz ( 1 , 1 ) = Ul ( 2  , 1 );
    Ulz ( 2 , 1 ) = Ul ( 6  , 1 );
    Ulz ( 3 , 1 ) = Ul ( 8  , 1 );
    Ulz ( 4 , 1 ) = Ul ( 12 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Tor��o
    Ult = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Tor��o
    Ult ( 1 , 1 ) = Ul ( 4  , 1 );
    Ult ( 2 , 1 ) = Ul ( 10 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DEFORMA��ES CANTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��o Canto
    if ( strcmp ( local , 'C' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = + h / 2;
        zl = + b / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto A
        S_axial_A = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto A
        S_by_A = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto A
        S_sy_A = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto A
        S_bz_A = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto A
        S_sz_A = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto A
        S_f_A  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        SlA ( 1 ) = S_axial_A ( 1 ) + S_by_A ( 1 ) + S_bz_A ( 1 );
        SlA ( 2 ) = 0;
        SlA ( 3 ) = 0;
        SlA ( 4 ) = S_f_A  ( 1 );
        SlA ( 5 ) = S_sy_A ( 1 );
        SlA ( 6 ) = S_sz_A ( 1 );

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = - h / 2;
        zl = + b / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto B
        S_axial_B = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto B
        S_by_B = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto B
        S_sy_B = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto B
        S_bz_B = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto B
        S_sz_B = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto B
        S_f_B  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto B
        SlB ( 1 ) = S_axial_B ( 1 ) + S_by_B ( 1 ) + S_bz_B ( 1 );
        SlB ( 2 ) = 0;
        SlB ( 3 ) = 0;
        SlB ( 4 ) = S_f_B  ( 1 );
        SlB ( 5 ) = S_sy_B ( 1 );
        SlB ( 6 ) = S_sz_B ( 1 );

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - h / 2;
        zl = - b / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto C
        S_axial_C = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto C
        S_by_C = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto C
        S_sy_C = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto C
        S_bz_C = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto C
        S_sz_C = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto C
        S_f_C  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto C
        SlC ( 1 ) = S_axial_C ( 1 ) + S_by_C ( 1 ) + S_bz_C ( 1 );
        SlC ( 2 ) = 0;
        SlC ( 3 ) = 0;
        SlC ( 4 ) = S_f_C  ( 1 );
        SlC ( 5 ) = S_sy_C ( 1 );
        SlC ( 6 ) = S_sz_C ( 1 );

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = + h / 2;
        zl = - b / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto D
        S_axial_D = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto D
        S_by_D = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto D
        S_sy_D = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto D
        S_bz_D = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto D
        S_sz_D = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto D
        S_f_D  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto D
        SlD ( 1 ) = S_axial_D ( 1 ) + S_by_D ( 1 ) + S_bz_D ( 1 );
        SlD ( 2 ) = 0;
        SlD ( 3 ) = 0;
        SlD ( 4 ) = S_f_D  ( 1 );
        SlD ( 5 ) = S_sy_D ( 1 );
        SlD ( 6 ) = S_sz_D ( 1 );
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DEFORMA��ES EXTREMIDADE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��o Extremidade
    if ( strcmp ( local , 'E' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = + h / 2;
        zl = 0;

        % Determina��o do Vetor de Tens�es Axiais do Ponto A
        S_axial_A = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto A
        S_by_A = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto A
        S_sy_A = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto A
        S_bz_A = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto A
        S_sz_A = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto A
        S_f_A  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        SlA ( 1 ) = S_axial_A ( 1 ) + S_by_A ( 1 ) + S_bz_A ( 1 );
        SlA ( 2 ) = 0;
        SlA ( 3 ) = 0;
        SlA ( 4 ) = S_f_A  ( 1 );
        SlA ( 5 ) = S_sy_A ( 1 );
        SlA ( 6 ) = S_sz_A ( 1 );

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = 0;
        zl = + b / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto B
        S_axial_B = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto B
        S_by_B = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto B
        S_sy_B = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto B
        S_bz_B = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto B
        S_sz_B = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto B
        S_f_B  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto B
        SlB ( 1 ) = S_axial_B ( 1 ) + S_by_B ( 1 ) + S_bz_B ( 1 );
        SlB ( 2 ) = 0;
        SlB ( 3 ) = 0;
        SlB ( 4 ) = S_f_B  ( 1 );
        SlB ( 5 ) = S_sy_B ( 1 );
        SlB ( 6 ) = S_sz_B ( 1 );

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - h / 2;
        zl = 0;

        % Determina��o do Vetor de Tens�es Axiais do Ponto C
        S_axial_C = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto C
        S_by_C = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto C
        S_sy_C = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto C
        S_bz_C = - E * yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto C
        S_sz_C = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto C
        S_f_C  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto C
        SlC ( 1 ) = S_axial_C ( 1 ) + S_by_C ( 1 ) + S_bz_C ( 1 );
        SlC ( 2 ) = 0;
        SlC ( 3 ) = 0;
        SlC ( 4 ) = S_f_C  ( 1 );
        SlC ( 5 ) = S_sy_C ( 1 );
        SlC ( 6 ) = S_sz_C ( 1 );

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = 0;
        zl = - b / 2;

        % Determina��o do Vetor de Tens�es Axiais do Ponto D
        S_axial_D = E * Ba * Ula;
        
        % Determina��o do Vetor de Tens�es Flex�o YY do Ponto D
        S_by_D = - E * zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Tens�es Cisalhamento YY do Ponto D
        S_sy_D = - G * ( Bsy * Uly );
        
        % Determina��o do Vetor de Tens�es Flex�o ZZ do Ponto D
        S_bz_D = - E * yl * ( Bbz * Ulz );
        
        % Determina��o do Vetor de Tens�es Cisalhamento ZZ do Ponto D
        S_sz_D = - G * ( Bsz * Ulz );

        % Determina��o do Vetor de Tens�es Tor��o do Ponto D
        S_f_D  = - G * ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto D
        SlD ( 1 ) = S_axial_D ( 1 ) + S_by_D ( 1 ) + S_bz_D ( 1 );
        SlD ( 2 ) = 0;
        SlD ( 3 ) = 0;
        SlD ( 4 ) = S_f_D  ( 1 );
        SlD ( 5 ) = S_sy_D ( 1 );
        SlD ( 6 ) = S_sz_D ( 1 );
        
    end      
    
end

