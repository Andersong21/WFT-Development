%% Cria��o do Vetor de Deforma��es Globais do Elemento Beam2

%% INPUT
% ElA               - Vetor de Deforma��o Local no Ponto A
% ElB               - Vetor de Deforma��o Local no Ponto B
% ElC               - Vetor de Deforma��o Local no Ponto C
% ElD               - Vetor de Deforma��o Local no Ponto D
% R                 - Matriz de Transforma�ao de Coordenada do Elemento

%% OUTPUT
% EgA               - Vetor de Deforma��o Global no Ponto A
% EgB               - Vetor de Deforma��o Global no Ponto B
% EgC               - Vetor de Deforma��o Global no Ponto C
% EgD               - Vetor de Deforma��o Global no Ponto D

%% Declara��o da Fun��o de Cria��o Vetor de Deforma��es Globais do Elemento Beam2
function [ EgA , EgB , EgC , EgD ] = vector_Eg_beam2 ( ElA , ElB , ElC , ElD , R )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto A
    matrix_El_A = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em A -- Linha 1
    matrix_El_A ( 1 , 1 ) = ElA ( 1 );
    matrix_El_A ( 1 , 2 ) = ElA ( 4 );
    matrix_El_A ( 1 , 3 ) = ElA ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em A -- Linha 2
    matrix_El_A ( 2 , 1 ) = ElA ( 4 );
    matrix_El_A ( 2 , 2 ) = ElA ( 2 );
    matrix_El_A ( 2 , 3 ) = ElA ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em A -- Linha 3
    matrix_El_A ( 3 , 1 ) = ElA ( 6 );
    matrix_El_A ( 3 , 2 ) = ElA ( 5 );
    matrix_El_A ( 3 , 3 ) = ElA ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto A
    matrix_Eg_A = R ( 1:3 , 1:3 ) * matrix_El_A * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em A
    EgA ( 1 ) = matrix_Eg_A ( 1 , 1 );
    EgA ( 2 ) = matrix_Eg_A ( 2 , 2 );
    EgA ( 3 ) = matrix_Eg_A ( 3 , 3 );
    EgA ( 4 ) = matrix_Eg_A ( 1 , 2 );
    EgA ( 5 ) = matrix_Eg_A ( 2 , 3 );
    EgA ( 6 ) = matrix_Eg_A ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto B
    matrix_El_B = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em B -- Linha 1
    matrix_El_B ( 1 , 1 ) = ElB ( 1 );
    matrix_El_B ( 1 , 2 ) = ElB ( 4 );
    matrix_El_B ( 1 , 3 ) = ElB ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em B -- Linha 2
    matrix_El_B ( 2 , 1 ) = ElB ( 4 );
    matrix_El_B ( 2 , 2 ) = ElB ( 2 );
    matrix_El_B ( 2 , 3 ) = ElB ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em B -- Linha 3
    matrix_El_B ( 3 , 1 ) = ElB ( 6 );
    matrix_El_B ( 3 , 2 ) = ElB ( 5 );
    matrix_El_B ( 3 , 3 ) = ElB ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL EM B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto B
    matrix_Eg_B = R ( 1:3 , 1:3 ) * matrix_El_B * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em B
    EgB ( 1 ) = matrix_Eg_B ( 1 , 1 );
    EgB ( 2 ) = matrix_Eg_B ( 2 , 2 );
    EgB ( 3 ) = matrix_Eg_B ( 3 , 3 );
    EgB ( 4 ) = matrix_Eg_B ( 1 , 2 );
    EgB ( 5 ) = matrix_Eg_B ( 2 , 3 );
    EgB ( 6 ) = matrix_Eg_B ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM C %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto C
    matrix_El_C = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em C -- Linha 1
    matrix_El_C ( 1 , 1 ) = ElC ( 1 );
    matrix_El_C ( 1 , 2 ) = ElC ( 4 );
    matrix_El_C ( 1 , 3 ) = ElC ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em C -- Linha 2
    matrix_El_C ( 2 , 1 ) = ElC ( 4 );
    matrix_El_C ( 2 , 2 ) = ElC ( 2 );
    matrix_El_C ( 2 , 3 ) = ElC ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em C -- Linha 3
    matrix_El_C ( 3 , 1 ) = ElC ( 6 );
    matrix_El_C ( 3 , 2 ) = ElC ( 5 );
    matrix_El_C ( 3 , 3 ) = ElC ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em C %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto C
    matrix_Eg_C = R ( 1:3 , 1:3 ) * matrix_El_C * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em C
    EgC ( 1 ) = matrix_Eg_C ( 1 , 1 );
    EgC ( 2 ) = matrix_Eg_C ( 2 , 2 );
    EgC ( 3 ) = matrix_Eg_C ( 3 , 3 );
    EgC ( 4 ) = matrix_Eg_C ( 1 , 2 );
    EgC ( 5 ) = matrix_Eg_C ( 2 , 3 );
    EgC ( 6 ) = matrix_Eg_C ( 1 , 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O LOCAL EM D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��o Local no Ponto D
    matrix_El_D = zeros ( 3 , 3 );
    
    % Aloca��o dos Termos de Deforma��o Local em D -- Linha 1
    matrix_El_D ( 1 , 1 ) = ElD ( 1 );
    matrix_El_D ( 1 , 2 ) = ElD ( 4 );
    matrix_El_D ( 1 , 3 ) = ElD ( 6 );
    
    % Aloca��o dos Termos de Deforma��o Local em D -- Linha 2
    matrix_El_D ( 2 , 1 ) = ElD ( 4 );
    matrix_El_D ( 2 , 2 ) = ElD ( 2 );
    matrix_El_D ( 2 , 3 ) = ElD ( 5 );
    
    % Aloca��o dos Termos de Deforma��o Local em D -- Linha 3
    matrix_El_D ( 3 , 1 ) = ElD ( 6 );
    matrix_El_D ( 3 , 2 ) = ElD ( 5 );
    matrix_El_D ( 3 , 3 ) = ElD ( 3 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE DEFORMA��O GLOBAL em D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Matriz de Deforma��p Global no Ponto D
    matrix_Eg_D = R ( 1:3 , 1:3 ) * matrix_El_D * transpose ( R ( 1:3 , 1:3 ) );
    
    % Aloca��o no Vetor de Deforma��es Globais em D
    EgD ( 1 ) = matrix_Eg_D ( 1 , 1 );
    EgD ( 2 ) = matrix_Eg_D ( 2 , 2 );
    EgD ( 3 ) = matrix_Eg_D ( 3 , 3 );
    EgD ( 4 ) = matrix_Eg_D ( 1 , 2 );
    EgD ( 5 ) = matrix_Eg_D ( 2 , 3 );
    EgD ( 6 ) = matrix_Eg_D ( 1 , 3 );    
    
end

