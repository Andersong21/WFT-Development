%% Cria��o do Vetor de Deforma��es Locais do Elemento Beam2

%% INPUT
% Ba                - Matriz de Correla��o Deslocamento Deforma��o Axial do Elemento Beam2
% Bby               - Matriz de Correla��o Deslocamento Deforma��o de Flex�o YY do Elemento Beam2
% Bbz               - Matriz de Correla��o Deslocamento Deforma��o de Flex�o ZZ do Elemento Beam2
% Bsy               - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento YY do Elemento Beam2
% Bsz               - Matriz de Correla��o Deslocamento Deforma��o de Cisalhamento ZZ do Elemento Beam2
% Bt                - Matriz de Correla��o Deslocamento Deforma��o de Tor��o do Elemento Beam2
% Ul                - Vetor de Deslocamento Nodais Locais do Elemento
% b                 - Base do Elemento no Ponto de Coordenada Natural e
% h                 - Altura do Elemento no Ponto de Coordenada Natural e
% local             - Local de C�lculo das Deforma��es na Viga
%                   - [ C ] = Canto
%                   - [ E ] = Extremidade                    

%% OUTPUT
% ElA               - Vetor de Deforma��es Locais no Ponto A
% ElB               - Vetor de Deforma��es Locais no Ponto B
% ElC               - Vetor de Deforma��es Locais no Ponto C
% ElD               - Vetor de Deforma��es Locais no Ponto D

%% Declara��o da Fun��o de Cria��o Vetor de Deforma��es Locais do Elemento Beam2
function [ ElA , ElB , ElC , ElD ] = vector_El_beam2 ( Ba , Bby , Bbz , Bsy , Bsz , Bt , Ul , b , h , local )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % AXIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Axial
    Ula = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Axial
    Ula ( 1 , 1 ) = Ul ( 1  , 1 );
    Ula ( 2 , 1 ) = Ul ( 7  , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O YY %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o YY
    Uly = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o YY
    Uly ( 1 , 1 ) = Ul ( 3  , 1 );
    Uly ( 2 , 1 ) = Ul ( 5  , 1 );
    Uly ( 3 , 1 ) = Ul ( 9  , 1 );
    Uly ( 4 , 1 ) = Ul ( 11 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % FLEX�O ZZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Flex�o ZZ
    Ulz = zeros ( 4 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Flex�o ZZ
    Ulz ( 1 , 1 ) = Ul ( 2  , 1 );
    Ulz ( 2 , 1 ) = Ul ( 6  , 1 );
    Ulz ( 3 , 1 ) = Ul ( 8  , 1 );
    Ulz ( 4 , 1 ) = Ul ( 12 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETORES DE DESLOCAMENTO % TOR��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Vetor de Deslocamentos Tor��o
    Ult = zeros ( 2 , 1 );
    
    % Aloca��o do Vetor de Deslocamento Tor��o
    Ult ( 1 , 1 ) = Ul ( 4  , 1 );
    Ult ( 2 , 1 ) = Ul ( 10 , 1 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DEFORMA��ES CANTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��o Canto
    if ( strcmp ( local , 'C' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = + h / 2;
        zl = + b / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto A
        E_axial_A = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto A
        E_by_A = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto A
        E_sy_A = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto A
        E_bz_A = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto A
        E_sz_A = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto A
        E_t_A  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        ElA ( 1 ) = E_axial_A ( 1 ) + E_by_A ( 1 ) + E_bz_A ( 1 );
        ElA ( 2 ) = 0;
        ElA ( 3 ) = 0;
        ElA ( 4 ) = E_t_A  ( 1 );
        ElA ( 5 ) = E_sy_A ( 1 );
        ElA ( 6 ) = E_sz_A ( 1 );

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = - h / 2;
        zl = + b / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto B
        E_axial_B = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto B
        E_by_B = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto B
        E_sy_B = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto B
        E_bz_B = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto B
        E_sz_B = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto B
        E_t_B  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto B
        ElB ( 1 ) = E_axial_B ( 1 ) + E_by_B ( 1 ) + E_bz_B ( 1 );
        ElB ( 2 ) = 0;
        ElB ( 3 ) = 0;
        ElB ( 4 ) = E_t_B  ( 1 );
        ElB ( 5 ) = E_sy_B ( 1 );
        ElB ( 6 ) = E_sz_B ( 1 );

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - h / 2;
        zl = - b / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto C
        E_axial_C = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto C
        E_by_C = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto C
        E_sy_C = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto C
        E_bz_C = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto C
        E_sz_C = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto C
        E_t_C  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto C
        ElC ( 1 ) = E_axial_C ( 1 ) + E_by_C ( 1 ) + E_bz_C ( 1 );
        ElC ( 2 ) = 0;
        ElC ( 3 ) = 0;
        ElC ( 4 ) = E_t_C  ( 1 );
        ElC ( 5 ) = E_sy_C ( 1 );
        ElC ( 6 ) = E_sz_C ( 1 );

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = + h / 2;
        zl = - b / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto D
        E_axial_D = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto D
        E_by_D = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto D
        E_sy_D = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto D
        E_bz_D = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto D
        E_sz_D = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto D
        E_t_D  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto D
        ElD ( 1 ) = E_axial_D ( 1 ) + E_by_D ( 1 ) + E_bz_D ( 1 ) + E_sy_D ( 1 ) + E_sz_D ( 1 );
        ElD ( 2 ) = 0;
        ElD ( 3 ) = 0;
        ElD ( 4 ) = E_t_D  ( 1 );
        ElD ( 5 ) = E_sy_D ( 1 );
        ElD ( 6 ) = E_sz_D ( 1 );
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DEFORMA��ES EXTREMIDADE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��o Extremidade
    if ( strcmp ( local , 'E' ) == 1 )             
    
        %%%%%%%%%%%
        % PONTO A %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto A
        yl = + h / 2;
        zl = 0;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto A
        E_axial_A = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto A
        E_by_A = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto A
        E_sy_A = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto A
        E_bz_A = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto A
        E_sz_A = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto A
        E_t_A  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto A
        ElA ( 1 ) = E_axial_A ( 1 ) + E_by_A ( 1 ) + E_bz_A ( 1 );
        ElA ( 2 ) = 0;
        ElA ( 3 ) = 0;
        ElA ( 4 ) = E_t_A  ( 1 );
        ElA ( 5 ) = E_sy_A ( 1 );
        ElA ( 6 ) = E_sz_A ( 1 );

        %%%%%%%%%%%
        % PONTO B %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto B
        yl = 0;
        zl = + b / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto B
        E_axial_B = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto B
        E_by_B = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto B
        E_sy_B = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto B
        E_bz_B = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto B
        E_sz_B = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto B
        E_t_B  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto B
        ElB ( 1 ) = E_axial_B ( 1 ) + E_by_B ( 1 ) + E_bz_B ( 1 );
        ElB ( 2 ) = 0;
        ElB ( 3 ) = 0;
        ElB ( 4 ) = E_t_B  ( 1 );
        ElB ( 5 ) = E_sy_B ( 1 );
        ElB ( 6 ) = E_sz_B ( 1 );

        %%%%%%%%%%%
        % PONTO C %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto C
        yl = - h / 2;
        zl = 0;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto C
        E_axial_C = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto C
        E_by_C = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto C
        E_sy_C = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto C
        E_bz_C = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto C
        E_sz_C = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto C
        E_t_C  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto C
        ElC ( 1 ) = E_axial_C ( 1 ) + E_by_C ( 1 ) + E_bz_C ( 1 );
        ElC ( 2 ) = 0;
        ElC ( 3 ) = 0;
        ElC ( 4 ) = E_t_C  ( 1 );
        ElC ( 5 ) = E_sy_C ( 1 );
        ElC ( 6 ) = E_sz_C ( 1 );

        %%%%%%%%%%%
        % PONTO D %
        %%%%%%%%%%%

        % Defini��es das Coordenadas do Ponto D
        yl = 0;
        zl = - b / 2;

        % Determina��o do Vetor de Deforma��es Axiais do Ponto D
        E_axial_D = Ba * Ula;

        % Determina��o do Vetor de Deforma��es Flex�o YY do Ponto D
        E_by_D = - zl * ( Bby * Uly );
        
        % Determina��o do Vetor de Deforma��es Cisalhamento YY do Ponto D
        E_sy_D = ( Bsy * Uly );

        % Determina��o do Vetor de Deforma��es Flex�o ZZ do Ponto D
        E_bz_D = - yl * ( Bbz * Ulz );
       
        % Determina��o do Vetor de Deforma��es Cisalhamento ZZ do Ponto D
        E_sz_D = ( Bsz * Ulz );

        % Determina��o do Vetor de Deforma��es Tor��o do Ponto D
        E_t_D  = - ( sqrt ( yl^2 + zl^2 ) ) * ( Bt * Ult );

        % Vetor de Deforma��es Locais do Ponto D
        ElD ( 1 ) = E_axial_D ( 1 ) + E_by_D ( 1 ) + E_bz_D ( 1 );
        ElD ( 2 ) = 0;
        ElD ( 3 ) = 0;
        ElD ( 4 ) = E_t_D  ( 1 );
        ElD ( 5 ) = E_sy_D ( 1 );
        ElD ( 6 ) = E_sz_D ( 1 );
        
    end    
    
end

