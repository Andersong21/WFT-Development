%% Cria��o da Estrutura de Deforma��es e Tens�es do Elemento Beam2

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Elemento i

%% OUTPUT
% Elem_Strain       - Matriz de Deforma��es do Elemento i
% Elem_Stress       - Matriz de Tens�es do Elemento i

%% Declara��o da Fun��o de Cria��o da Estrutura de Tens�es do Elemento Beam2
function [ Elem_Strain , Elem_Stress ] = strain_stress_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Estrutura de Dados das Deforma��es do Elemento
    Elem_Strain = struct;
    
    % Inicializa��o da Estrutura de Dados das Tens�es do Elemento
    Elem_Stress = struct;
    
    % Retorno das Defini��es Iniciais da Propriedade
    [ b , h ] = get_section_param ( Elem_Param , Prop_Param , i );
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_beam2 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_beam2 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_beam2 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva do Elemento
    [ E , G ] = matrix_D_beam2 ( Mat_Param );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Globais do Elemento
    [ Ug ] = vector_Ug_beam2 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS NODAIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Locais do Elemento
    [ Ul ] = vector_Ul_beam2 ( R , Ug );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFORMA��ES NOS N�S DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos N�s do Elemento
    for j = 1:2
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % COORDENADAS NATURAIS DOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % N� 1
        if ( j == 1 )
           
            % Coordenada Natural r
            r = - 1;
            
        end
        
        % N� 2
        if ( j == 2 )
            
            % Coordenada Natural r
            r = + 1;
            
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO % AXIAL %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Ba ] = matrix_Ba_beam2 ( Cl );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO % FLEX�O %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bby , Bbz ] = matrix_Bb_beam2 ( E , G , b , h , Cl , r );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO % CISALHAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bsy , Bsz ] = matrix_Bs_beam2 ( E , G , b , h , Cl , r );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO % TOR��O %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
        [ Bt ] = matrix_Bt_beam2 ( Cl );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE DEFORMA��ES LOCAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Deforma��es Locais do Elemento
        [ ElA , ElB , ElC , ElD ] = vector_El_beam2 ( Ba , Bby , Bbz , Bsy , Bsz , Bt , Ul , b , h , 'C' );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE TENS�ES LOCAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Tens�es Locais do Elemento
        [ SlA , SlB , SlC , SlD ] = vector_Sl_beam2 ( Ba , Bby , Bbz , Bsy , Bsz , Bt , Ul , b , h , E , G , 'C' );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE DEFORMA��ES GLOBAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Deforma��es Globais do Elemento
        [ EgA , EgB , EgC , EgD ] = vector_Eg_beam2 ( ElA , ElB , ElC , ElD , R );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % VETOR DE TENS�ES GLOBAIS DO ELEMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Retorno dos Vetores de Tens�es Globais do Elemento
        [ SgA , SgB , SgC , SgD ] = vector_Sg_beam2 ( SlA , SlB , SlC , SlD , R );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ALOCA��O NA ESTRUTURA DE DADOS DOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Id do N�
        Elem_Strain ( j ).id = Elem_Param ( i ).node ( j );
        Elem_Stress ( j ).id = Elem_Param ( i ).node ( j );        
        
        % Varredura na Lista das Deforma��es Globais -- Pontos
        for k = 1:4
           
            % Varredura no Vetor de Deforma��es
            for l = 1:6
                
                % Ponto A
                if k == 1
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgA ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgA ( l );
                    
                    % Continuar
                    continue;
                    
                end
                
                % Ponto B
                if k == 2
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgB ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgB ( l );
                    
                    % Continuar
                    continue;
                    
                end
                
                % Ponto C
                if k == 3
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgC ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgC ( l );
                    
                    % Continuar
                    continue;
                    
                end
                
                % Ponto D
                if k == 4
                    
                    % Aloca��o na Estrutura de Dados da Deforma��o Elemento
                    Elem_Strain ( j ).point ( k ).strain ( l ) = EgD ( l );
                    
                    % Aloca��o na Estrutura de Dados da Tens�o do Elemento
                    Elem_Stress ( j ).point ( k ).stress ( l ) = SgD ( l );
                    
                    % Continuar
                    continue;
                    
                end

            end
            
        end
        
    end
    
end

