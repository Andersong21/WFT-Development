%% Cria��o da Matriz Jacobiana do Elemento Beam2

%% INPUT
% Cl                - Matriz de Coordenadas Nodais Locais do Elemento

%% OUTPUT
% J                 - Matriz Jacobiana do Elemento Beam2

%% Declara��o da Fun��o de Cria��o da Matriz Jacobiana do Elemento Beam2
function [ J ] = matrix_J_beam2 ( Cl )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COORDENADAS NODAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Coordenadas X locais do Elemento
    x1 = Cl ( 1 , 1 );
    x2 = Cl ( 2 , 1 );
    
    %%%%%%%%%%%%%
    % JACOBIANO %
    %%%%%%%%%%%%%
    
    % Determina��o do Jacobiano do Elemento
    J = ( - x1 / 2 ) + ( x2 / 2 );    
    
end

