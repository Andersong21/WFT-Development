%% Cria��o da Estrutura de Deforma��es e Tens�es do Elemento Quad4

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento i

%% OUTPUT
% Ei                - Vetor de Deforma��es do Elemento i
% Si                - Vetor de Tens�es do Elemento i

%% Declara��o da Fun��o de Cria��o da Estrutura de Deforma��es e Tens�es do Elemento Quad4
function [ Ei , Si ] = strain_stress_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_quad4 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_quad4 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_quad4 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz Constitutiva e Espessura do Elemento
    [ t , Dm , Db , Ds ] = matrix_D_quad4 ( Elem_Param , Mat_Param , Prop_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Globais do Elemento
    [ Ug ] = vector_Ug_quad4 ( Node_Param , Elem_Param , i );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS NODAIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos Locais do Elemento
    [ Ul ] = vector_Ul_quad4 ( R , Ug );
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COORDENADAS NATURAIS DOS N�S %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Coordenadas do Centro -- e
    e = 0;

    % Coordenadas do Centro -- n
    n = 0;

    %%%%%%%%%%%%%%%%%%%%
    % MATRIZ JACOBIANA %
    %%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz Jacobiana
    [ J ] = matrix_J_quad4 ( e , n , Cl );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
    [ Bm , Bb , Bs ] = matrix_B_quad4 ( e , n , J );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Deforma��es Locais do Elemento
    [ ElE , ElF , ElG ] = vector_El_quad4 ( Bm , Bb , Bs , Ul , t );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Tens�es Locais do Elemento
    [ SlE , SlF , SlG ] = vector_Sl_quad4 ( ElE , ElF , ElG , Dm , Db , Ds , t ); 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Deforma��es Globais do Elemento
    [ EgE , EgF , EgG ] = vector_Eg_quad4 ( ElE , ElF , ElG , R );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE TENS�ES GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Tens�es Globais do Elemento
    [ SgE , SgF , SgG ] = vector_Sg_quad4 ( SlE , SlF , SlG , R );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O NA ESTRUTURA DE DADOS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Deforma��es em Branco
    Empty = zeros ( 1 , 6 );
    
    % Aloca��o na Estrutura de Deforma��es do Elemento
    Ei = [ EgE , EgF , EgG , Empty ];   
    
    % Aloca��o na Estrutura de Tens�es do Elemento
    Si = [ SgE , SgF , SgG , Empty ];     

end

