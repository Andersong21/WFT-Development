%% Cria��o da Matriz Constutitva do Elemento Quad4

%% INPUT
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento i na Estrutura de Dados

%% OUTPUT
% t                 - Espessura do Elemento
% Dm                - Matriz Constitutiva de Membrana do Elemento Quad4
% Db                - Matriz Constitutiva de Flex�o do Elemento Quad4
% Ds                - Matriz Constitutiva de Cisalhamento do Elemento Quad4

%% Declara��o da Fun��o de Cria��o da Matriz Constutitva do Elemento Quad4
function [ t , Dm , Db , Ds ] = matrix_D_quad4 ( Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%
    % PAR�METROS %
    %%%%%%%%%%%%%%
    
    % Id da Propriedade do Elemento
    Idp = Elem_Param ( i ).prop_id;
    
    % Id do Material
    Idm = Mat_Param ( 1 ).id;
    
    % Espessura do Elemento
    t = Prop_Param ( Idp ).thick;
    
    % M�dulo de Elasticidade
    E = Mat_Param ( Idm ).E;
    
    % Coeficiente de Poisson
    v = Mat_Param ( Idm ).poisson;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz Constitutiva de Membrana
    Dm = zeros ( 3 , 3 );
    
    % Termo Fixo
    D1 = E / ( 1 - ( v * v ) );
    
    % Aloca��o dos Termos na Matriz Constitutiva de Membrana
    Dm ( 1 , 1 ) = D1;
    Dm ( 1 , 2 ) = D1 * v;
    Dm ( 2 , 1 ) = D1 * v;
    Dm ( 2 , 2 ) = D1;
    Dm ( 3 , 3 ) = D1 * 0.5 * ( 1 - v );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz Constitutiva de Flex�o
    Db = zeros ( 3 , 3 );
    
    % Termo Fixo
    D2 = ( E * t * t * t ) / ( 12 * ( ( 1 - ( v * v ) ) ) );
    
    % Aloca��o dos Termos na Matriz Constitutiva de Flex�o
    Db ( 1 , 1 ) = D2;
    Db ( 1 , 2 ) = D2 * v;
    Db ( 2 , 2 ) = D2;
    Db ( 2 , 1 ) = D2 * v;
    Db ( 3 , 3 ) = D2 * 0.5 * ( 1 - v );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ CONSTITUTIVA DE CISALHAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz Constitutiva de Cisalhamento
    Ds = zeros ( 2 , 2 );
    
    % Termo Fixo
    D3 = ( ( 5 / 6 ) * E * t ) / ( ( 2 * ( 1 + v ) ) );
    
    % Aloca��o dos Termos na Matriz Constitutiva de Cisalhamento
    Ds ( 1 , 1 ) = D3;
    Ds ( 2 , 2 ) = D3;

end

