%% Cria��o da Matriz de Massa do Elemento Quad4 no Ponto da Quadratura de Gauss

%% INPUT
% t                 - Espessura do Elemento
% J                 - Matriz Jacobiana do Elemento
% Hm                - Matriz de Fun��es de Forma de Membrana do Elemento Quad4
% Hb                - Matriz de Fun��es de Forma de Flex�o do Elemento Quad4
% rho               - Densidade do Elemento Quad4
% I                 - Matriz de Densidade de Placa do Elemento Quad4

%% OUTPUT
% M1                - Matriz de Massa do Elemento Quad4 no Ponto da Quadratura de Gauss

%% Declara��o da Fun��o de Cria��o da Matriz de Massa do Elemento Quad4 no Ponto da Quadratura de Gauss
function [ M1 ] = matrix_M_QG_quad4 ( t , J , Hm , Hb , rho , I )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa de Membrana
    Mm = ( t * rho ) * ( transpose ( Hm ) * Hm ) * det ( J );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa de Flex�o
    Mb = ( transpose ( Hb ) * I * Hb ) * det ( J );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO NO PONTO DA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local
    M1 = zeros ( 24 , 24 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA DE MEMBRANA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 1
    M1 ( 1  , 1  ) = Mm ( 1 , 1 );
    M1 ( 1  , 2  ) = Mm ( 1 , 2 );
    M1 ( 1  , 7  ) = Mm ( 1 , 3 );
    M1 ( 1  , 8  ) = Mm ( 1 , 4 );
    M1 ( 1  , 13 ) = Mm ( 1 , 5 );
    M1 ( 1  , 14 ) = Mm ( 1 , 6 );
    M1 ( 1  , 19 ) = Mm ( 1 , 7 );
    M1 ( 1  , 20 ) = Mm ( 1 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 2
    M1 ( 2  , 1  ) = Mm ( 2 , 1 );
    M1 ( 2  , 2  ) = Mm ( 2 , 2 );
    M1 ( 2  , 7  ) = Mm ( 2 , 3 );
    M1 ( 2  , 8  ) = Mm ( 2 , 4 );
    M1 ( 2  , 13 ) = Mm ( 2 , 5 );
    M1 ( 2  , 14 ) = Mm ( 2 , 6 );
    M1 ( 2  , 19 ) = Mm ( 2 , 7 );
    M1 ( 2  , 20 ) = Mm ( 2 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 3
    M1 ( 7  , 1  ) = Mm ( 3 , 1 );
    M1 ( 7  , 2  ) = Mm ( 3 , 2 );
    M1 ( 7  , 7  ) = Mm ( 3 , 3 );
    M1 ( 7  , 8  ) = Mm ( 3 , 4 );
    M1 ( 7  , 13 ) = Mm ( 3 , 5 );
    M1 ( 7  , 14 ) = Mm ( 3 , 6 );
    M1 ( 7  , 19 ) = Mm ( 3 , 7 );
    M1 ( 7  , 20 ) = Mm ( 3 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 4
    M1 ( 8  , 1  ) = Mm ( 4 , 1 );
    M1 ( 8  , 2  ) = Mm ( 4 , 2 );
    M1 ( 8  , 7  ) = Mm ( 4 , 3 );
    M1 ( 8  , 8  ) = Mm ( 4 , 4 );
    M1 ( 8  , 13 ) = Mm ( 4 , 5 );
    M1 ( 8  , 14 ) = Mm ( 4 , 6 );
    M1 ( 8  , 19 ) = Mm ( 4 , 7 );
    M1 ( 8  , 20 ) = Mm ( 4 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 5
    M1 ( 13 , 1  ) = Mm ( 5 , 1 );
    M1 ( 13 , 2  ) = Mm ( 5 , 2 );
    M1 ( 13 , 7  ) = Mm ( 5 , 3 );
    M1 ( 13 , 8  ) = Mm ( 5 , 4 );
    M1 ( 13 , 13 ) = Mm ( 5 , 5 );
    M1 ( 13 , 14 ) = Mm ( 5 , 6 );
    M1 ( 13 , 19 ) = Mm ( 5 , 7 );
    M1 ( 13 , 20 ) = Mm ( 5 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 6
    M1 ( 14 , 1  ) = Mm ( 6 , 1 );
    M1 ( 14 , 2  ) = Mm ( 6 , 2 );
    M1 ( 14 , 7  ) = Mm ( 6 , 3 );
    M1 ( 14 , 8  ) = Mm ( 6 , 4 );
    M1 ( 14 , 13 ) = Mm ( 6 , 5 );
    M1 ( 14 , 14 ) = Mm ( 6 , 6 );
    M1 ( 14 , 19 ) = Mm ( 6 , 7 );
    M1 ( 14 , 20 ) = Mm ( 6 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 7
    M1 ( 19 , 1  ) = Mm ( 7 , 1 );
    M1 ( 19 , 2  ) = Mm ( 7 , 2 );
    M1 ( 19 , 7  ) = Mm ( 7 , 3 );
    M1 ( 19 , 8  ) = Mm ( 7 , 4 );
    M1 ( 19 , 13 ) = Mm ( 7 , 5 );
    M1 ( 19 , 14 ) = Mm ( 7 , 6 );
    M1 ( 19 , 19 ) = Mm ( 7 , 7 );
    M1 ( 19 , 20 ) = Mm ( 7 , 8 );
    
    % Aloca��o dos Termos da Matriz de Massa de Membrana -- LINHA 8
    M1 ( 20 , 1  ) = Mm ( 8 , 1 );
    M1 ( 20 , 2  ) = Mm ( 8 , 2 );
    M1 ( 20 , 7  ) = Mm ( 8 , 3 );
    M1 ( 20 , 8  ) = Mm ( 8 , 4 );
    M1 ( 20 , 13 ) = Mm ( 8 , 5 );
    M1 ( 20 , 14 ) = Mm ( 8 , 6 );
    M1 ( 20 , 19 ) = Mm ( 8 , 7 );
    M1 ( 20 , 20 ) = Mm ( 8 , 8 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MATRIZ DE MASSA DE FLEX�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 1
    M1 ( 3  , 3  ) = Mb ( 1  , 1  );
    M1 ( 3  , 4  ) = Mb ( 1  , 2  );
    M1 ( 3  , 5  ) = Mb ( 1  , 3  );
    M1 ( 3  , 9  ) = Mb ( 1  , 4  );
    M1 ( 3  , 10 ) = Mb ( 1  , 5  );
    M1 ( 3  , 11 ) = Mb ( 1  , 6  );
    M1 ( 3  , 15 ) = Mb ( 1  , 7  );
    M1 ( 3  , 16 ) = Mb ( 1  , 8  );
    M1 ( 3  , 17 ) = Mb ( 1  , 9  );
    M1 ( 3  , 21 ) = Mb ( 1  , 10 );
    M1 ( 3  , 22 ) = Mb ( 1  , 11 );
    M1 ( 3  , 23 ) = Mb ( 1  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 2
    M1 ( 4  , 3  ) = Mb ( 2  , 1  );
    M1 ( 4  , 4  ) = Mb ( 2  , 2  );
    M1 ( 4  , 5  ) = Mb ( 2  , 3  );
    M1 ( 4  , 9  ) = Mb ( 2  , 4  );
    M1 ( 4  , 10 ) = Mb ( 2  , 5  );
    M1 ( 4  , 11 ) = Mb ( 2  , 6  );
    M1 ( 4  , 15 ) = Mb ( 2  , 7  );
    M1 ( 4  , 16 ) = Mb ( 2  , 8  );
    M1 ( 4  , 17 ) = Mb ( 2  , 9  );
    M1 ( 4  , 21 ) = Mb ( 2  , 10 );
    M1 ( 4  , 22 ) = Mb ( 2  , 11 );
    M1 ( 4  , 23 ) = Mb ( 2  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 3
    M1 ( 5  , 3  ) = Mb ( 3  , 1  );
    M1 ( 5  , 4  ) = Mb ( 3  , 2  );
    M1 ( 5  , 5  ) = Mb ( 3  , 3  );
    M1 ( 5  , 9  ) = Mb ( 3  , 4  );
    M1 ( 5  , 10 ) = Mb ( 3  , 5  );
    M1 ( 5  , 11 ) = Mb ( 3  , 6  );
    M1 ( 5  , 15 ) = Mb ( 3  , 7  );
    M1 ( 5  , 16 ) = Mb ( 3  , 8  );
    M1 ( 5  , 17 ) = Mb ( 3  , 9  );
    M1 ( 5  , 21 ) = Mb ( 3  , 10 );
    M1 ( 5  , 22 ) = Mb ( 3  , 11 );
    M1 ( 5  , 23 ) = Mb ( 3  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 4
    M1 ( 9  , 3  ) = Mb ( 4  , 1  );
    M1 ( 9  , 4  ) = Mb ( 4  , 2  );
    M1 ( 9  , 5  ) = Mb ( 4  , 3  );
    M1 ( 9  , 9  ) = Mb ( 4  , 4  );
    M1 ( 9  , 10 ) = Mb ( 4  , 5  );
    M1 ( 9  , 11 ) = Mb ( 4  , 6  );
    M1 ( 9  , 15 ) = Mb ( 4  , 7  );
    M1 ( 9  , 16 ) = Mb ( 4  , 8  );
    M1 ( 9  , 17 ) = Mb ( 4  , 9  );
    M1 ( 9  , 21 ) = Mb ( 4  , 10 );
    M1 ( 9  , 22 ) = Mb ( 4  , 11 );
    M1 ( 9  , 23 ) = Mb ( 4  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 5
    M1 ( 10 , 3  ) = Mb ( 5  , 1  );
    M1 ( 10 , 4  ) = Mb ( 5  , 2  );
    M1 ( 10 , 5  ) = Mb ( 5  , 3  );
    M1 ( 10 , 9  ) = Mb ( 5  , 4  );
    M1 ( 10 , 10 ) = Mb ( 5  , 5  );
    M1 ( 10 , 11 ) = Mb ( 5  , 6  );
    M1 ( 10 , 15 ) = Mb ( 5  , 7  );
    M1 ( 10 , 16 ) = Mb ( 5  , 8  );
    M1 ( 10 , 17 ) = Mb ( 5  , 9  );
    M1 ( 10 , 21 ) = Mb ( 5  , 10 );
    M1 ( 10 , 22 ) = Mb ( 5  , 11 );
    M1 ( 10 , 23 ) = Mb ( 5  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 6
    M1 ( 11 , 3  ) = Mb ( 6  , 1  );
    M1 ( 11 , 4  ) = Mb ( 6  , 2  );
    M1 ( 11 , 5  ) = Mb ( 6  , 3  );
    M1 ( 11 , 9  ) = Mb ( 6  , 4  );
    M1 ( 11 , 10 ) = Mb ( 6  , 5  );
    M1 ( 11 , 11 ) = Mb ( 6  , 6  );
    M1 ( 11 , 15 ) = Mb ( 6  , 7  );
    M1 ( 11 , 16 ) = Mb ( 6  , 8  );
    M1 ( 11 , 17 ) = Mb ( 6  , 9  );
    M1 ( 11 , 21 ) = Mb ( 6  , 10 );
    M1 ( 11 , 22 ) = Mb ( 6  , 11 );
    M1 ( 11 , 23 ) = Mb ( 6  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 7
    M1 ( 15 , 3  ) = Mb ( 7  , 1  );
    M1 ( 15 , 4  ) = Mb ( 7  , 2  );
    M1 ( 15 , 5  ) = Mb ( 7  , 3  );
    M1 ( 15 , 9  ) = Mb ( 7  , 4  );
    M1 ( 15 , 10 ) = Mb ( 7  , 5  );
    M1 ( 15 , 11 ) = Mb ( 7  , 6  );
    M1 ( 15 , 15 ) = Mb ( 7  , 7  );
    M1 ( 15 , 16 ) = Mb ( 7  , 8  );
    M1 ( 15 , 17 ) = Mb ( 7  , 9  );
    M1 ( 15 , 21 ) = Mb ( 7  , 10 );
    M1 ( 15 , 22 ) = Mb ( 7  , 11 );
    M1 ( 15 , 23 ) = Mb ( 7  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 8
    M1 ( 16 , 3  ) = Mb ( 8  , 1  );
    M1 ( 16 , 4  ) = Mb ( 8  , 2  );
    M1 ( 16 , 5  ) = Mb ( 8  , 3  );
    M1 ( 16 , 9  ) = Mb ( 8  , 4  );
    M1 ( 16 , 10 ) = Mb ( 8  , 5  );
    M1 ( 16 , 11 ) = Mb ( 8  , 6  );
    M1 ( 16 , 15 ) = Mb ( 8  , 7  );
    M1 ( 16 , 16 ) = Mb ( 8  , 8  );
    M1 ( 16 , 17 ) = Mb ( 8  , 9  );
    M1 ( 16 , 21 ) = Mb ( 8  , 10 );
    M1 ( 16 , 22 ) = Mb ( 8  , 11 );
    M1 ( 16 , 23 ) = Mb ( 8  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 9
    M1 ( 17 , 3  ) = Mb ( 9  , 1  );
    M1 ( 17 , 4  ) = Mb ( 9  , 2  );
    M1 ( 17 , 5  ) = Mb ( 9  , 3  );
    M1 ( 17 , 9  ) = Mb ( 9  , 4  );
    M1 ( 17 , 10 ) = Mb ( 9  , 5  );
    M1 ( 17 , 11 ) = Mb ( 9  , 6  );
    M1 ( 17 , 15 ) = Mb ( 9  , 7  );
    M1 ( 17 , 16 ) = Mb ( 9  , 8  );
    M1 ( 17 , 17 ) = Mb ( 9  , 9  );
    M1 ( 17 , 21 ) = Mb ( 9  , 10 );
    M1 ( 17 , 22 ) = Mb ( 9  , 11 );
    M1 ( 17 , 23 ) = Mb ( 9  , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 10
    M1 ( 21 , 3  ) = Mb ( 10 , 1  );
    M1 ( 21 , 4  ) = Mb ( 10 , 2  );
    M1 ( 21 , 5  ) = Mb ( 10 , 3  );
    M1 ( 21 , 9  ) = Mb ( 10 , 4  );
    M1 ( 21 , 10 ) = Mb ( 10 , 5  );
    M1 ( 21 , 11 ) = Mb ( 10 , 6  );
    M1 ( 21 , 15 ) = Mb ( 10 , 7  );
    M1 ( 21 , 16 ) = Mb ( 10 , 8  );
    M1 ( 21 , 17 ) = Mb ( 10 , 9  );
    M1 ( 21 , 21 ) = Mb ( 10 , 10 );
    M1 ( 21 , 22 ) = Mb ( 10 , 11 );
    M1 ( 21 , 23 ) = Mb ( 10 , 12 );

    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 11
    M1 ( 22 , 3  ) = Mb ( 11 , 1  );
    M1 ( 22 , 4  ) = Mb ( 11 , 2  );
    M1 ( 22 , 5  ) = Mb ( 11 , 3  );
    M1 ( 22 , 9  ) = Mb ( 11 , 4  );
    M1 ( 22 , 10 ) = Mb ( 11 , 5  );
    M1 ( 22 , 11 ) = Mb ( 11 , 6  );
    M1 ( 22 , 15 ) = Mb ( 11 , 7  );
    M1 ( 22 , 16 ) = Mb ( 11 , 8  );
    M1 ( 22 , 17 ) = Mb ( 11 , 9  );
    M1 ( 22 , 21 ) = Mb ( 11 , 10 );
    M1 ( 22 , 22 ) = Mb ( 11 , 11 );
    M1 ( 22 , 23 ) = Mb ( 11 , 12 );
    
    % Aloca��o dos Termos da Matriz de Massa de Flex�o -- LINHA 12
    M1 ( 23 , 3  ) = Mb ( 12 , 1  );
    M1 ( 23 , 4  ) = Mb ( 12 , 2  );
    M1 ( 23 , 5  ) = Mb ( 12 , 3  );
    M1 ( 23 , 9  ) = Mb ( 12 , 4  );
    M1 ( 23 , 10 ) = Mb ( 12 , 5  );
    M1 ( 23 , 11 ) = Mb ( 12 , 6  );
    M1 ( 23 , 15 ) = Mb ( 12 , 7  );
    M1 ( 23 , 16 ) = Mb ( 12 , 8  );
    M1 ( 23 , 17 ) = Mb ( 12 , 9  );
    M1 ( 23 , 21 ) = Mb ( 12 , 10 );
    M1 ( 23 , 22 ) = Mb ( 12 , 11 );
    M1 ( 23 , 23 ) = Mb ( 12 , 12 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % TERMOS DA MASSA DE ROTA��O PERPENDICULAR A PLACA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % M�ximo Valor de Massa da Matriz do Elemento
    Mmax = max ( M1 ( : ) );
    
    % Massa de Rota��o Perpendicular a Placa
    Mrot = Mmax * 1000;
    
    % Aloca��o da Massa de Rota��o Perpendicular a Placa na Matriz
    M1 ( 6  , 6  ) = Mrot;
    M1 ( 12 , 12 ) = Mrot;
    M1 ( 18 , 18 ) = Mrot;
    M1 ( 24 , 24 ) = Mrot;

end

