%% Cria��o da Matriz de Massa do Elemento Quad4

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% i                 - Elemento i

%% OUTPUT
% Mi                - Termo i da Matriz de Massa Global
% Mj                - Termo j da Matriz de mASSA Global
% Mv                - Valor ( i , j ) da Matriz de Massa Global

%% Declara��o da Fun��o de Cria��o da Matriz de Massa do Elemento
function [ Mi , Mj , Mv ] = matrix_M_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE PESOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Pesos na Quadratura de Gauss
    [ WE ] = matrix_WE_quad4 ();
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DOS PONTOS NA QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz dos Pontos na Quadratura de Gauss
    [ PO ] = matrix_PO_quad4 ();

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_quad4 ( Node_Param , Elem_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_quad4 ( Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_quad4 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DENSIDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Densidade e Espessura do Elemento
    [ t , rho , I ] = matrix_P_quad4 ( Elem_Param , Mat_Param , Prop_Param , i );
    
    %%%%%%%%%%%%%%%%%%%%%%%
    % QUADRATURA DE GAUSS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Massa Local Final
    Ml = zeros ( 24 , 24 );
    
    % Varredura nos Pontos e da Quadratura de Gauss
    for j = 1:2
        
        % Varredura nos Pontos n da Quadratura de Gauss
        for k = 1:2
            
            % Ponto na Quadratura -- e
            e = PO ( j , 1 );
            
            % Ponto na Quadratura -- n
            n = PO ( k , 1 );
            
            %%%%%%%%%%%%%%%%%%%%
            % MATRIZ JACOBIANA %
            %%%%%%%%%%%%%%%%%%%%
            
            % Retorno da Matriz Jacobiana
            [ J ] = matrix_J_quad4 ( e , n , Cl );            
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE Fun��es de Forma %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Retorno da Matriz de Fun��es de Forma
            [ Hm , Hb ] = matrix_H_quad4 ( e , n );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE MASSA DO ELEMENTO % QUADRATURA DE GAUSS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Retorno da Matriz de Massa no Ponto de Integra��o
            [ M1 ] = matrix_M_QG_quad4 ( t , J , Hm , Hb , rho , I );

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % MATRIZ DE MASSA DO ELEMENTO % LOCAL %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Matriz de Massa no Ponto de Integra��o
            Ml = Ml + ( WE ( j ) * WE ( k ) * M1 );        
            
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO % GLOBAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Matriz de Massa Global do Elemento
    Mg = sparse ( R * Ml * transpose ( R ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE GRAUS DE LIBERDADE DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Contador de Graus de Liberdade do Elemento
    Ndof = 1;
    
    % Inicializa��o do Vetor de Graus de Liberdade
    DOF = zeros ( 24 , 1 );
    
    % Varredura nos N�s do Elemento
    for j = 1:length( Elem_Param ( i ).node )
       
        % Id do N�
        Idn = Elem_Param ( i ).node ( j );
        
        % Varredura nos Graus de Liberdade dos N�s do Elemento
        for k = 1:length ( Node_Param ( Idn ).dof )            
            
            % Aloca��o no Vetor de Graus de Liberdade
            DOF ( Ndof ) = Node_Param ( Idn ).dof ( k );
            
            % Incremento na Contagem de Graus de Liberdade
            Ndof = Ndof + 1;
            
        end         
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE MASSA DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Quantidade de Termos N�o Nulos na Matriz
    Nn = nnz ( Mg );
    
    % Defini��o das Posi��es e Valores da Matriz
    [ pi , pj , pv ] = find ( Mg );
    
    % Inicializa��o do Contador
    cont = 1;
    
    % Aloca��o na Matriz de Massa Global do Problema
    for j = 1:Nn
        
        % Posi��o a
        a = pi ( j );
        
        % Posi��o b
        b = pj ( j );        
        
        % Verifica��o se o Grau de Liberdade � nulo
        if ( DOF ( a ) == 0 )
            
            % Continuar
            continue;
            
        else     
            
            % Verifica��o se o Grau de Liberdade � nulo
            if ( DOF ( b ) == 0 )

                % Continuar
                continue;

            else

                % Aloca��o dos Termos da Matriz na Posi��o Global
                Mi ( cont ) = DOF ( a );
                Mj ( cont ) = DOF ( b );
                Mv ( cont ) = pv ( j );
                
                % Atualiza�ao do Contador
                cont = cont + 1;
                
            end
            
        end
        
    end
    
end

