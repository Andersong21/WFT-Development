%% Fun��o de Escrita dos Deslocamentos dos N�s

%% INPUT
% Node_Param   - Estrutura dos Par�metros dos N�s Vazios Desloc

%% Declara��o da Fun��o de Escrita dos Deslocamentos dos N�s
function write_disp ( Node_Param )

    % Quantidade de N�s
    Nnodes = max ( arrayfun ( @(struct)max(struct(:).id ) , Node_Param ) );
    
    % Abertura do Arquivo -- Deslocamento X    
    fid1 = fopen('dispX.csv', 'w');
    
    % Abertura do Arquivo -- Deslocamento Y    
    fid2 = fopen('dispY.csv', 'w');
    
    % Abertura do Arquivo -- Deslocamento Y    
    fid3 = fopen('dispZ.csv', 'w');
    
    % Abertura do Arquivo -- Deslocamento Total
    fid4 = fopen('disp.csv' , 'w');
    
    % Varredura nos N�s
    for i = 1:Nnodes
       
        % Escrita do Node
        string = 'Node ';
        
        % Transforma��o do Id em string
        id_string = int2str ( Node_Param ( i ).id );
        
        % String do Node
        Id_Nodes = [ string , id_string ];
        
        % Escrita dos Deslocamentos em X
        fprintf ( fid1 , '%s,%2.6f\n' , Id_Nodes , Node_Param ( i ).disp ( 1 ) ); 
        
        % Escrita dos Deslocamentos em Y
        fprintf ( fid2 , '%s,%2.6f\n' , Id_Nodes , Node_Param ( i ).disp ( 2 ) );
        
        % Escrita dos Deslocamentos em Z
        fprintf ( fid3 , '%s,%2.6f\n' , Id_Nodes , Node_Param ( i ).disp ( 3 ) );        
                
        % Escrita dos Deslocamentos
        fprintf ( fid4 , '%s,%2.6f\n' , Id_Nodes , Node_Param ( i ).max_disp );
        
    end
    
    % Fechar Arquivo
    fclose ( 'all' );
    
end