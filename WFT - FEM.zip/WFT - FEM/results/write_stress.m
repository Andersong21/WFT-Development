%% Fun��o de Escrita das Tens�es nos N�s

%% INPUT
% Node_Param   - Estrutura dos Par�metros dos N�s
% Elem_Param   - Estrutura dos Par�metros dos Elementos

%% Declara��o da Fun��o de Escrita das Tens�es nos Elementos
function write_stress ( Node_Param , Elem_Param )

    % Quantidade de Elementos
    Nelem = max ( arrayfun ( @(struct)max(struct(:).id ) , Elem_Param ) );
    
    % Quantidade de N�s
    Nnode = max ( arrayfun ( @(struct)max(struct(:).id ) , Node_Param ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA TENS�O VON MISES % ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Abertura do Arquivo -- Tens�o von Mises  
    fid6 = fopen('stressVM_elem.csv', 'w');    
   
    % Varredura nos Elementos
    for i = 1:Nelem
       
        % Escrita do Element
        string = 'Element ';
        
        % Transforma��o do Id em string
        id_string = int2str ( Elem_Param ( i ).id );
        
        % String do Elemento
        Id_Elems = [ string , id_string ];
        
        % Escrita da Tens�o von Mises
        fprintf ( fid6 , '%s,%2.6f\n' , Id_Elems , Elem_Param ( i ).max_stress );         
        
    end
    
    % Fechar Arquivo
    fclose ( 'all' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA TENS�O VON MISES % N� %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Abertura do Arquivo -- Tens�o von Mises  
    fid7 = fopen('stressVM_node.csv', 'w');    
   
    % Varredura nos N�s
    for i = 1:Nnode
       
        % Escrita do Node
        string = 'Node ';
        
        % Transforma��o do Id em string
        id_string = int2str ( Node_Param ( i ).id );
        
        % String do N�
        Id_Nodes = [ string , id_string ];
        
        % Escrita da Tens�o von Mises
        fprintf ( fid7 , '%s,%2.6f\n' , Id_Nodes , Node_Param ( i ).max_stress );         
        
    end
    
    % Fechar Arquivo
    fclose ( 'all' );
    
end