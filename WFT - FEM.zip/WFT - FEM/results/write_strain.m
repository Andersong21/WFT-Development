%% Fun��o de Escrita das Deforma��es nos N�s

%% INPUT
% Node_Param   - Estrutura dos Par�metros dos N�s
% Elem_Param   - Estrutura dos Par�metros dos Elementos

%% Declara��o da Fun��o de Escrita das Deforma��es nos Elementos
function write_strain ( Node_Param , Elem_Param )

    % Quantidade de Elementos
    Nelem = max ( arrayfun ( @(struct)max(struct(:).id ) , Elem_Param ) );
    
    % Quantidade de N�s
    Nnode = max ( arrayfun ( @(struct)max(struct(:).id ) , Node_Param ) );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DEFORMA��O VON MISES % ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Abertura do Arquivo -- Deforma��o von Mises  
    fid5 = fopen('strainVM_elem.csv', 'w');    
   
    % Varredura nos Elementos
    for i = 1:Nelem
       
        % Escrita do Elemento
        string = 'Element ';
        
        % Transforma��o do Id em string
        id_string = int2str ( Elem_Param ( i ).id );
        
        % String do Element
        Id_Elems = [ string , id_string ];
        
        % Escrita da Deforma��o von Mises
        fprintf ( fid5 , '%s,%2.6f\n' , Id_Elems , Elem_Param ( i ).max_strain );         
        
    end
    
    % Fechar Arquivo
    fclose ( 'all' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DEFORMA��O VON MISES % N� %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Abertura do Arquivo -- Deforma��o von Mises  
    fid6 = fopen('strainVM_node.csv', 'w');    
   
    % Varredura nos N�s
    for i = 1:Nnode
       
        % Escrita do N�
        string = 'Node ';
        
        % Transforma��o do Id em string
        id_string = int2str ( Node_Param ( i ).id );
        
        % String do Node
        Id_Nodes = [ string , id_string ];
        
        % Escrita da Deforma��o von Mises
        fprintf ( fid6 , '%s,%2.6f\n' , Id_Nodes , Node_Param ( i ).max_strain );         
        
    end
    
    % Fechar Arquivo
    fclose ( 'all' );
    
end