%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROTINA PARA DEFINI��O DO PAR�METRO Fc %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Limpeza das Vari�veis
clear all;

% Fechar todas as janelas
close all;

% Limpeza das Entrada
clc;

% Inicializa��o do Timer
tic;

% Formatar Sa�da
format short;

% Verifica��o das licen�as existentes
versions = ver;

% Verifica��o da Licen�a Parallel Computing Toolbox
parallel = any ( strcmp ( 'Parallel Computing Toolbox' , { versions.Name } ) );

% Defini��o do Processamento Paralelo
if ( parallel == 1 )
    
    % Defini��o do Multicore    
    p = gcp('nocreate');

    % Processadores n�o Dispon�veis
    if isempty( p )

        % N�mero de Processadores
        multicore = 1;

    else

        % N�mero de Processadores
        multicore = p.NumWorkers;

    end
    
else
    
    % N�mero de Processadores
    multicore = 1;
    
end    

%% ESTRUTURA DO PROBLEMA

% Vari�veis
% x ( 1  ) - Vari�vel b1      - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1      - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2      - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2      - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L       - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf      - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t       - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d       - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r       - Raio do Centro da C�lula de Carga    - [ mm ]

% Quantidade de Amostras
Ns        = input ('Entre a quantidade de amostras:');

% Fator de Correla��o
FC        = input ('Entre o fator de correla��o:');

% Erro Admiss�vel
max_error = input ('Ente o erro admiss�vel:');

% Erro Admiss�vel
Nmax      = input ('Ente o tamanho m�ximo de refino da malha:');

%%%%%%%%%%%%%%%%%
% INICIALIZA��O %
%%%%%%%%%%%%%%%%%

% Inicializa��o do Di�rio
diary ( strcat ( 'Define_Fc' , '.out' ) );

% Lower Bound
LB       = [ 10 , 10 , 10 , 10 , 41 , 41 , 0.5 , 1.5 , 30 ];

% Upper Bound
UB       = [ 40 , 40 , 40 , 40 , 52 , 94 , 8.0 , 8.0 , 32 ];

% Inicializa��o dos Pontos Iniciais
x0_points   = zeros ( length ( LB ) , Ns );

% Inicializa��o dos Deslocamentos dos Pontos
disp_points = zeros ( Nmax , Ns );

% Inicializa��o das Tens�es dos Pontos
stress_points = zeros ( Nmax , Ns );

% Inicializa��o dos Graus de Liberdade nos Pontos
dof_points = zeros ( Nmax , Ns );

% Inicializa��o dos Erros na Converg�ncia dos Pontos
error_points = zeros ( Nmax , Ns );

% Inicializa��o do Timer
tic;

%%%%%%%%%%%%%%%%%%%%
% PONTOS DE ESTUDO %
%%%%%%%%%%%%%%%%%%%%

% Retorno dos Pontos de Estudo 
[ xn ] = get_starting_point4 ( Ns , LB , UB );

% Varredura nos Pontos de Estudo
for i = 1:Ns
    
    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Di�rio
    diary ( strcat ( 'define_Fc_' , int2str ( i ) , '.out' ) );    

    % Escrita do Ponto de Estudo
    fprintf( 'Point %d :\n\n' , i );
    
    % Ponto de Estudo
    x0 = xn ( i , 1:end );
    
    % Aloca��o do Ponto de Estudo
    x0_points ( 1:end , i ) = x0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CRIT�RIO DE CONVERG�NCIA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%    

    % Erro Inicial
    error = 1.0;
    
    % Deslocamento da Itera��o
    Dnew = 0;
    
    % Deslocamento da Itera��o Anterior
    Dold = 0;
    
    % Tens�o da Itera��o
    Snew = 0;
    
    % Tens�o da Itera��o Anterior
    Sold = 0;
    
    % Aloca��o do Vetor de M�ximos Deslocamentos
    maxD   = zeros ( Nmax , 1 );
    
    % Aloca��o do Vetor de M�ximas Tens�es
    maxS   = zeros ( Nmax , 1 );
    
    % Aloca��o do Vetor de Graus de Liberdade
    dofs   = zeros ( Nmax , 1 );
    
    % Aloca��o do Vetor de Erros
    errors = zeros ( Nmax , 1 );
        
    % Inicialia��o do Par�metro de Malha
    N = 1;
    
    % Crit�rio de Converg�ncia
    while ( error > max_error && N <= Nmax )
        
        % Escrita da Qualidade de Malha
        fprintf( 'Mesh Quality %d :\n' , N );
        
        % Modelo Num�rico do Transdutor
        [ ~ , Mat_Param , Prop_Param , Node_Param , Elem_Param , Mpc_Param , t2 ] = numerical_model( x0 , N , FC , multicore );
        
        % M�ximo Deslocamento
        maxD ( N , 1 ) = max ( arrayfun ( @(struct)max(struct(:).max_disp   ) , Node_Param ) );
        
        % M�xima Tens�o
        maxS  ( N , 1 ) = max ( arrayfun ( @(struct)max(struct(:).max_stress ) , Elem_Param ) );
        
        % Quantidade de Graus de Liberdade
        dofs  ( N , 1 ) = max ( arrayfun ( @(struct)max(struct(:).dof ( : ) ) , Node_Param ) );
        
        % Ponto Inicial
        if ( N == 1 )
            
            % Incremento na Qualidade de Malha
            N = N + 1;
            
            % Continuar
            continue;
            
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CONVERG�NCIA - DESLOCAMENTO %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Deslocamento da Itera��o
        Dnew = maxD ( N , 1 );
        
        % Deslocamento da Itera��o Anterior
        Dold = maxD ( N - 1 , 1 );
        
        % Converg�ncia - Deslocamento
        error1 = abs ( ( Dnew - Dold ) / Dnew );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%
        % CONVERG�NCIA - TENS�O %
        %%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Tens�o da Itera��o
        Snew = maxS ( N , 1 );
        
        % Tens�o da Itera��o Anterior
        Sold = maxS ( N - 1 , 1 );
        
        % Converg�ncia - Tens�o
        error2 = abs ( ( Snew - Sold ) / Snew );
        
        %%%%%%%%%%%%%%%%%%%%%%%%%
        % CONVERG�NCIA - M�TODO %
        %%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Converg�ncia do M�todo
        error = max ( error1 , error2 );
        
        % Aloca��o do Erro
        errors ( N , 1 ) = error;        
        
        % Escrita do Erro do Deslocamento
        fprintf('Error1  : %2.2f\n' , error1 * 100 );
        
        % Escrita do Erro da Tens�o
        fprintf('Error2  : %2.2f\n' , error2 * 100 );
        
        % Escrita do Erro do M�todo
        fprintf('Error   : %2.2f\n' , error * 100  );
        
        % Incremento na Qualidade de Malha
        N = N + 1;

    end
    
    % Atualiza��o da Vari�vel de Qualidade de Malha
    N = N - 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VISUALIZA��O RESULTADOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Plot de Resultado -- Deslocamento
    figure
    hold on;
    grid on;
    plot   ( 2:N , maxD ( 2:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'blue' , 'MarkerEdgeColor' , 'blue' );
    xlabel ( 'Refinamento de malha'    , 'FontSize' , 12 );
    ylabel ( 'Deslocamento [ mm ]', 'FontSize' , 12 );
    title  ( strcat ( 'An�lise de converg�ncia - Ponto  ' , int2str ( i ) ) , 'FontSize' , 12 );
    set    ( gca , 'FontSize' , 12 );
    
    % Figura
    savefig ( strcat ( 'Define_Fc_point_' , int2str ( i ) , '_disp' , '.fig' ) );

    % Plot de Resultado -- Tens�o
    figure
    hold on;
    grid on;
    plot   ( 2:N , maxS ( 2:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'red' , 'MarkerEdgeColor' , 'red' );
    xlabel ( 'Refinamento de malha'    , 'FontSize' , 12 );
    ylabel ( 'Tens�o von Mises [ MPa ]', 'FontSize' , 12 );
    title  ( strcat ( 'An�lise de converg�ncia - Ponto  ' , int2str ( i ) ) , 'FontSize' , 12 );
    set    ( gca , 'FontSize' , 12 );
    
    % Figura
    savefig ( strcat ( 'Define_Fc_point_' , int2str ( i ) , '_stress' , '.fig' ) );
    
    % Plot de Resultado -- Erro
    figure
    hold on;
    grid on;
    plot   ( 2:N , 100 * errors ( 2:N , 1 ) , 'p' , 'LineWidth' , 2 , 'MarkerSize' , 8 , 'Marker' , 'o' , 'MarkerFaceColor' , 'black' , 'MarkerEdgeColor' , 'black' );
    xlabel ( 'Refinamento de malha'    , 'FontSize' , 12 );
    ylabel ( 'Erro [ % ]', 'FontSize' , 12 );
    title  ( strcat ( 'An�lise de converg�ncia - Ponto  ' , int2str ( i ) ) , 'FontSize' , 12 );
    set    ( gca , 'FontSize' , 12 );
    
    % Figura
    savefig ( strcat ( 'Define_Fc_point_' , int2str ( i ) , '_error' , '.fig' ) );
    
    % Aloca��o dos Deslocamentos
    disp_points   ( 1:end , i ) = maxD;
    
    % Aloca��o das Tens�es
    stress_points ( 1:end , i ) = maxS;
    
    % Aloca��o dos Graus de Liberdade
    dof_points    ( 1:end , i ) = dofs;
    
    % Aloca��o dos Erros
    error_points  ( 1:end , i ) = errors;
    
    % Salvar as Vari�veis
    save ( strcat ( 'Define_Fc_point_' , int2str ( i ) , '.mat' ) );
        
end

% Salvar as Vari�veis
save ( 'Define_Fc.mat' );

% Determina��o do Tempo
fprintf('\nTotal time [ s ] : %g\n\n' , toc );

% Finaliza��o da An�lise
display ( '\nEnd' );
display ( 'Analysis Succesfully' );

% Finaliza��o do Di�rio
diary off;