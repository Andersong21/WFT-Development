%% Defini��o do Ponto Inicial

%% INPUT
% LB                         - Lower Bound das Vari�veis
% UB                         - Upper Bound das Vari�veis
% nsamples                   - N�mero das Amostras

%% OUTPUT
% xn ( x , nsamples )        - Vari�veis de cada amostra da an�lise
% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]
% x ( 10 ) - Vari�vel P      - Posi��o do Gaige no Comprimento Lf   - [ -- ]
% nsamples                   - N�mero de Amostras

%% Declara��o da Fun��o de Defini��o do Ponto Inicial
function [ xn , nsamples ] = get_starting_point3 ( LB , UB , ~ )

    %%%%%%%
    % DOE %
    %%%%%%%
    
    % Inicializa��o dos Pontos do Problema
    x0 = [ LB ; UB ]; 
    
    % Vetor Transposto dos Pontos do Problema
    x0 =  transpose ( x0 );    

    % Atualiza��o do Vetor de Pontos Iniciais
    xn = zeros ( 16 , 9 );
    
    %%%%%%%%%%%
    % PONTO 1 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 1
    xn ( 1 , 1 ) = x0 ( 1 , 1 );
    xn ( 1 , 2 ) = x0 ( 2 , 2 );
    xn ( 1 , 3 ) = x0 ( 3 , 2 );
    xn ( 1 , 4 ) = x0 ( 4 , 2 );
    xn ( 1 , 5 ) = x0 ( 5 , 1 );
    xn ( 1 , 6 ) = x0 ( 6 , 2 );
    xn ( 1 , 7 ) = x0 ( 7 , 1 );
    xn ( 1 , 8 ) = x0 ( 8 , 1 );
    xn ( 1 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%
    % PONTO 2 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 2
    xn ( 2 , 1 ) = x0 ( 1 , 1 );
    xn ( 2 , 2 ) = x0 ( 2 , 1 );
    xn ( 2 , 3 ) = x0 ( 3 , 1 );
    xn ( 2 , 4 ) = x0 ( 4 , 2 );
    xn ( 2 , 5 ) = x0 ( 5 , 1 );
    xn ( 2 , 6 ) = x0 ( 6 , 2 );
    xn ( 2 , 7 ) = x0 ( 7 , 2 );
    xn ( 2 , 8 ) = x0 ( 8 , 2 );
    xn ( 2 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%
    % PONTO 3 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 3
    xn ( 3 , 1 ) = x0 ( 1 , 1 );
    xn ( 3 , 2 ) = x0 ( 2 , 2 );
    xn ( 3 , 3 ) = x0 ( 3 , 1 );
    xn ( 3 , 4 ) = x0 ( 4 , 1 );
    xn ( 3 , 5 ) = x0 ( 5 , 2 );
    xn ( 3 , 6 ) = x0 ( 6 , 2 );
    xn ( 3 , 7 ) = x0 ( 7 , 1 );
    xn ( 3 , 8 ) = x0 ( 8 , 2 );
    xn ( 3 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%
    % PONTO 4 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 4
    xn ( 4 , 1 ) = x0 ( 1 , 1 );
    xn ( 4 , 2 ) = x0 ( 2 , 2 );
    xn ( 4 , 3 ) = x0 ( 3 , 1 );
    xn ( 4 , 4 ) = x0 ( 4 , 2 );
    xn ( 4 , 5 ) = x0 ( 5 , 2 );
    xn ( 4 , 6 ) = x0 ( 6 , 1 );
    xn ( 4 , 7 ) = x0 ( 7 , 2 );
    xn ( 4 , 8 ) = x0 ( 8 , 1 );
    xn ( 4 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%
    % PONTO 5 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 5
    xn ( 5 , 1 ) = x0 ( 1 , 2 );
    xn ( 5 , 2 ) = x0 ( 2 , 1 );
    xn ( 5 , 3 ) = x0 ( 3 , 1 );
    xn ( 5 , 4 ) = x0 ( 4 , 2 );
    xn ( 5 , 5 ) = x0 ( 5 , 2 );
    xn ( 5 , 6 ) = x0 ( 6 , 2 );
    xn ( 5 , 7 ) = x0 ( 7 , 1 );
    xn ( 5 , 8 ) = x0 ( 8 , 1 );
    xn ( 5 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%
    % PONTO 6 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 6
    xn ( 6 , 1 ) = x0 ( 1 , 2 );
    xn ( 6 , 2 ) = x0 ( 2 , 2 );
    xn ( 6 , 3 ) = x0 ( 3 , 2 );
    xn ( 6 , 4 ) = x0 ( 4 , 2 );
    xn ( 6 , 5 ) = x0 ( 5 , 2 );
    xn ( 6 , 6 ) = x0 ( 6 , 2 );
    xn ( 6 , 7 ) = x0 ( 7 , 2 );
    xn ( 6 , 8 ) = x0 ( 8 , 2 );
    xn ( 6 , 9 ) = x0 ( 9 , 2 );
 
    %%%%%%%%%%%
    % PONTO 7 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 7
    xn ( 7 , 1 ) = x0 ( 1 , 1 );
    xn ( 7 , 2 ) = x0 ( 2 , 1 );
    xn ( 7 , 3 ) = x0 ( 3 , 2 );
    xn ( 7 , 4 ) = x0 ( 4 , 1 );
    xn ( 7 , 5 ) = x0 ( 5 , 2 );
    xn ( 7 , 6 ) = x0 ( 6 , 2 );
    xn ( 7 , 7 ) = x0 ( 7 , 2 );
    xn ( 7 , 8 ) = x0 ( 8 , 1 );
    xn ( 7 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%
    % PONTO 8 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 8
    xn ( 8 , 1 ) = x0 ( 1 , 2 );
    xn ( 8 , 2 ) = x0 ( 2 , 1 );
    xn ( 8 , 3 ) = x0 ( 3 , 2 );
    xn ( 8 , 4 ) = x0 ( 4 , 1 );
    xn ( 8 , 5 ) = x0 ( 5 , 1 );
    xn ( 8 , 6 ) = x0 ( 6 , 2 );
    xn ( 8 , 7 ) = x0 ( 7 , 1 );
    xn ( 8 , 8 ) = x0 ( 8 , 2 );
    xn ( 8 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%
    % PONTO 9 %
    %%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 9
    xn ( 9 , 1 ) = x0 ( 1 , 2 );
    xn ( 9 , 2 ) = x0 ( 2 , 1 );
    xn ( 9 , 3 ) = x0 ( 3 , 1 );
    xn ( 9 , 4 ) = x0 ( 4 , 1 );
    xn ( 9 , 5 ) = x0 ( 5 , 2 );
    xn ( 9 , 6 ) = x0 ( 6 , 1 );
    xn ( 9 , 7 ) = x0 ( 7 , 2 );
    xn ( 9 , 8 ) = x0 ( 8 , 2 );
    xn ( 9 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%%
    % PONTO 10 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 10
    xn ( 10 , 1 ) = x0 ( 1 , 2 );
    xn ( 10 , 2 ) = x0 ( 2 , 2 );
    xn ( 10 , 3 ) = x0 ( 3 , 1 );
    xn ( 10 , 4 ) = x0 ( 4 , 2 );
    xn ( 10 , 5 ) = x0 ( 5 , 1 );
    xn ( 10 , 6 ) = x0 ( 6 , 1 );
    xn ( 10 , 7 ) = x0 ( 7 , 1 );
    xn ( 10 , 8 ) = x0 ( 8 , 2 );
    xn ( 10 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%%
    % PONTO 11 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 11
    xn ( 11 , 1 ) = x0 ( 1 , 1 );
    xn ( 11 , 2 ) = x0 ( 2 , 2 );
    xn ( 11 , 3 ) = x0 ( 3 , 2 );
    xn ( 11 , 4 ) = x0 ( 4 , 1 );
    xn ( 11 , 5 ) = x0 ( 5 , 1 );
    xn ( 11 , 6 ) = x0 ( 6 , 1 );
    xn ( 11 , 7 ) = x0 ( 7 , 2 );
    xn ( 11 , 8 ) = x0 ( 8 , 2 );
    xn ( 11 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%%
    % PONTO 12 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 12
    xn ( 12 , 1 ) = x0 ( 1 , 2 );
    xn ( 12 , 2 ) = x0 ( 2 , 2 );
    xn ( 12 , 3 ) = x0 ( 3 , 2 );
    xn ( 12 , 4 ) = x0 ( 4 , 1 );
    xn ( 12 , 5 ) = x0 ( 5 , 2 );
    xn ( 12 , 6 ) = x0 ( 6 , 1 );
    xn ( 12 , 7 ) = x0 ( 7 , 1 );
    xn ( 12 , 8 ) = x0 ( 8 , 1 );
    xn ( 12 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%%
    % PONTO 13 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 13
    xn ( 13 , 1 ) = x0 ( 1 , 2 );
    xn ( 13 , 2 ) = x0 ( 2 , 1 );
    xn ( 13 , 3 ) = x0 ( 3 , 2 );
    xn ( 13 , 4 ) = x0 ( 4 , 2 );
    xn ( 13 , 5 ) = x0 ( 5 , 1 );
    xn ( 13 , 6 ) = x0 ( 6 , 1 );
    xn ( 13 , 7 ) = x0 ( 7 , 2 );
    xn ( 13 , 8 ) = x0 ( 8 , 1 );
    xn ( 13 , 9 ) = x0 ( 9 , 1 );
    
    %%%%%%%%%%%%
    % PONTO 14 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 14
    xn ( 14 , 1 ) = x0 ( 1 , 1 );
    xn ( 14 , 2 ) = x0 ( 2 , 1 );
    xn ( 14 , 3 ) = x0 ( 3 , 1 );
    xn ( 14 , 4 ) = x0 ( 4 , 1 );
    xn ( 14 , 5 ) = x0 ( 5 , 1 );
    xn ( 14 , 6 ) = x0 ( 6 , 1 );
    xn ( 14 , 7 ) = x0 ( 7 , 1 );
    xn ( 14 , 8 ) = x0 ( 8 , 1 );
    xn ( 14 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%%
    % PONTO 15 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 15
    xn ( 15 , 1 ) = x0 ( 1 , 1 );
    xn ( 15 , 2 ) = x0 ( 2 , 1 );
    xn ( 15 , 3 ) = x0 ( 3 , 2 );
    xn ( 15 , 4 ) = x0 ( 4 , 2 );
    xn ( 15 , 5 ) = x0 ( 5 , 2 );
    xn ( 15 , 6 ) = x0 ( 6 , 1 );
    xn ( 15 , 7 ) = x0 ( 7 , 1 );
    xn ( 15 , 8 ) = x0 ( 8 , 2 );
    xn ( 15 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%%
    % PONTO 16 %
    %%%%%%%%%%%%
    
    % Defini��o dos Par�metros do Ponto 16
    xn ( 16 , 1 ) = x0 ( 1 , 2 );
    xn ( 16 , 2 ) = x0 ( 2 , 2 );
    xn ( 16 , 3 ) = x0 ( 3 , 1 );
    xn ( 16 , 4 ) = x0 ( 4 , 1 );
    xn ( 16 , 5 ) = x0 ( 5 , 1 );
    xn ( 16 , 6 ) = x0 ( 6 , 2 );
    xn ( 16 , 7 ) = x0 ( 7 , 2 );
    xn ( 16 , 8 ) = x0 ( 8 , 1 );
    xn ( 16 , 9 ) = x0 ( 9 , 2 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % QUANTIDADE DE AMOSTRAS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Determina��o da Quantidade de Amostras
    [ nsamples , ~ ] = size ( xn );
    
end