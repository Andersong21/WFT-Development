%% Fun��o de Associa��o dos Deslocamento a Estrutura dos N�s

%% OUTPUT
% Node_Param   - Estrutura dos Par�metros dos N�s Preenchidos Desloc
% T            - Matriz de Aplica��o do Multi Point Constraint

%% INPUT
% X            - Deslocamentos do Sistema
% Node_Param   - Estrutura dos Par�metros dos N�s Vazios Desloc

%% Declara��o da Fun��o de Associa�ao dos Deslocamentos a Estrutura de N�s
function [ Node_Param ] = disp_node ( X , Node_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de N�s do Problema
    Nnode = Node_Param ( end ).id;
    
    % Transforma��o da Matriz em Cheia
    X = full ( X );

    % Varredura na Lista de N�s
    for i = 1:Nnode

        % Varredura na Lista dos Graus de Liberdade do N�
        for j = 1:6
            
            % Verifica��o se o Grau de Liberdade � nulo
            if ( Node_Param ( i ).dof ( j ) == 0 )
            
                % Aloca��o dos Deslocamentos Nodais
                Node_Param ( i ).disp ( j ) = 0;                
                
            else
                
                % Aloca��o dos Deslocamentos Nodais
                Node_Param ( i ).disp ( j ) = X ( Node_Param ( i ).dof ( j ) );
                
            end            

        end
        
        % M�ximo Deslocamento
        Node_Param ( i ).max_disp = sqrt ( ( Node_Param ( i ).disp ( 1 )^2 ) + ( Node_Param ( i ).disp ( 2 )^2 ) + ( Node_Param ( i ).disp ( 3 )^2 ) );

    end   
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('disp_node : %2.2f s.\n', t2 );
    
end