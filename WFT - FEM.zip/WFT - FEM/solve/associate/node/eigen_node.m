%% Fun��o de Associa��o dos Autovalores a Estrutura dos N�s

%% OUTPUT
% Node_Param   - Estrutura dos Par�metros dos N�s Preenchidos Autovalores

%% INPUT
% EVA          - Autovalores do Sistema
% EVC          - Autovetores do Sistema
% Node_Param   - Estrutura dos Par�metros dos N�s Vazios Autovalores

%% Declara��o da Fun��o de Associa�ao dos Autovalores a Estrutura dos N�s
function [ Node_Param ] = eigen_node ( EVA , EVC , Node_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de N�s do Problema
    Nnode = Node_Param ( end ).id;
    
    % Transforma��o da Matriz em Cheia
    EVC = full ( EVC );
    
    % Quantidade de Autovalores
    eigenV = length ( EVA );
    
    % Varredura nos Autovalores
    for i = 1:eigenV
        
        % Varredura na Lista de N�s
        for j = 1:Nnode
            
            % Aloca��o do Autovalor ao N�
            Node_Param ( j ).EVA ( i ) = EVA ( i );

            % Varredura na Lista dos Graus de Liberdade do N�
            for k = 1:6

                % Verifica��o se o Grau de Liberdade � nulo
                if ( Node_Param ( j ).dof ( k ) == 0 )

                    % Aloca��o dos Autovetores ao N�
                    Node_Param ( j ).EVC ( k , i ) = 0;

                else
                    
                    % Grau de Liberdade Associado
                    dof = Node_Param ( j ).dof ( k );

                    % Aloca��o dos Autovetores ao N�
                    Node_Param ( j ).EVC ( k , i ) = EVC ( dof , i );

                end

            end
            
        end

    end  
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('eigen_node : %2.2f s.\n', t2 );
    
end