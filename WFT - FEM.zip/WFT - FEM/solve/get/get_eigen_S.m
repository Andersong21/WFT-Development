%% Retorno do Gerador das Matrizes de Solu��o Modal do Problema

%% INPUT
% K            - Matriz de Rigidez do Problema
% M            - Matriz de Massa do Problema
% Node_Param   - Estrutura de Dados dos N�s do Problema

%% OUTPUT
% EVA          - Vetor de AutoValores do Problema
% EVC          - Vetor de AutoVetores do Problema
% Node_Param   - Estrutura de Dados dos N�s do Problema -- EigenSystem

%% Declara��o da Fun��o de Retorno do Gerador das Matrizes de Solu��o Modal do Problema
function [ Node_Param ] = get_eigen_S ( K , M , Node_Param )
    
    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Solu��o do Sistema Modal
    [ EVA , EVC ] = esolve ( K , M );
    
    %  Associa��o dos Sistema de Autovalores ao N�s do Problema
    [ Node_Param ] = eigen_node ( EVA , EVC , Node_Param );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_eigen_S : %2.2f s.\n', t2 );
    
end