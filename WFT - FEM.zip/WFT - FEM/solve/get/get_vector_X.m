%% Retorno do Gerador do Vetor de Deslocamentos do Problema

%% INPUT
% K            - Matriz de Rigidez do Problema
% F            - Vetor de For�as do Problema
% Node_Param   - Estrutura de Dados dos N�s do Problema

%% OUTPUT
% Node_Param   - Estrutura de Dados dos N�s do Problema -- Displacement

%% Declara��o da Fun��o de Retorno do Gerador do Vetor de For�as da An�lise
function [ Node_Param ] = get_vector_X ( K , F , Node_Param )
    
    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Solu��o do Sistema Linear
    [ X ] = lsolve ( K , F );
     
    %  Associa��o dos Deslocamentos a Estrutura dos N�s
    [ Node_Param ] = disp_node ( X , Node_Param );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_vector_X : %2.2f s.\n', t2 );
    
end