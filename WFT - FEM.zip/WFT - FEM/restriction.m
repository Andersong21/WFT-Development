%% Defini��o das Restri��es

% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]
% n                          - Quantidade de Elementos              - [ -  ] 
% CS                         - Coeficiente de Seguran�a             - [ -  ]
% multicore                  - Quantidade de N�cleos

%% Declara��o da Fun��o Objetivo
function [ c , ceq ] = restriction( x , n , CS , multicore )

    %%%%%%%%%%%%%
    % VARI�VEIS %
    %%%%%%%%%%%%%
    
    % Defini��o das Vari�veis
    b1 = x ( 1 , 1 );
    h1 = x ( 1 , 2 );
    b2 = x ( 1 , 3 );
    h2 = x ( 1 , 4 );
    L  = x ( 1 , 5 );
    Lf = x ( 1 , 6 );
    t  = x ( 1 , 7 );
    d  = x ( 1 , 8 );
    r  = x ( 1 , 9 );
    
    %%%%%%%%%%%%%%%%%%%
    % PAR�METROS RODA %
    %%%%%%%%%%%%%%%%%%%
    
    % Raio Interno da Roda
    Ri = 176 / 2;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % RESTRI��ES GEOM�TRICAS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Restri��o de Inequaldade - Geometria
    c ( 1 ) = h1 - 60;
    c ( 2 ) = h2 - 60;
    c ( 3 ) = ( L - ( t / 2 ) ) + r - Ri;
    c ( 4 ) = ( Lf / 2 ) + 15 - ( Ri * sqrt ( 2 ) / 2 );
    c ( 5 ) = ( d / min ( min ( min ( b1 , b2 ) , h1 ) , h2 ) ) - 0.10;
       
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno do Material do Sistema
    [ Mat_Param ] = get_mat ();
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DAS PROPRIEDADES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno das Propriedades do Sistema
    [ Prop_Param ] = get_prop ( t );
    
    %%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DO MPC %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Retorno dos Mpcs do Sistema
    [ Mpc_Param ] = get_mpc ();

    %%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DE MALHA %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Gerador de Malha
    [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = get_mesh ( b1 , h1 , b2 , h2 , L , Lf , t , d , r , n , Prop_Param , Mpc_Param , Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MONTAGEM DA MATRIZ DE RIGIDEZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Rigidez do Problema
    [ K ] = get_matrix_K ( Node_Param , Elem_Param , Mat_Param , Prop_Param , Mpc_Param , multicore );

    %%%%%%%%%%%%%%%%%%%
    % VETOR DE FOR�AS %
    %%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de For�as do Problema
    [ F , Node_Param ] = get_vector_F ( Node_Param , 7 );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SOLU��O DO SISTEMA LINEAR %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos
    [ Node_Param ] = get_vector_X ( K , F , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DAS DEFORMA��ES E TENS�ES DOS ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Fun��o de C�lculo das Deforma��es e Tens�es dos Elementos
    [ Elem_Param ] = get_strain_stress ( Node_Param , Elem_Param , Mat_Param , Prop_Param , multicore );  

    %%%%%%%%%%%%%%%%%%%%%
    % RESTRI��ES TENS�O %
    %%%%%%%%%%%%%%%%%%%%%
    
    % M�xima Tens�o
    Max_Stress = max ( arrayfun ( @( struct )max( struct( : ).max_stress ) , Elem_Param ) );
    
    % Restri��o de Tens�o
    c ( 6 ) = Max_Stress - ( Mat_Param ( 1 ).Sfad / CS );

    %%%%%%%%%%%%%%%%%%%%%%%
    % RESTRI��O IGUALDADE %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Restri��o -- Igualdade
    ceq = [];     

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % LIMPEZA DAS VARI�VEIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Limpeza das Estruturas
    clearvars Node_Param;
    clearvars Elem_Param;
    clearvars Prop_Param;
    clearvars Mat_Param;
    clearvars Mpc_Param;

end