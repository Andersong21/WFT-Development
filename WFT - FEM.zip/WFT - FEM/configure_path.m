%% Defini��o dos Path das Fun��es 

%% Declara��o da Fun��o de Defini��o dos Paths das Fun��es
function configure_path()

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o do Gerador do Material
    addpath ( './material/get' );
    
    % Path da Fun��o de Inicializa��o do Material
    addpath ( './material/init' );    
        
    % Path da Fun��o de Cria��o do Material
    addpath ( './material/create' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % PROPRIEDADES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o do Gerador das Propriedades
    addpath ( './prop/get' );
    
    % Path da Fun��o de Inicializa��o das Propriedades
    addpath ( './prop/init' );
    
    % Path da Fun��o de Cria��o da Propriedade 2D
    addpath ( './prop/create' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % MPCS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%    
        
    % Path da Fun��o do Gerador dos MPcs
    addpath ( './mpc/get' );
    
    % Path da Fun��o de Inicializa��o dos Mpcs
    addpath ( './mpc/init' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % MESH %
    %%%%%%%%%%%%%%%%%%%%%%%%%%    
      
    % Path da Fun��o do Gerador da Malha
    addpath ( './mesh/get' );
    
    % Path da Fun��o de Inicializa��o da Malha
    addpath ( './mesh/init' );    
    
    % Path da Fun��o de Cria��o da Malha
    addpath ( './mesh/create' );
    
    % Path da Fun��o de Exemplos da Malha
    addpath ( './mesh/example' );
    
    % Path da Fun��o de Escrita da Malha
    addpath ( './mesh/write' );
    
    % Path da Convers�o do Texto para Formato ASCII
    addpath ( './convert/text' );
    
    % Path das Fun��es de Escrita
    addpath ( './mesh/write/MD_Nastran' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % RIGIDEZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o de Retorno da Matriz de Rigidez
    addpath ( './stiff/get' );

    % Path da Fun��o de Cria��o da Matriz de Rigidez
    addpath ( './stiff/create' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % MASSA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%    
        
    % Path da Fun��o de Retorno da Matriz de Massa
    addpath ( './mass/get' );
    
    % Path da Fun��o de Cria��o da Matriz de Massa
    addpath ( './mass/create' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % POINT0 %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path de Defini��o da Matriz de Massa nos Pontos de Integra��o
    addpath ( './elements/point0' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % BEAM2 %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path de Defini��o dos Par�metros do Elemento
    addpath ( './elements/beam2/param' );
    
    % Path de Defini��o das Coordenadas do Elemento
    addpath ( './elements/beam2/coord' );

    % Path de Defini��o da Matriz de Rota��o
    addpath ( './elements/beam2/R' );
    
    % Path de Defini��o das Caracter�sticas de Materiais do Elemento
    addpath ( './elements/beam2/mat' );
    
    % Path de Defini��o da Matriz de Correla��o Deforma��o Deslocamento
    addpath ( './elements/beam2/B' );

    % Path da Fun��o de C�lculo da Matriz de Rigidez beam2
    addpath ( './elements/beam2/K' );
    
    % Path de Defini��o da Matriz de Massa nos Pontos de Integra��o
    addpath ( './elements/beam2/M' );
    
    % Path da Fun��o de C�lculo das Deforma��es e Tens�es do Elemento Beam2
    addpath ( './elements/beam2/SSC' );
    
    % Path da Fun��o de C�lculo dos Deslocamentos do Elemento Beam2
    addpath ( './elements/beam2/SSC/disp' );
    
    % Path da Fun��o de C�lculo das Deforma��es do Elemento Beam2
    addpath ( './elements/beam2/SSC/strain' );
    
    % Path da Fun��o de C�lculo das Tens�es do Elemento Beam2
    addpath ( './elements/beam2/SSC/stress' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % QUAD4 %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path de Defini��o das Coordenadas do Elemento
    addpath ( './elements/quad4/coord' );
    
    % Path de Defini��o da Matriz dos Pontos de Integra��o
    addpath ( './elements/quad4/PO' );
    
    % Path de Defini��o da Matriz dos Pesos dos Pontos de Integra��o
    addpath ( './elements/quad4/WE' );
    
    % Path de Defini��o da Matriz de Rota��o
    addpath ( './elements/quad4/R' );
    
    % Path de Defini��o da Matriz Jacobiana
    addpath ( './elements/quad4/J' );
    
    % Path de Defini��o das Caracter�sticas de Materiais do Elemento
    addpath ( './elements/quad4/mat' );
    
    % Path de Defini��o da Matriz de Correla��o Deforma��o Deslocamento
    addpath ( './elements/quad4/B' );

    % Path da Fun��o de C�lculo da Matriz de Rigidez quad4
    addpath ( './elements/quad4/K' );
    
    % Path da Fun��o de C�lculo das Deforma��es e Tens�es do Elemento quad4
    addpath ( './elements/quad4/SSC' );
    
    % Path da Fun��o de C�lculo dos Deslocamentos do Elemento quad4
    addpath ( './elements/quad4/SSC/disp' );
    
    % Path da Fun��o de C�lculo das Deforma��es do Elemento quad4
    addpath ( './elements/quad4/SSC/strain' );
    
    % Path da Fun��o de C�lculo das Tens�es do Elemento quad4
    addpath ( './elements/quad4/SSC/stress' );    
        
    % Path de Defini��o da Matriz de Fun��es de Forma
    addpath ( './elements/quad4/H' );

    % Path da Fun��o de C�lculo da Matriz de Massa quad4
    addpath ( './elements/quad4/M' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % EIGEN %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o de Retorno do Sistema de Solu��o Modal
    addpath ( './solve/get' );
    
    % Path da Fun��o de Solu��o do Sistema Modal
    addpath ( './eigensolve' );
    
    % Path da Fun��o de Associa��o dos Autovalores aos N�s do Problema
    addpath ( './solve/associate/node' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % LINSOLVE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o de Solu��o do Sistema Linear
    addpath ( './linsolve' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % FORCE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % Path da Fun��o de Retorno do Vetor de For�as
    addpath ( './force/get' );
        
    % Path da Fun��o de Cria��o do Vetor de For�as
    addpath ( './force/create' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % DISP %
    %%%%%%%%%%%%%%%%%%%%%%%%%% 
    
    % Path da Fun��o do Retorno do Vetor de Deslocamentos
    addpath ( './solve/get' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % LOADCELL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
    % Path da Fun��o de C�lculo do Ponto de Deforma��o da C�lula de Carga
    addpath ( './loadcell/compliance' );
    
    % Path da Fun��o de Retorno do Vetor de Deforma��es
    addpath ( './loadcell/strain' );
    
    % Path da Fun��o de C�lculo da Calibra��o da C�lula de Carga
    addpath ( './loadcell/calibration' );    
    
    % Path da Fun��o de C�lculo do Cross Talking da C�lula de Carga
    addpath ( './loadcell/crosstalking' );
    
    % Path da Fun��o de C�lculo da Isotropia da C�lula de Carga
    addpath ( './loadcell/isotropy' );
    
    % Path da Fun��o de C�lculo das Sensibilidades da C�lula de Carga
    addpath ( './loadcell/sensibility' );
    
    % Path da Fun��o de Retorno do Vetor de For�as
    addpath ( './loadcell/force' );
    
    % Path da Fun��o de Procura da Posi��o P
    addpath ( './loadcell/find'  );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % DEFORMA��O TENS�O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o de Retorno das Deforma��es e Tens�es dos Elementos
    addpath ( './strain_stress/get' );
    
    % Path da Fun��o de C�lculo das Deforma��es e Tens�es dos Elementos
    addpath ( './strain_stress/calc' );
    
    % Path da Fun��o de C�lculo dos Pontos de Isoflex�o
    addpath ( './strain_stress/iso'  );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O PATHS % RESULTADOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Path da Fun��o de Escrita dos Resultados
    addpath ( './results' );    

end

