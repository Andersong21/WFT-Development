%% Retorno do C�lculo das Deforma��es e Tens�es nos Elementos

%% INPUT - Sem Deforma��o
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema

%% OUPTUT - Com Deforma��o e Tens�o
% Node_Param        - Estrutura de Dados dos N�s da Malha -- Deforma��o // Tens�o
% Node_Param        - Estrutura de Dados dos Elementos da Malha -- Deforma��o // Tens�o

%% Declara��o da Fun��o de Retorno das Deforma��es e Tens�es dos Elementos
function [ Node_Param , Elem_Param ] = get_strain_stress ( Node_Param , Elem_Param , Mat_Param , Prop_Param , multicore )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % C�lculo das Deforma��es e Tens�es nos Elementos
    [ Node_Param , Elem_Param ] = calc_strain_stress ( Node_Param , Elem_Param , Mat_Param , Prop_Param , multicore );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_strain_stress : %2.2f s.\n', t2 );
    
end