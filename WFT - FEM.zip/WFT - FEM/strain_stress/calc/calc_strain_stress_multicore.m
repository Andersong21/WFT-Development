%% C�lculo das Deforma��es e Tens�es nos Elementos

%% INPUT - Sem Deforma��o
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% multicore         - Quantidade de N�cleos

%% OUPTUT - Com Deforma��o e Tens�o
% Ei                - Matriz de Deforma��es do N�
% Si                - Matriz de Tens�es do N�

%% Declara��o da Fun��o de C�lculo das Deforma��es e Tens�es dos Elementos
function [ Ef , Sf ] = calc_strain_stress_multicore ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem )   

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VARREDURA NA LISTA DE ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Quantidade de Elementos
    Nelem = length ( List_elem );
    
    % Inicializa��o das C�lulas para Aloca��o dos Termos de Deforma��o
    Eg = cell ( [ 1 , Nelem ] );
    
    % Inicializa��o das C�lulas para Aloca��o dos Termos de Tens�o
    Sg = cell ( [ 1 , Nelem ] );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VARREDURA NA LISTA DE ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura na Lista de Elementos
    for i = 1:length ( List_elem )
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % C�LCULO DAS DEFORMA��ES E TENS�ES 1D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Deforma��es e Tens�es 1D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '1d' ) == 1 )
        
            % C�lculo das Deforma��es e Tens�es -- Beam2
            [ Ei , Si ] = strain_stress_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem ( i ) );
                        
            % Aloca��o dos Vetores do Triplet
            Eg { i } = Ei;
            Sg { i } = Si;
            
            % Continuar
            continue;     
        
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % C�LCULO DAS DEFORMA��ES E TENS�ES 2D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Deforma��es e Tens�es 2D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '2d' ) == 1 )
        
            % C�lculo das Deforma��es e Tens�es -- Quad4
            [ Ei , Si ] = strain_stress_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem ( i ) );
                        
            % Aloca��o dos Vetores do Triplet
            Eg { i } = Ei;
            Sg { i } = Si;
            
            % Continuar
            continue;     
        
        end  
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % C�LCULO DAS DEFORMA��ES E TENS�ES 0D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Deforma��es e Tens�es 0D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '0d' ) == 1 )
                                
            % Aloca��o dos Vetores do Triplet
            Eg { i } = zeros ( 1 , 24 );
            Sg { i } = zeros ( 1 , 24 );
            
            % Continuar
            continue;     
        
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O NA MATRIZ DE DEFORMA��ES E TENS�ES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Defini��o da Matriz de Deforma��es
    Ef = vertcat ( Eg { : } );

    % Defini��o da Matriz de Tens�es
    Sf = vertcat ( Sg { : } );
    
end