%% C�lculo das Deforma��es e Tens�es nos Elementos

%% INPUT - Sem Deforma��o
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% multicore         - Quantidade de N�cleos

%% OUPTUT - Com Deforma��o e Tens�o
% Node_Param        - Estrutura de Dados dos N�s do Problema -- Com Deforma��o e Tens�o
% Elem_Param        - Estrutura de Dados dos Elementos do Problema -- Com Deforma��o e Tens�o

%% Declara��o da Fun��o de C�lculo das Deforma��es e Tens�es dos Elementos
function [ Node_Param , Elem_Param ] = calc_strain_stress ( Node_Param , Elem_Param , Mat_Param , Prop_Param , multicore )   

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFORMA��ES E TENS�ES %
    %%%%%%%%%%%%%%%%%%%%%%%%%

    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id;
    
    % Quantidade de Elementos por N�cleo
    delem = fix ( Nelem / multicore );
    
    % Redimensionamento do tamanho dos n�cleos
    if ( delem == 0 )
        
        % Par�metro de Quantidade de N�cleos
        multicore = 1;
        
    end
    
    % Inicializa��o das C�lulas
    Ec = {};
    Sc = {};
    
    % Varredura na Lista de N�cleos
    parfor i = 1:multicore
        
        %%%%%%%%%%%%%%
        % DEFINI��ES %
        %%%%%%%%%%%%%%
        
        % Primeiros N�cleos 
        if ( i ~= multicore )
        
            % In�cio dos Elementos
            begin_elem = 1 + ( ( i - 1 ) * delem );

            % Final dos Elementos
            end_elem = i * delem;

        % Demais N�cleos
        else
            
            % In�cio dos Elementos
            begin_elem = 1 + ( ( i - 1 ) * delem );

            % Final dos Elementos
            end_elem = Nelem;
            
        end        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DAS DEFORMA��ES E TENS�ES % MULTICORE %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Cria��o da Matriz de Rigidez em cada N�cleo
        [ Ei , Si ] = calc_strain_stress_multicore ( Node_Param , Elem_Param , Mat_Param , Prop_Param , begin_elem:1:end_elem );
        
        % Aloca��o na Linha da Matriz de Termos
        Ec = [ Ec ; { Ei } ];
        Sc = [ Sc ; { Si } ];
        
    end
    
    % Transforma��o das C�lulas em Matrix
    Eg = vertcat ( Ec { : } );
    Sg = vertcat ( Sc { : } );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ALOCA��O NOS ELEMENTOS DO PROBLEMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos Elementos do Problema
    for j = 1:Nelem
       
        % Tipo de Elemento -- 1D
        if ( strcmp ( Elem_Param ( j ).type , '1d' ) == 1 )
            
            % Aloca��o nos Termos do Elemento
            Elem_Param ( j ).strain ( 1:24 ) = Eg ( j , 1:24 );  
            Elem_Param ( j ).stress ( 1:24 ) = Sg ( j , 1:24 );
            
            % Tens�o de Von Mises
            New_Max_Stress = 0.0;
            
            % Deforma��o de Von Mises
            New_Max_Strain = 0.0;
            
            % C�lculo da Deforma��o de Von Mises --- Nos Pontos A , B , C , D
            for k = 1:4
                
                % Tens�o nos Pontos
                sx  = Elem_Param ( j ).stress ( ( 6 * k - 5 ) );
                sy  = Elem_Param ( j ).stress ( ( 6 * k - 4 ) );
                sz  = Elem_Param ( j ).stress ( ( 6 * k - 3 ) );
                sxy = Elem_Param ( j ).stress ( ( 6 * k - 2 ) );
                syz = Elem_Param ( j ).stress ( ( 6 * k - 1 ) );
                sxz = Elem_Param ( j ).stress ( ( 6 * k - 0 ) );
                
                % Deforma��es nos Pontos
                ex  = Elem_Param ( j ).strain ( ( 6 * k - 5 ) );
                ey  = Elem_Param ( j ).strain ( ( 6 * k - 4 ) );
                ez  = Elem_Param ( j ).strain ( ( 6 * k - 3 ) );
                exy = Elem_Param ( j ).strain ( ( 6 * k - 2 ) );
                eyz = Elem_Param ( j ).strain ( ( 6 * k - 1 ) );
                exz = Elem_Param ( j ).strain ( ( 6 * k - 0 ) );
                    
                % Tens�o Von Mises do Ponto
                New_Max_Stress_Point = sqrt ( ( ( 1 / 2 ) * ( ( ( sx - sy )^2 ) + ( ( sy - sz )^2 ) + ( ( sx - sz )^2 ) ) ) +  ( 3 * ( ( sxy^2 ) + ( syz^2 ) + ( sxz^2 ) ) ) );

                % Deforma��o Von Mises do Ponto
                New_Max_Strain_Point = sqrt ( ( ( 1 / 2 ) * ( ( ( ex - ey )^2 ) + ( ( ey - ez )^2 ) + ( ( ex - ez )^2 ) ) ) +  ( 3 * ( ( exy^2 ) + ( eyz^2 ) + ( exz^2 ) ) ) );

                % M�xima Tens�o de Von Mises no Ponto
                New_Max_Stress = max ( New_Max_Stress , New_Max_Stress_Point );

                % M�xima Deforma��o de Von Mises no Ponto
                New_Max_Strain = max ( New_Max_Strain , New_Max_Strain_Point );
                    
            end
            
            % Aloca��o da Tens�o de Von Mises
            Elem_Param ( j ).max_stress = New_Max_Stress;
            
            % Aloca��o da Deforma��o de Von Mises
            Elem_Param ( j ).max_strain = New_Max_Strain;           
            
        end
        
        % Tipo de Elemento -- 2D
        if ( strcmp ( Elem_Param ( j ).type , '2d' ) == 1 )
            
            % Aloca��o nos Termos do Elemento
            Elem_Param ( j ).strain ( 1:18 ) = Eg ( j , 1:18 );  
            Elem_Param ( j ).stress ( 1:18 ) = Sg ( j , 1:18 );
            
            % Tens�o de Von Mises
            New_Max_Stress = 0.0;
            
            % Deforma��o de Von Mises
            New_Max_Strain = 0.0;
            
            % C�lculo da Deforma��o de Von Mises --- Nos Pontos A , B , C , D
            for k = 1:3
                
                % Tens�o e Deforma��o -- Partes Superior e Inferior
                if ( k ~= 1 )

                    % Tens�o nos Pontos
                    sx  = Elem_Param ( j ).stress ( ( 6 * k - 5 ) ) + Elem_Param ( j ).stress ( 1 );
                    sy  = Elem_Param ( j ).stress ( ( 6 * k - 4 ) ) + Elem_Param ( j ).stress ( 2 );
                    sz  = Elem_Param ( j ).stress ( ( 6 * k - 3 ) ) + Elem_Param ( j ).stress ( 3 );
                    sxy = Elem_Param ( j ).stress ( ( 6 * k - 2 ) ) + Elem_Param ( j ).stress ( 4 );
                    syz = Elem_Param ( j ).stress ( ( 6 * k - 1 ) );
                    sxz = Elem_Param ( j ).stress ( ( 6 * k - 0 ) );

                    % Deforma��o nos Pontos
                    ex  = Elem_Param ( j ).strain ( ( 6 * k - 5 ) ) + Elem_Param ( j ).strain ( 1 );
                    ey  = Elem_Param ( j ).strain ( ( 6 * k - 4 ) ) + Elem_Param ( j ).strain ( 2 );
                    ez  = Elem_Param ( j ).strain ( ( 6 * k - 3 ) ) + Elem_Param ( j ).strain ( 3 );
                    exy = Elem_Param ( j ).strain ( ( 6 * k - 2 ) ) + Elem_Param ( j ).strain ( 4 );
                    eyz = Elem_Param ( j ).strain ( ( 6 * k - 1 ) );
                    exz = Elem_Param ( j ).strain ( ( 6 * k - 0 ) );

                else

                    % Tens�o nos Pontos
                    sx  = Elem_Param ( j ).stress ( ( 6 * k - 5 ) );
                    sy  = Elem_Param ( j ).stress ( ( 6 * k - 4 ) );
                    sz  = Elem_Param ( j ).stress ( ( 6 * k - 3 ) );
                    sxy = Elem_Param ( j ).stress ( ( 6 * k - 2 ) );
                    syz = Elem_Param ( j ).stress ( ( 6 * k - 1 ) );
                    sxz = Elem_Param ( j ).stress ( ( 6 * k - 0 ) );

                    % Deforma��o nos Pontos
                    ex  = Elem_Param ( j ).strain ( ( 6 * k - 5 ) );
                    ey  = Elem_Param ( j ).strain ( ( 6 * k - 4 ) );
                    ez  = Elem_Param ( j ).strain ( ( 6 * k - 3 ) );
                    exy = Elem_Param ( j ).strain ( ( 6 * k - 2 ) );
                    eyz = Elem_Param ( j ).strain ( ( 6 * k - 1 ) );
                    exz = Elem_Param ( j ).strain ( ( 6 * k - 0 ) );

                end                    
                    
                % Tens�o Von Mises do Ponto
                New_Max_Stress_Point = sqrt ( ( ( 1 / 2 ) * ( ( ( sx - sy )^2 ) + ( ( sy - sz )^2 ) + ( ( sx - sz )^2 ) ) ) +  ( 3 * ( ( sxy^2 ) + ( syz^2 ) + ( sxz^2 ) ) ) );

                % Deforma��o Von Mises do Ponto
                New_Max_Strain_Point = sqrt ( ( ( 1 / 2 ) * ( ( ( ex - ey )^2 ) + ( ( ey - ez )^2 ) + ( ( ex - ez )^2 ) ) ) +  ( 3 * ( ( exy^2 ) + ( eyz^2 ) + ( exz^2 ) ) ) );

                % M�xima Tens�o de Von Mises no Ponto
                New_Max_Stress = max ( New_Max_Stress , New_Max_Stress_Point );

                % M�xima Deforma��o de Von Mises no Ponto
                New_Max_Strain = max ( New_Max_Strain , New_Max_Strain_Point );
                    
            end
            
            % Aloca��o da Tens�o de Von Mises
            Elem_Param ( j ).max_stress = New_Max_Stress;
            
            % Aloca��o da Deforma��o de Von Mises
            Elem_Param ( j ).max_strain = New_Max_Strain;
            
        end
        
        % Tipo de Elemento -- 0D
        if ( strcmp ( Elem_Param ( j ).type , '0d' ) == 1 )
 
            % Aloca��o da Tens�o de Von Mises
            Elem_Param ( j ).max_stress = 0;
            
            % Aloca��o da Deforma��o de Von Mises
            Elem_Param ( j ).max_strain = 0;           
            
        end
        
        % Quantidade de N�s do Elemento
        [ ~ , Nnode ]  = size ( Elem_Param ( j ).node );
        
        % Varredura nos N�s
        for k = 1:Nnode
            
            % Aloca��o da Tens�o de Von Mises no N�
            Node_Param ( Elem_Param ( j ).node ( k ) ).max_stress = 0;
            
            % Aloca��o da Deforma��o de Von Mises no N�
            Node_Param ( Elem_Param ( j ).node ( k ) ).max_strain = 0;
            
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % INTERPOLA��O NOS N�S DO PROBLEMA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos Elementos do Problema
    for j = 1:Nelem
        
        % Quantidade de N�s do Elemento
        [ ~ , Nnode ]  = size ( Elem_Param ( j ).node );
        
        % Varredura nos N�s
        for k = 1:Nnode
           
            % Aloca��o da Tens�o de Von Mises no N�
            Node_Param ( Elem_Param ( j ).node ( k ) ).max_stress = max ( Elem_Param ( j ).max_stress , Node_Param ( Elem_Param ( j ).node ( k ) ).max_stress );
            
            % Aloca��o da Deforma��o de Von Mises no N�
            Node_Param ( Elem_Param ( j ).node ( k ) ).max_strain = max ( Elem_Param ( j ).max_strain , Node_Param ( Elem_Param ( j ).node ( k ) ).max_strain );
            
        end
    
    end
    
    % Aloca��o da Tens�o de Von Mises no N� Central
    Node_Param ( 1 ).max_stress = 0;

    % Aloca��o da Deforma��o de Von Mises no N� Central
    Node_Param ( 1 ).max_strain = 0;
    
end