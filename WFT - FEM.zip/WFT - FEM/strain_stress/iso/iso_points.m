%% C�lculo das Deforma��es e Tens�es nos Elementos

%% INPUT
% stress_point1     - Tens�o no Ponto 1 da estrutura 1D
% stress_point2     - Tens�o no Ponto 2 da estrutura 1D
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados dos Materiais do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Posi��o i do Vetor de For�as

%% OUPTUT
% stress_point1     - Tens�o no Ponto 1 da estrutura 1D
% stress_point2     - Tens�o no Ponto 2 da estrutura 1D

%% Declara��o da Fun��o de C�lculo das Deforma��es e Tens�es dos Elementos
function [ stress_point1 , stress_point2 , Node_Param , Elem_Param ] = iso_points ( stress_point1 , stress_point2 , Node_Param , Elem_Param , Mat_Param , Prop_Param , i )

    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % TENS�O NO ELEMENTO 1D %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura na Lista de Elementos
    for j = 1:Nelem
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % C�LCULO DAS DEFORMA��ES DO ELEMENTO BEAM2 %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Deforma��o do Elemento Beam2
        if ( strcmp ( Elem_Param ( j ).type , '1d' ) == 1 )            
            
            % Deforma��o e Tens�o -- Beam2
            [ ~ , Si ] = strain_stress_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , j );
            
            % Aloca��o nos Termos do Elemento
            Elem_Param ( j ).stress ( 1:24 ) = Si ( 1:24 );
            
            % Estrutura 1 e 3
            if ( Elem_Param ( j ).estr == 1 || Elem_Param ( j ).estr == 3 )
            
                % C�lculo da Deforma��o de Von Mises --- Nos Pontos A , B , C , D
                for k = 1:4
                    
                    % Primeira Tens�o
                    if ( k == 1 )
                        
                        % Tens�o no Primeiro Ponto
                        New_Max_Stress = Elem_Param ( j ).stress ( ( 6 * k - 5 ) );
                        
                    else

                        % Tens�o nos Pontos
                        sx  = Elem_Param ( j ).stress ( ( 6 * k - 5 ) );

                        % Tens�o Von Mises do Ponto
                        New_Max_Stress_Point = sx;

                        % M�xima Tens�o de Von Mises no Ponto
                        New_Max_Stress = max ( New_Max_Stress , New_Max_Stress_Point );
                        
                    end

                end

                % Aloca��o da Tens�o de Von Mises
                Elem_Param ( j ).max_stress = New_Max_Stress;
                
            end
            
            % Estrutura 2 e 4
            if ( Elem_Param ( j ).estr == 2 || Elem_Param ( j ).estr == 4 )
            
                % C�lculo da Deforma��o de Von Mises --- Nos Pontos A , B , C , D
                for k = 1:4
                    
                    % Primeira Tens�o
                    if ( k == 1 )
                        
                        % Tens�o no Primeiro Ponto
                        New_Max_Stress = Elem_Param ( j ).stress ( ( 6 * k - 4 ) );
                        
                    else

                        % Tens�o nos Pontos
                        sy  = Elem_Param ( j ).stress ( ( 6 * k - 4 ) );

                        % Tens�o Von Mises do Ponto
                        New_Max_Stress_Point = sy;

                        % M�xima Tens�o de Von Mises no Ponto
                        New_Max_Stress = max ( New_Max_Stress , New_Max_Stress_Point );
                        
                    end

                end

                % Aloca��o da Tens�o de Von Mises
                Elem_Param ( j ).max_stress = New_Max_Stress;
                
            end
            
            % Continuar
            continue;             
            
        end
       
    end
    
    %%%%%%%%%%%%%
    % ISOFLEX�O %
    %%%%%%%%%%%%%
    
    % Varredura na Lista de Elementos
    for j = 1:Nelem
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % TENS�ES PRESENTES NOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Elemento Beam2
        if ( strcmp ( Elem_Param ( j ).type , '1d' ) == 1 )
            
            % Verifica��o se o Elemento Anterior do tipo 2D
            if ( strcmp ( Elem_Param ( j - 1 ).type , '2d' ) == 1 )
                
                % Continuar programa
                continue;
                
            end
            
            % Verifica��o de Mudan�a no Tipo de Se��o
            if ( strcmp ( Elem_Param ( j ).part , 'B' ) == 1 && strcmp ( Elem_Param ( j - 1 ).part , 'A' ) == 1 )
                
                %%%%%%%%%%%%%%%%%%%%%%%
                % FOR�A X % MOMENTO X %
                %%%%%%%%%%%%%%%%%%%%%%%
                
                % For�a X -- Momento X
                if ( i == 1 || i == 4 )
                    
                    %%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA 2 e 4 %
                    %%%%%%%%%%%%%%%%%%%
                    
                    % Estrutura 2 e 4
                    if ( Elem_Param ( j ).estr == 2 || Elem_Param ( j ).estr == 4 )

                        % Tens�o no Ponto 1 -- Isoflex�o
                        stress_point1 ( i , Elem_Param ( j ).estr ) = Elem_Param ( j ).max_stress;
                        
                    end
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%
                % FOR�A Y % MOMENTO Y %
                %%%%%%%%%%%%%%%%%%%%%%%
                
                % For�a Y -- Momento Y
                if ( i == 2 || i == 5 )
                    
                    %%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA 1 e 3 %
                    %%%%%%%%%%%%%%%%%%%
                    
                    % Estrutura 1
                    if ( Elem_Param ( j ).estr == 1 || Elem_Param ( j ).estr == 3 )
                        
                        % Tens�o no Ponto 1 -- Isoflex�o
                        stress_point1 ( i , Elem_Param ( j ).estr ) = Elem_Param ( j ).max_stress;
                        
                    end
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%
                % FOR�A Z % MOMENTO Z %
                %%%%%%%%%%%%%%%%%%%%%%%
                
                % For�a Z -- Momento Z
                if ( i == 3  || i == 6 )
                    
                    %%%%%%%%%%%%%%%%%%%%
                    % TODAS ESTRUTURAS %
                    %%%%%%%%%%%%%%%%%%%%

                    % Tens�o no Ponto 1 -- Isoflex�o
                    stress_point1 ( i , Elem_Param ( j ).estr ) = Elem_Param ( j ).max_stress;

                end
                
            end
            
            % Verifica��o de Mudan�a no Tipo de Se��o
            if ( strcmp ( Elem_Param ( j ).part , 'C' ) == 1 && strcmp ( Elem_Param ( j - 1 ).part , 'B' ) == 1 )
               
                %%%%%%%%%%%%%%%%%%%%%%%
                % FOR�A X % MOMENTO X %
                %%%%%%%%%%%%%%%%%%%%%%%
                
                % For�a X -- Momento X
                if ( i == 1 || i == 4 )
                    
                    %%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA 2 e 4 %
                    %%%%%%%%%%%%%%%%%%%
                    
                    % Estrutura 2 e 4
                    if ( Elem_Param ( j - 1 ).estr == 2 || Elem_Param ( j - 1 ).estr == 4 )

                        % Tens�o no Ponto 1 -- Isoflex�o
                        stress_point2 ( i , Elem_Param ( j - 1 ).estr ) = Elem_Param ( j - 1 ).max_stress;
                        
                    end
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%
                % FOR�A Y % MOMENTO Y %
                %%%%%%%%%%%%%%%%%%%%%%%
                
                % For�a Y -- Momento Y
                if ( i == 2 || i == 5 )
                    
                    %%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA 1 e 3 %
                    %%%%%%%%%%%%%%%%%%%
                    
                    % Estrutura 1
                    if ( Elem_Param ( j - 1 ).estr == 1 || Elem_Param ( j - 1 ).estr == 3 )
                        
                        % Tens�o no Ponto 1 -- Isoflex�o
                        stress_point2 ( i , Elem_Param ( j - 1 ).estr ) = Elem_Param ( j - 1 ).max_stress;
                        
                    end
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%
                % FOR�A Z % MOMENTO Z %
                %%%%%%%%%%%%%%%%%%%%%%%
                
                % For�a Z -- Momento Z
                if ( i == 3  || i == 6 )
                    
                    %%%%%%%%%%%%%%%%%%%%
                    % TODAS ESTRUTURAS %
                    %%%%%%%%%%%%%%%%%%%%

                    % Tens�o no Ponto 1 -- Isoflex�o
                    stress_point2 ( i , Elem_Param ( j - 1 ).estr ) = Elem_Param ( j - 1 ).max_stress;

                end
                
            end
            
        end        
        
    end
    
end