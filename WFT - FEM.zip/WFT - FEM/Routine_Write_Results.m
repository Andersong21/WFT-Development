%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROTINA DE ESCRITA DOS RESULTADOS 1 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fechar todas as janelas
close all;

% Limpeza das Entrada
clc;

% Inicializa��o do Timer
tic;

% Formatar Sa�da
format short;

% Defini��o do Multicore    
p = gcp('nocreate');

% Processadores n�o Dispon�veis
if isempty( p )

    % N�mero de Processadores
    multicore = 1;

else

    % N�mero de Processadores
    multicore = p.NumWorkers;

end

%% ESTRUTURA DO PROBLEMA

% Vari�veis
% x ( 1  ) - Vari�vel b1      - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1      - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2      - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2      - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L       - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf      - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t       - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d       - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r       - Raio do Centro da C�lula de Carga    - [ mm ]

% Ponto de Estudo
Ps       = input ('Entre o ponto de estudo:');

%%%%%%%%%%%%%%%%%
% INICIALIZA��O %
%%%%%%%%%%%%%%%%%

% Lower Bound
LB       = [ 10 , 10 , 10 , 10 , 41 , 41 , 0.5 , 1.5 , 30 ];

% Upper Bound
UB       = [ 40 , 40 , 40 , 40 , 52 , 94 , 8.0 , 8.0 , 32 ];

% Inicializa��o do Timer
tic;
    
% Ponto de Estudo
x0 = transpose ( x0_points ( 1:end , Ps ) );

% Tamanho de Malha
N = 10;

% Fator de Correla��o
Fc = 1.5;

% Modelo Num�rico do Transdutor
[ ~ , Mat_Param , Prop_Param , Node_Param , Elem_Param , Mpc_Param , t2 ] = numerical_model( x0 , N , Fc , multicore );
        
% Determina��o do Tempo
fprintf('\nTotal time [ s ] : %g\n\n' , toc );

% Finaliza��o da An�lise
display ( '\nEnd' );
display ( 'Analysis Succesfully' );

% Finaliza��o do Di�rio
diary off;