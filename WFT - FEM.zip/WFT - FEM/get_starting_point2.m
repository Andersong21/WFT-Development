%% Defini��o do Ponto Inicial

%% INPUT
% nelem                      - Quantidade de Elementos    
% nsamples                   - Quantidade de Amostras
% LB                         - Lower Bound das Vari�veis
% UB                         - Upper Bound das Vari�veis
% multicore                  - Quantidade de N�cleos a Serem Utilizado

%% OUTPUT
% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]
% fn                         - Fun��es Objetivos dos Pontos Alcan�ados

%% Declara��o da Fun��o de Defini��o do Ponto Inicial
function [ xn , fn ] = get_starting_point2 ( nelem , nsamples , LB , UB , multicore )
    
    %%%%%%%%%%%%%%%%%%%%
    % N�MERO RAND�MICO %
    %%%%%%%%%%%%%%%%%%%%
    
    % Garantia de N�meros Rand�micos
    rng ( 'default' );    
   
    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Vetor de N�meros Rand�micos
    xn = zeros ( nsamples , length ( LB ) );
    
    % Inicializa��o da Fun��o Objetivo dos Pontos Rand�micos
    fn = zeros ( nsamples , 1 );
    
    %%%%%%%%%%%%%
    % ITERA��ES %
    %%%%%%%%%%%%%
    
    % Inicializa��o do Contador
    cont = 1;
    
    % Itera��es do Problema    
    while ( cont <= nsamples )
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % DISTRIBUI��O DAS VARI�VEIS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Distribui��o Uniforme        
        xn ( cont , 1:end ) = LB + ( rand ( 1 , length ( LB ) ) .* ( UB - LB ) );             
       
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        % VALIDA��ES DO PROBLEMA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%
            
        % Display Mensagem
        fprintf( 'Point %d - Random Vector OK \n' , cont );   

        % Determina��o da Fun��o Objetivo
        [ f ] = objective_function( xn ( cont , 1:end ) , nelem , multicore );

        % Aloca��o da Fun��o Objetivo
        fn ( cont , 1 ) = f;

        % Incremento do Contador dos Pontos
        cont = cont + 1;      
        
    end
        
end