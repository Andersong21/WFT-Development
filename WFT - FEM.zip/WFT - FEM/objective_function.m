%% Defini��o da Fun��o Objetivo

% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]
% n                          - Quantidade de Elementos              - [ -  ]
% CS                         - Coeficiente de Seguran�a             - [ -  ]
% multicore                  - Quantidade de N�cleos

%% Declara��o da Fun��o Objetivo
function [ f ] = objective_function( x , n , CS , multicore )

    %%%%%%%%%%%%%
    % VARI�VEIS %
    %%%%%%%%%%%%%
    
    % Defini��o das Vari�veis
    b1 = x ( 1 , 1 );
    h1 = x ( 1 , 2 );
    b2 = x ( 1 , 3 );
    h2 = x ( 1 , 4 );
    L  = x ( 1 , 5 );
    Lf = x ( 1 , 6 );
    t  = x ( 1 , 7 );
    d  = x ( 1 , 8 );
    r  = x ( 1 , 9 );
    P  = 0.5;
    r1 = 55;
    d1 = 25;
    d2 = 8;

    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno do Material do Sistema
    [ Mat_Param ] = get_mat ();
    
    % Retorno da Densidade do Material
    rho = Mat_Param ( 1 ).rho;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DAS PROPRIEDADES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    % Retorno das Propriedades do Sistema
    [ Prop_Param ] = get_prop ( t );
    
    %%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DO MPC %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Retorno dos Mpcs do Sistema
    [ Mpc_Param ] = get_mpc ();    
  
    %%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DE MALHA %
    %%%%%%%%%%%%%%%%%%%%%%%
      
    % Retorno do Gerador de Malha
    [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = get_mesh ( b1 , h1 , b2 , h2 , L , Lf , t , d , r , n , Prop_Param , Mpc_Param , Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MONTAGEM DA MATRIZ DE RIGIDEZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % Retorno da Matriz de Rigidez do Problema
    [ K ] = get_matrix_K ( Node_Param , Elem_Param , Mat_Param , Prop_Param , Mpc_Param , multicore );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COMPLIANCE NORMALIZADA DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Compliance Normalizada da C�lula de Carga
    Comp_N_LoadCell = zeros ( 6 , 6 );
    
    % Varredura nas 6 dire��es
    for i = 1:6
        
        %%%%%%%%%%%%%%%%%%%
        % VETOR DE FOR�AS %
        %%%%%%%%%%%%%%%%%%%

        % Retorno do Vetor de For�as do Problema
        [ F ] = get_vector_F ( Node_Param , i );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % SOLU��O DO SISTEMA LINEAR %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%        

        % Retorno do Vetor de Deslocamentos
        [ Node_Param ] = get_vector_X ( K , F , Node_Param );        
            
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % DEFORMA��O C�LULA DE CARGA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Fun��o de C�lculo das Deforma��es no Ponto de Localiza��o do Gaige
        [ Comp_N_LoadCell ] = get_comp_N_loadcell ( Comp_N_LoadCell , L , t , r , P , Node_Param , Elem_Param , Prop_Param , i );
        
    end    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SENSIBILIDADE DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
       
    % Fun��o de C�lculo das Sensibilidades dos Canais da C�lula de Carga
    [ Sens_LoadCell ] = get_sens_loadcell ( Comp_N_LoadCell );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % FUN��O OTIMIZA��O % MASSA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Peso da Fun��o de Massa
    w1 = 0.0;
    
    % Minimiza��o da Massa
    f1 ( 1 ) = - 1000 * ( h1 * ( power ( d1 , 2 ) * pi + 4 * ( power ( d2 , 2 ) * pi - 4 * power ( r1 , 2 ) - pi * ( r + 2 * r1 ) * ( r + 2 * r1 - 2 * sqrt ( 2 ) * r1 ) ) ) * rho ) / 4. + b1 * h1 * rho * ( 1.2 * L - 0.6 * t ) - ...
               2.2399999999999998  * ( 1.*b1 + 0.4285714285714286 * b2 - 2.857142857142857 * d ) * ( d - 0.35 * h1 - 0.15 * h2 ) * rho * ( 1.*L - 0.5*t ) + ...
               0.10800000000000003 * ( 1.*b1 + 2.333333333333333  * b2 ) * ( 1.*h1 + 2.333333333333333 * h2 ) * rho * ( 1.*L - 0.5 * t ) + 4 * h2 * Lf * rho * t;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % FUN��O OTIMIZA��O % SENSIBILIDADE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Peso da Fun��o de Sensibilidade
    w2 = 1.0;
    
    % Maximiza��o das Sensibilidades
    f1 ( 2 ) = Sens_LoadCell ( 1 );
    f1 ( 3 ) = Sens_LoadCell ( 2 );
    f1 ( 4 ) = Sens_LoadCell ( 3 );
    f1 ( 5 ) = Sens_LoadCell ( 4 );
    f1 ( 6 ) = Sens_LoadCell ( 5 );
    f1 ( 7 ) = Sens_LoadCell ( 6 );    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % FUN��O OTIMIZA��O % GERAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Fun��o Objetivo
    f = ( w1 * f1 ( 1 ) ) - ( w2 * ( f1 ( 2 ) + f1 ( 3 ) + f1 ( 4 ) + f1 ( 5 ) + f1 ( 6 ) + f1 ( 7 ) ) );    
        
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % LIMPEZA DAS VARI�VEIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Limpeza das Estruturas
    clearvars Node_Param;
    clearvars Elem_Param;
    clearvars Prop_Param;
    clearvars Mat_Param;
    clearvars Mpc_Param;

end