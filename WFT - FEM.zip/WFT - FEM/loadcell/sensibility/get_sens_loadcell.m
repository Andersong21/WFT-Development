%% Retorno do Vetor de Sensibilidades dos Canais da C�lula de Carga

%% INPUT
% Comp_N_LoadCell   - Matriz de Compliance Normalizada da C�lula de Carga

%% OUPTUT
% Sen_LoadCell      - Vetor de Sensibilidade dos Canais da C�lula de Carga

%% Declara��o da Fun��o de Retorno Vetor de Sensibilidades dos Canais da C�lula de Carga
function [ Sens_LoadCell ] = get_sens_loadcell ( Comp_N_LoadCell )

    % Inicializa��o do Tempo
    t1 = cputime;
   
    % Determina��o das Sensibilidades dos Canais da C�lula de Carga -- Fx
    Sens_LoadCell ( 1 ) = norm ( Comp_N_LoadCell ( : , 1 ) ) * 2.1 * 1000; 
    
    % Determina��o das Sensibilidades dos Canais da C�lula de Carga -- Fy
    Sens_LoadCell ( 2 ) = norm ( Comp_N_LoadCell ( : , 2 ) ) * 2.1 * 1000; 
    
    % Determina��o das Sensibilidades dos Canais da C�lula de Carga -- Fz
    Sens_LoadCell ( 3 ) = norm ( Comp_N_LoadCell ( : , 3 ) ) * 2.1 * 1000; 
    
    % Determina��o das Sensibilidades dos Canais da C�lula de Carga -- Mx
    Sens_LoadCell ( 4 ) = norm ( Comp_N_LoadCell ( : , 4 ) ) * 2.1 * 1000; 
    
    % Determina��o das Sensibilidades dos Canais da C�lula de Carga -- My
    Sens_LoadCell ( 5 ) = norm ( Comp_N_LoadCell ( : , 5 ) ) * 2.1 * 1000; 
    
    % Determina��o das Sensibilidades dos Canais da C�lula de Carga -- Mz
    Sens_LoadCell ( 6 ) = norm ( Comp_N_LoadCell ( : , 6 ) ) * 2.1 * 1000;

    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_sens_loadcell : %2.2f s.\n', t2 );
    
end