%% Retorno da Matriz de Calibra��o da C�lula de Carga

%% INPUT
% Comp_LoadCell     - Matriz de Compliance da C�lula de Carga

%% OUPTUT
% Calib_LoadCell   - Matriz de Calibra��o da C�lula de Carga

%% Declara��o da Fun��o dos Pontos da Matriz de Compliance da C�lula de Carga
function [ Calib_LoadCell ] = get_calib_loadcell ( Comp_LoadCell )

    % Inicializa��o do Tempo
    t1 = cputime;
       
    % Determina��o da Matriz de Calibra��o da C�lula de Carga
    Calib_LoadCell = inv ( Comp_LoadCell );

    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_calib_loadcell : %2.2f s.\n', t2 );
    
end