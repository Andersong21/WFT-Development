%% Retorno de Localiza��o do Id do Elemento na Estrutura Deform�vel j

%% INPUT
% L                 - Comprimento L da Estrutura Deform�vel
% t                 - Espessura da Placa
% r                 - Raio do Centro da C�lulad de Carga
% P                 - Posi��o do Gaige em Rela��o a Estrutura Deform�vel
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% j                 - Estrutura Deform�vel j

%% OUPTUT
% Elem_Id           - Id do Elemento

%% Declara��o da Fun��o do Retorno do Vetor de Deforma��es da C�lula de Carga
function [ Elem_Id ] = find_element_id ( L , t , r , P , Node_Param , Elem_Param , j )

    % Inicializa��o do Tempo
    t1 = cputime;    
    
    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id;
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 1 %
    %%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%
    % POSI��O P %
    %%%%%%%%%%%%%
    
    % Posi��o P    
    Px = r + ( P * ( L - ( t / 2 ) ) );
    Py = 0;
    Pz = 0;   
    
    % Estrutura 1
    if ( j == 1 )
       
        % Varredura nos Elementos
        for k = 1:Nelem
           
            % Verifica��o se o Elemento n�o � tipo 1D
            if ( strcmp ( Elem_Param ( k ).type , '2d' ) == 1 || strcmp ( Elem_Param ( k ).type , '0d' ) )
                
                % Continuar
                continue;
                
            end
            
            % Verifica��o se o Elemento n�o da Estrutura j
            if ( Elem_Param ( k ).estr ~= j )
                
                % Continuar
                continue;
                
            end
            
            %%%%%%%%
            % N� 1 %
            %%%%%%%%            
            
            % Id do N� 1 do Elemento
            IdNode1 = Elem_Param ( k ).node ( 1 );            
                        
            % Coordenada X do N� 1
            x1 = Node_Param ( IdNode1 ).coord ( 1 );
            
            % Coordenada Y do N� 1
            y1 = Node_Param ( IdNode1 ).coord ( 2 );
            
            % Coordenada Z do N� 1
            z1 = Node_Param ( IdNode1 ).coord ( 3 );
            
            %%%%%%%%
            % N� 2 %
            %%%%%%%% 
            
            % Id do N� 2 do Elemento
            IdNode2 = Elem_Param ( k ).node ( 2 );
            
            % Coordenada X do N� 2
            x2 = Node_Param ( IdNode2 ).coord ( 1 );
            
            % Coordenada Y do N� 2
            y2 = Node_Param ( IdNode2 ).coord ( 2 );
            
            % Coordenada Z do N� 2
            z2 = Node_Param ( IdNode2 ).coord ( 3 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D1 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - Node 1
            d1 ( 1 ) = x2 - x1;
            d1 ( 2 ) = y2 - y1;
            d1 ( 3 ) = z2 - z1;
            
            % Normaliza��o do Vetor d1
            d1 = d1 / norm ( d1 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D2 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - dP
            d2 ( 1 ) = x2 - Px;
            d2 ( 2 ) = y2 - Py;
            d2 ( 3 ) = z2 - Pz;
            
            % Normaliza��o do Vetor d2
            d2 = d2 / norm ( d2 );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % VERIFICA��O DO PONTO P %
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Verifica��o do Ponto P dentro do Elemento
            if ( dot ( d1 , d2 ) == 1 )
               
                % Defini��o do Id do Elemento
                Elem_Id = k;
                
                % Quebra do C�digo
                break;                
                
            end           
            
        end

    end
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 2 %
    %%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%
    % POSI��O P %
    %%%%%%%%%%%%%
    
    % Posi��o P    
    Px = 0;
    Py = r + ( P * ( L - ( t / 2 ) ) );
    Pz = 0;   
    
    % Estrutura 2
    if ( j == 2 )
       
        % Varredura nos Elementos
        for k = 1:Nelem
           
            % Verifica��o se o Elemento n�o � tipo 1D
            if ( strcmp ( Elem_Param ( k ).type , '2d' ) == 1 || strcmp ( Elem_Param ( k ).type , '0d' ) )
                
                % Continuar
                continue;
                
            end
            
            % Verifica��o se o Elemento n�o da Estrutura j
            if ( Elem_Param ( k ).estr ~= j )
                
                % Continuar
                continue;
                
            end
            
            %%%%%%%%
            % N� 1 %
            %%%%%%%%            
            
            % Id do N� 1 do Elemento
            IdNode1 = Elem_Param ( k ).node ( 1 );            
                        
            % Coordenada X do N� 1
            x1 = Node_Param ( IdNode1 ).coord ( 1 );
            
            % Coordenada Y do N� 1
            y1 = Node_Param ( IdNode1 ).coord ( 2 );
            
            % Coordenada Z do N� 1
            z1 = Node_Param ( IdNode1 ).coord ( 3 );
            
            %%%%%%%%
            % N� 2 %
            %%%%%%%% 
            
            % Id do N� 2 do Elemento
            IdNode2 = Elem_Param ( k ).node ( 2 );
            
            % Coordenada X do N� 2
            x2 = Node_Param ( IdNode2 ).coord ( 1 );
            
            % Coordenada Y do N� 2
            y2 = Node_Param ( IdNode2 ).coord ( 2 );
            
            % Coordenada Z do N� 2
            z2 = Node_Param ( IdNode2 ).coord ( 3 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D1 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - Node 1
            d1 ( 1 ) = x2 - x1;
            d1 ( 2 ) = y2 - y1;
            d1 ( 3 ) = z2 - z1;
            
            % Normaliza��o do Vetor d1
            d1 = d1 / norm ( d1 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D2 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - dP
            d2 ( 1 ) = x2 - Px;
            d2 ( 2 ) = y2 - Py;
            d2 ( 3 ) = z2 - Pz;
            
            % Normaliza��o do Vetor d2
            d2 = d2 / norm ( d2 );

            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % VERIFICA��O DO PONTO P %
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Verifica��o do Ponto P dentro do Elemento
            if ( dot ( d1 , d2 ) == 1 )
               
                % Defini��o do Id do Elemento
                Elem_Id = k;
                
                % Quebra do C�digo
                break;                
                
            end           
            
        end
        
    end
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 3 %
    %%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%
    % POSI��O P %
    %%%%%%%%%%%%%
    
    % Posi��o P    
    Px = - ( r + ( P * ( L - ( t / 2 ) ) ) );
    Py = 0;
    Pz = 0;   
    
    % Estrutura 3
    if ( j == 3 )
       
        % Varredura nos Elementos
        for k = 1:Nelem
           
            % Verifica��o se o Elemento n�o � tipo 1D
            if ( strcmp ( Elem_Param ( k ).type , '2d' ) == 1 || strcmp ( Elem_Param ( k ).type , '0d' ) )
                
                % Continuar
                continue;
                
            end
            
            % Verifica��o se o Elemento n�o da Estrutura j
            if ( Elem_Param ( k ).estr ~= j )
                
                % Continuar
                continue;
                
            end
            
            %%%%%%%%
            % N� 1 %
            %%%%%%%%            
            
            % Id do N� 1 do Elemento
            IdNode1 = Elem_Param ( k ).node ( 1 );            
                        
            % Coordenada X do N� 1
            x1 = Node_Param ( IdNode1 ).coord ( 1 );
            
            % Coordenada Y do N� 1
            y1 = Node_Param ( IdNode1 ).coord ( 2 );
            
            % Coordenada Z do N� 1
            z1 = Node_Param ( IdNode1 ).coord ( 3 );
            
            %%%%%%%%
            % N� 2 %
            %%%%%%%% 
            
            % Id do N� 2 do Elemento
            IdNode2 = Elem_Param ( k ).node ( 2 );
            
            % Coordenada X do N� 2
            x2 = Node_Param ( IdNode2 ).coord ( 1 );
            
            % Coordenada Y do N� 2
            y2 = Node_Param ( IdNode2 ).coord ( 2 );
            
            % Coordenada Z do N� 2
            z2 = Node_Param ( IdNode2 ).coord ( 3 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D1 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - Node 1
            d1 ( 1 ) = x2 - x1;
            d1 ( 2 ) = y2 - y1;
            d1 ( 3 ) = z2 - z1;
            
            % Normaliza��o do Vetor d1
            d1 = d1 / norm ( d1 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D2 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - dP
            d2 ( 1 ) = x2 - Px;
            d2 ( 2 ) = y2 - Py;
            d2 ( 3 ) = z2 - Pz;
            
            % Normaliza��o do Vetor d2
            d2 = d2 / norm ( d2 );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % VERIFICA��O DO PONTO P %
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Verifica��o do Ponto P dentro do Elemento
            if ( dot ( d1 , d2 ) == 1 )
               
                % Defini��o do Id do Elemento
                Elem_Id = k;
                
                % Quebra do C�digo
                break;                
                
            end           
            
        end
        
    end
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 4 %
    %%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%
    % POSI��O P %
    %%%%%%%%%%%%%
    
    % Posi��o P    
    Px = 0;
    Py = - ( r + ( P * ( L - ( t / 2 ) ) ) );
    Pz = 0;   
    
    % Estrutura 4
    if ( j == 4 )
       
        % Varredura nos Elementos
        for k = 1:Nelem
           
            % Verifica��o se o Elemento n�o � tipo 1D
            if ( strcmp ( Elem_Param ( k ).type , '2d' ) == 1 || strcmp ( Elem_Param ( k ).type , '0d' ) )
                
                % Continuar
                continue;
                
            end
            
            % Verifica��o se o Elemento n�o da Estrutura j
            if ( Elem_Param ( k ).estr ~= j )
                
                % Continuar
                continue;
                
            end
            
            %%%%%%%%
            % N� 1 %
            %%%%%%%%            
            
            % Id do N� 1 do Elemento
            IdNode1 = Elem_Param ( k ).node ( 1 );            
                        
            % Coordenada X do N� 1
            x1 = Node_Param ( IdNode1 ).coord ( 1 );
            
            % Coordenada Y do N� 1
            y1 = Node_Param ( IdNode1 ).coord ( 2 );
            
            % Coordenada Z do N� 1
            z1 = Node_Param ( IdNode1 ).coord ( 3 );
            
            %%%%%%%%
            % N� 2 %
            %%%%%%%% 
            
            % Id do N� 2 do Elemento
            IdNode2 = Elem_Param ( k ).node ( 2 );
            
            % Coordenada X do N� 2
            x2 = Node_Param ( IdNode2 ).coord ( 1 );
            
            % Coordenada Y do N� 2
            y2 = Node_Param ( IdNode2 ).coord ( 2 );
            
            % Coordenada Z do N� 2
            z2 = Node_Param ( IdNode2 ).coord ( 3 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D1 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - Node 1
            d1 ( 1 ) = x2 - x1;
            d1 ( 2 ) = y2 - y1;
            d1 ( 3 ) = z2 - z1;
            
            % Normaliza��o do Vetor d1
            d1 = d1 / norm ( d1 );
            
            %%%%%%%%%%%%%%%%%%%%%%
            % VETOR DIST�NCIA D2 %
            %%%%%%%%%%%%%%%%%%%%%%
            
            % Vetor de Dist�ncia Node 2 - dP
            d2 ( 1 ) = x2 - Px;
            d2 ( 2 ) = y2 - Py;
            d2 ( 3 ) = z2 - Pz;
            
            % Normaliza��o do Vetor d2
            d2 = d2 / norm ( d2 );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % VERIFICA��O DO PONTO P %
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Verifica��o do Ponto P dentro do Elemento
            if ( dot ( d1 , d2 ) == 1 )
               
                % Defini��o do Id do Elemento
                Elem_Id = k;
                
                % Quebra do C�digo
                break;                
                
            end           
            
        end

    end    
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('find_element_id : %2.2f s.\n', t2 );
    
end