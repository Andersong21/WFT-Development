%% Retorno do Vetor de For�as Lidas dos Canais da C�lula de Carga

%% INPUT
% Calib_LoadCell   - Matriz de Calibra��o da C�lula de Carga
% Strain_Vector_FB - Vetor de Deforma��es da C�lula de Carga -- Com Ponte

%% OUPTUT
% Force_LoadCell   - Vetor de For�as dos Canais Lidos da C�lula de Carga

%% Declara��o da Fun��o de Retorno Vetor de For�as Lidos nos Canais da C�lula de Carga
function [ Force_LoadCell ] = get_force_loadcell ( Comp_LoadCell , Strain_Vector_FB )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Determina��o do Vetor de For�as Lidos nos Canais da C�lula de Carga
    Force_LoadCell = Comp_LoadCell * Strain_Vector_FB;

    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_force_loadcell : %2.2f s.\n', t2 );
    
end