%% Retorno do Vetor de Crosstalking dos Canais da C�lula de Carga

%% INPUT
% Comp_N_LoadCell   - Matriz de Compliance Normalizada da C�lula de Carga

%% OUPTUT
% Cross_LoadCell    - Vetor de Crosstalking dos Canais da C�lula de Carga

%% Declara��o da Fun��o de Retorno Vetor de Crosstalking dos Canais da C�lula de Carga
function [ Cross_LoadCell ] = get_cross_loadcell ( Comp_N_LoadCell )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Determina��o do �ndice de CrossTalking da C�lula de Carga
    for i = 1:6
       
        % Determina��o da Norma da Coluna
        Norma = norm ( Comp_N_LoadCell ( : , i ) );
        
        % Varredura na Linha da Matriz de Compliance Normalizada
        for j = 1:6
           
            % Determina��o do CrossTalking da C�lula de Carga
            Cross_LoadCell ( j , i ) = Comp_N_LoadCell ( j , i ) / Norma;
            
        end            
        
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_cross_loadcell : %2.2f s.\n', t2 );
    
end