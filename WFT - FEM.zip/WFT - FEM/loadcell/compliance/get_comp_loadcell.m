%% Retorno dos Pontos da Matriz de Compliance da C�lula de Carga

%% INPUT
% Comp_LoadCell     - Matriz de Compliance da C�lula de Carga

%% OUPTUT
% Comp_N_LoadCell   - Matriz de Compliance Normalizada da C�lula de Carga

%% Declara��o da Fun��o Retorno dos Pontos da Matriz de Compliance da C�lula de Carga
function [ Comp_LoadCell ] = get_comp_loadcell ( Comp_N_LoadCell )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Compliance Unit�rio da C�lula de Carga -- Fx
    Comp_LoadCell ( : , 1 ) = Comp_N_LoadCell ( : , 1 ) / 5500; 
    
    % Compliance Unit�rio da C�lula de Carga -- Fy
    Comp_LoadCell ( : , 2 ) = Comp_N_LoadCell ( : , 2 ) / 4268;
    
    % Compliance Unit�rio da C�lula de Carga -- Fz
    Comp_LoadCell ( : , 3 ) = Comp_N_LoadCell ( : , 3 ) / 2132;
    
    % Compliance Unit�rio da C�lula de Carga -- Mx
    Comp_LoadCell ( : , 4 ) = Comp_N_LoadCell ( : , 4 ) / 50000; 
    
    % Compliance Unit�rio da C�lula de Carga -- My
    Comp_LoadCell ( : , 5 ) = Comp_N_LoadCell ( : , 5 ) / 50000;
    
    % Compliance Unit�rio da C�lula de Carga -- Mz
    Comp_LoadCell ( : , 6 ) = Comp_N_LoadCell ( : , 6 ) / 1485000;
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_comp_loadcell : %2.2f s.\n', t2 );
    
end