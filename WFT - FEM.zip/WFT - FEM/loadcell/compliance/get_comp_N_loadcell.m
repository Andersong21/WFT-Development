%% Retorno dos Pontos da Matriz de Compliance Normalizada da C�lula de Carga

%% INPUT
% Comp_N_LoadCell   - Matriz de Compliance Normalizada da C�lula de Carga ( i )
% L                 - Comprimento L da Estrutura Deform�vel
% t                 - Espessura da Placa
% r                 - Raio do Centro da C�lulad de Carga
% P                 - Posi��o do Gaige em Rela��o a Estrutura Deform�vel
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% i                 - Linha de Aloca��o na Matriz de Deforma��es

%% OUPTUT
% Comp_N_LoadCell   - Matriz de Compliance Normalizada da C�lula de Carga ( i )

%% Declara��o da Fun��o Retorno dos Pontos da Matriz de Compliance Normalizada da C�lula de Carga
function [ Comp_N_LoadCell ] = get_comp_N_loadcell ( Comp_N_LoadCell , L , t , r , P , Node_Param , Elem_Param , Prop_Param , i )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Retorno do Vetor de Deforma��es -- Sem Ponte
    [ Strain_Vector_NB ] = strain_vector_NB ( L , t , r , P , Node_Param , Elem_Param , Prop_Param );
    
    % Retorno do Vetor de Deforma��es -- Com Ponte
    [ Strain_Vector_FB ] = strain_vector_FB ( Strain_Vector_NB );

    % Aloca��o na Matriz de Compliance da C�lula de Carga
    for j = 1:6
       
        % Aloca��o na Matriz de Deforma��es da C�lula de Carga
        Comp_N_LoadCell ( j , i ) = Strain_Vector_FB ( j , 1 );
        
    end 
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_comp_N_loadcell : %2.2f s.\n', t2 );
    
end