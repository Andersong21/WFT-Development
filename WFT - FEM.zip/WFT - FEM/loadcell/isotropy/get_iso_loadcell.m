%% Retorno da Isotropia da C�lula de Carga

%% INPUT
% Iso_LoadCell      - Isotropia da C�lula de Carga

%% OUPTUT
% Comp_N_LoadCell   - Matriz de Compliance Normalizada da C�lula de Carga

%% Declara��o da Fun��o Retorno da Isotropia da C�lula de Carga
function [ Iso_LoadCell ] = get_iso_loadcell ( Comp_N_LoadCell )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Determina��o dos Autovalores da Matriz de Compliance Normalizada
    EIG = eig ( Comp_N_LoadCell );
    
    % Determina��o da Isotropia da C�lula de Carga
    Iso_LoadCell = max ( EIG ) / min ( EIG );

    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_iso_loadcell : %2.2f s.\n', t2 );
    
end