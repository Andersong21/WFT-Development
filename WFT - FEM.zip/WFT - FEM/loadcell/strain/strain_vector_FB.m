%% Retorno do Vetor de Deforma��es em Ponte Completa da C�lula de Carga

%% INPUT - Com Deforma��es Sem Ponte

%% OUPTUT - Com Deforma��es em Ponte
% Strain_Vector_FB  - Vetor de Deforma��es da C�lula de Carga -- Com Ponte

%% Declara��o da Fun��o do Retorno do Vetor de Deforma��es em Ponte Completa da C�lula de Carga
function [ Strain_Vector_FB ] = strain_vector_FB ( Strain_Vector_NB )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Determina��o dos Valores das Deforma��es Nos Canais --- Fx
    Strain_Vector_FB ( 1 , 1 ) = ( 1 / 4 ) * ( Strain_Vector_NB ( 1 , 1  ) - Strain_Vector_NB ( 1 , 2  ) + Strain_Vector_NB ( 1 , 3  ) - Strain_Vector_NB ( 1 , 4  ) );
    
    % Determina��o dos Valores das Deforma��es Nos Canais --- Fy
    Strain_Vector_FB ( 2 , 1 ) = ( 1 / 4 ) * ( Strain_Vector_NB ( 1 , 5  ) - Strain_Vector_NB ( 1 , 6  ) + Strain_Vector_NB ( 1 , 7  ) - Strain_Vector_NB ( 1 , 8  ) );
    
    % Determina��o dos Valores das Deforma��es Nos Canais --- Fz
    Strain_Vector_FB ( 3 , 1 ) = ( 1 / 4 ) * ( Strain_Vector_NB ( 1 , 9  ) - Strain_Vector_NB ( 1 , 10 ) + Strain_Vector_NB ( 1 , 11 ) - Strain_Vector_NB ( 1 , 12 ) );
    
    % Determina��o dos Valores das Deforma��es Nos Canais --- Mx
    Strain_Vector_FB ( 4 , 1 ) = ( 1 / 4 ) * ( Strain_Vector_NB ( 1 , 13 ) - Strain_Vector_NB ( 1 , 14 ) + Strain_Vector_NB ( 1 , 15 ) - Strain_Vector_NB ( 1 , 16 ) );
    
    % Determina��o dos Valores das Deforma��es Nos Canais --- My
    Strain_Vector_FB ( 5 , 1 ) = ( 1 / 4 ) * ( Strain_Vector_NB ( 1 , 17 ) - Strain_Vector_NB ( 1 , 18 ) + Strain_Vector_NB ( 1 , 19 ) - Strain_Vector_NB ( 1 , 20 ) );
    
    % Determina��o dos Valores das Deforma��es Nos Canais --- Mz
    Strain_Vector_FB ( 6 , 1 ) = ( 1 / 4 ) * ( Strain_Vector_NB ( 1 , 21 ) - Strain_Vector_NB ( 1 , 22 ) + Strain_Vector_NB ( 1 , 23 ) - Strain_Vector_NB ( 1 , 24 ) );
     
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('strain_vector_NB : %2.2f s.\n', t2 );
    
end