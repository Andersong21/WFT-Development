%% Retorno do Vetor de Deforma��es do Elemento na Posi��o P

%% INPUT
% L                 - Comprimento L da Estrutura Deform�vel
% t                 - Espessura da Placa
% r                 - Raio do Centro da C�lulad de Carga
% P                 - Posi��o do Gaige em Rela��o a Estrutura Deform�vel
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema
% j                 - Estrutura Deform�vel j
% Elem_Id           - Id do Elemento

%% OUPTUT
% vector_strain_j   - Vetor de Deforma��es do Elemento na Posi��o J na estrutura J

%% Declara��o da Fun��o do Retorno do Vetor de Deforma��es do Elemento na Posi��o P
function [ vector_strain_j ] = strain_element_id ( L , t , r , P , Node_Param , Elem_Param , Prop_Param , j , Elem_Id )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 1 %
    %%%%%%%%%%%%%%%
    
    % Estrutura 1
    if ( j == 1 )

        %%%%%%%%%%%%%
        % POSI��O P %
        %%%%%%%%%%%%%

        % Posi��o P    
        Pg ( 1 ) = r + ( P * ( L - ( t / 2 ) ) );
        Pg ( 2 ) = 0;
        Pg ( 3 ) = 0;      
                
    end
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 2 %
    %%%%%%%%%%%%%%%
    
    % Estrutura 2
    if ( j == 2 )

        %%%%%%%%%%%%%
        % POSI��O P %
        %%%%%%%%%%%%%

        % Posi��o P    
        Pg ( 1 ) = 0;
        Pg ( 2 ) = r + ( P * ( L - ( t / 2 ) ) );
        Pg ( 3 ) = 0; 
        
    end
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 3 %
    %%%%%%%%%%%%%%%
    
    % Estrutura 3
    if ( j == 3 )

        %%%%%%%%%%%%%
        % POSI��O P %
        %%%%%%%%%%%%%

        % Posi��o P    
        Pg ( 1 ) = - ( r + ( P * ( L - ( t / 2 ) ) ) );
        Pg ( 2 ) = 0;
        Pg ( 3 ) = 0;
        
    end
    
    %%%%%%%%%%%%%%%
    % ESTRUTURA 4 %
    %%%%%%%%%%%%%%%
    
    % Estrutura 4
    if ( j == 4 )

        %%%%%%%%%%%%%
        % POSI��O P %
        %%%%%%%%%%%%%

        % Posi��o P    
        Pg ( 1 ) = 0;
        Pg ( 2 ) = - ( r + ( P * ( L - ( t / 2 ) ) ) );
        Pg ( 3 ) = 0; 
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz das Posi��es Nodais Globais do Elemento
    [ Cg ] = matrix_Cg_beam2 ( Node_Param , Elem_Param , Elem_Id );
    
    %%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��ES INICIAIS %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno das Defini��es Iniciais da Propriedade
    [ b , h ] = get_section_param ( Elem_Param , Prop_Param , Elem_Id );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE TRANSFORMA��O DE COORDENADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Transforma��o de Coordenada
    [ R ] = matrix_R_beam2 ( Cg );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DAS POSI��ES NODAIS LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz das Posi��es Nodais Locais do Elemento
    [ Cl ] = matrix_Cl_beam2 ( R , Cg );
    
    %%%%%%%%%%%%%%%%%%%
    % POSI��O P LOCAL %
    %%%%%%%%%%%%%%%%%%%

    % C�lculo da Posi��o P Local do Gaige
    Pl = transpose ( R ( 1:3 , 1:3 ) ) * transpose ( Pg );
    
    %%%%%%%%%%%%%%%%%%%%%
    % POSI��O P NATURAL %
    %%%%%%%%%%%%%%%%%%%%%
    
    % C�lculo da Posi��o P Natural do Gaige no Elemento    
    x = ( Cl ( 2 , 1 ) - Cl ( 1 , 1 ) ) / 2.0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno do Vetor de Deslocamentos Globais do Elemento
    [ Ug ] = vector_Ug_beam2 ( Node_Param , Elem_Param , Elem_Id );    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DESLOCAMENTOS NODAIS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno do Vetor de Deslocamentos Locais do Elemento
    [ Ul ] = vector_Ul_beam2 ( R , Ug );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MATRIZ DE CORRELA��O DEFORMA��O / DESLOCAMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno da Matriz de Correla��o Deforma��o / Deslocamento
    [ Ba , Bfz , Bfy , Bt ] = matrix_B_beam2 ( x , Cl );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES LOCAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Deforma��es Locais do Elemento 
    [ ElA , ElB , ElC , ElD , ElE , ElF , ElG , ElH , ElI , ElJ , ElK , ElL ] = vector_El_beam2 ( Ba , Bfz , Bfy , Bt , Ul , b , h , 'E' );
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VETOR DE DEFORMA��ES GLOBAIS DO ELEMENTO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Retorno dos Vetores de Deforma��es Globais do Elemento
    [ EgA , EgB , EgC , EgD , EgE , EgF , EgG , EgH , EgI , EgJ , EgK , EgL ] = vector_Eg_beam2 ( ElA , ElB , ElC , ElD , ElE , ElF , ElG , ElH , ElI , ElJ , ElK , ElL , R );
    
    % Retorno da Estrutura de Deforma��es do Elemento
    vector_strain_j = [ EgA EgB EgC EgD EgE EgF EgG EgH EgI EgJ EgK EgL ];
   
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('strain_element_id : %2.2f s.\n', t2 );
    
end