%% Retorno do Vetor de Deforma��es da C�lula de Carga -- Sem Ponte

%% INPUT - Sem Deforma��o
% L                 - Comprimento da Estrutura
% t                 - Espessura da Placa
% r                 - Raio do Centro da C�lulad de Carga
% P                 - Posi��o do Gaige em Rela��o a Estrutura Deform�vel
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Prop_Param        - Estrutura de Dados das Propriedades do Problema

%% OUPTUT - Com Deforma��o e Tens�o
% Strain_Vector_NB  - Vetor de Deforma��es da C�lula de Carga -- Sem Ponte

%% Declara��o da Fun��o do Retorno do Vetor de Deforma��es da C�lula de Carga -- Sem Ponte
function [ Strain_Vector_NB ] = strain_vector_NB ( L , t , r , P , Node_Param , Elem_Param , Prop_Param )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Inicializa��o do Vetor de Deforma��es da C�lula de Carga
    Strain_Vector_NB = zeros ( 1 , 24 );
    
    % Varredura nas Estruturas Deform�veis da C�lula de Carga
    for j = 1:4
        
        % Retorno do Id do Elemento Relacionado a Posi��o P na Estrutura j
        [ Elem_Id ] = find_element_id ( L , t , r , P , Node_Param , Elem_Param , j );
                
        % C�lculo Deforma��o do Elemento na Posi��o P
        [ vector_strain_j ] = strain_element_id ( L , t , r , P , Node_Param , Elem_Param , Prop_Param , j , Elem_Id );
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 1 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 1
        if ( j == 1 )
            
            % Redu��o para as Deforma��es Normais
            vector_axial_strain = zeros ( 1 , 12 );
            
            % Aloca��o das Deforma��es Normais
            for k = 1:12
               
                % Aloca��o dos Termos
                vector_axial_strain ( 1 , k ) = vector_strain_j ( ( 6 * k ) - 5 ); 
                
            end    
            
            % Aloca��o no Vetor de Deforma��es de Deforma��es da C�lula de Carga
            Strain_Vector_NB ( 1 , 5  ) = vector_axial_strain ( 1 , 5  );
            Strain_Vector_NB ( 1 , 6  ) = vector_axial_strain ( 1 , 10 );
            Strain_Vector_NB ( 1 , 9  ) = vector_axial_strain ( 1 , 9  );
            Strain_Vector_NB ( 1 , 19 ) = vector_axial_strain ( 1 , 2  );
            Strain_Vector_NB ( 1 , 20 ) = vector_axial_strain ( 1 , 7  );
            Strain_Vector_NB ( 1 , 24 ) = vector_axial_strain ( 1 , 12 );
            
        end
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 2 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 2
        if ( j == 2 )
            
            % Redu��o para as Deforma��es Normais
            vector_axial_strain = zeros ( 1 , 12 );
            
            % Aloca��o das Deforma��es Normais
            for k = 1:12
               
                % Aloca��o dos Termos
                vector_axial_strain ( 1 , k ) = vector_strain_j ( ( 6 * k ) - 4 ); 
                
            end
            
            % Aloca��o no Vetor de Deforma��es de Deforma��es da C�lula de Carga
            Strain_Vector_NB ( 1 , 1  ) = vector_axial_strain ( 1 , 11 );
            Strain_Vector_NB ( 1 , 2  ) = vector_axial_strain ( 1 , 4  );
            Strain_Vector_NB ( 1 , 10 ) = vector_axial_strain ( 1 , 1  );
            Strain_Vector_NB ( 1 , 13 ) = vector_axial_strain ( 1 , 8  );
            Strain_Vector_NB ( 1 , 16 ) = vector_axial_strain ( 1 , 3  );
            Strain_Vector_NB ( 1 , 23 ) = vector_axial_strain ( 1 , 6  );
            
        end
     
        %%%%%%%%%%%%%%%
        % ESTRUTURA 3 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 3
        if ( j == 3 )
            
            % Redu��o para as Deforma��es Normais
            vector_axial_strain = zeros ( 1 , 12 );
            
            % Aloca��o das Deforma��es Normais
            for k = 1:12
               
                % Aloca��o dos Termos
                vector_axial_strain ( 1 , k ) = vector_strain_j ( ( 6 * k ) - 5 ); 
                
            end   
           
            % Aloca��o no Vetor de Deforma��es de Deforma��es da C�lula de Carga
            Strain_Vector_NB ( 1 , 7  ) = vector_axial_strain ( 1 , 11 );
            Strain_Vector_NB ( 1 , 8  ) = vector_axial_strain ( 1 , 4  );
            Strain_Vector_NB ( 1 , 12 ) = vector_axial_strain ( 1 , 3  );
            Strain_Vector_NB ( 1 , 17 ) = vector_axial_strain ( 1 , 8  );
            Strain_Vector_NB ( 1 , 18 ) = vector_axial_strain ( 1 , 1  );
            Strain_Vector_NB ( 1 , 21 ) = vector_axial_strain ( 1 , 6  );
          
        end
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 4 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 4
        if ( j == 4 )
            
            % Redu��o para as Deforma��es Normais
            vector_axial_strain = zeros ( 1 , 12 );
            
            % Aloca��o das Deforma��es Normais
            for k = 1:12
               
                % Aloca��o dos Termos
                vector_axial_strain ( 1 , k ) = vector_strain_j ( ( 6 * k ) - 4 ); 
                
            end 
            
            % Aloca��o no Vetor de Deforma��es de Deforma��es da C�lula de Carga
            Strain_Vector_NB ( 1 , 3  ) = vector_axial_strain ( 1 , 5  );
            Strain_Vector_NB ( 1 , 4  ) = vector_axial_strain ( 1 , 10 );
            Strain_Vector_NB ( 1 , 11 ) = vector_axial_strain ( 1 , 7  );
            Strain_Vector_NB ( 1 , 14 ) = vector_axial_strain ( 1 , 9  );
            Strain_Vector_NB ( 1 , 15 ) = vector_axial_strain ( 1 , 2  );
            Strain_Vector_NB ( 1 , 22 ) = vector_axial_strain ( 1 , 12 );

        end   
        
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('strain_vector_NB : %2.2f s.\n', t2 );
    
end