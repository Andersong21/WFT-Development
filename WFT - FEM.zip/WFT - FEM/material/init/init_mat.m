%% Inicializa��o dos Par�metros do Material do Problema

%% INPUT

%% OUTPUT
% Mat_Param         - Estrutura de Dados do Material da An�lise

%% Declara��o da Fun��o de Inicializa��o dos Par�metros do Material
function [ Mat_Param ] = init_mat ()
 
    % Inicializa��o da Estrutura do Material da An�lise
    Mat_Param = struct;
    
end