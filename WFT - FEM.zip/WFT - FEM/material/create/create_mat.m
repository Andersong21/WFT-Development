%% Defini��o do Material do Problema

%% INPUT
% Mat_Param         - Estrutura de Dados Inicial do Material do Problema

%% OUPTUR
% Mat_Param         - Estrutura de Dados Final do Material do Problema

%% Declara��o da Fun��o de Defini��o do Material do Problema
function [ Mat_Param ] = create_mat ( Mat_Param )

    % Defini��o do Id do Material
    Mat_Param ( 1 ).id = 1;
    
    % Defini��o do M�dulo de Elasticidade
    Mat_Param ( 1 ).E  = 71000;
    
    % Defini��o do Coeficiente de Poisson
    Mat_Param ( 1 ).poisson = 0.33;
    
    % Defini��o da Densidade
    Mat_Param ( 1 ).rho = 2.70e-9;
    
    % Defini��o da Tens�o de Fadiga
    Mat_Param ( 1 ).Sfad = 185;
    
end