%% Retorno do Gerador de Material do Problema

%% INPUT

%% OUPTUR
% Mat_Param    - Estrutura de Dados do Material do Sistema

%% Declara��o da Fun��o de Retorno do Gerador de Material do Problema
function [ Mat_Param ] = get_mat ()

    % Inicializa��o do Timer
    t1 = cputime;
    
    % Inicializa��o dos Par�metros do Material
    [ Mat_Param ] = init_mat ();
    
    % Defini��o do Material da An�lise
    [ Mat_Param ] = create_mat ( Mat_Param );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_mat : %2.2f s.\n', t2 );
    
end