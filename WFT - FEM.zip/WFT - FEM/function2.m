%% Defini��o do Modelo Num�rico do Transdutor

%% INPUT
% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]
% n                          - Quantidade de Elementos              - [ -  ]
% FC                         - Fator de Correla��o                  - [ -  ]
% multicore                  - Quantidade de N�cleos                - [ -  ]

%% OUTPUT
% f1                         - Fun��o Objetivo
% Mat_Param                  - Par�metros dos Materiais
% Prop_Param                 - Par�metros das Propriedades
% Node_Param                 - Par�metros dos N�s
% Elem_Param                 - Par�metros dos Elementos
% Mpc_Param                  - Par�metros das Restri��es
% nsamples                   - Quantidade de Amostras
% LB                         - Lower Bound das Vari�veis
% UB                         - Upper Bound das Vari�veis

%% Declara��o da Fun��o Objetivo
function [ f1 , Mat_Param , Prop_Param , Node_Param , Elem_Param , Mpc_Param , t2 ] = function2( x , n , FC , multicore )

    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;

    %%%%%%%%%%%%%
    % VARI�VEIS %
    %%%%%%%%%%%%%
    
    % Defini��o das Vari�veis
    b1 = x ( 1 , 1 );
    h1 = x ( 1 , 2 );
    b2 = x ( 1 , 3 );
    h2 = x ( 1 , 4 );
    L  = x ( 1 , 5 );
    Lf = x ( 1 , 6 );
    t  = x ( 1 , 7 );
    d  = x ( 1 , 8 );
    r  = x ( 1 , 9 );
    P  = 0.5;
    r1 = 55;
    d1 = 25;
    d2 = 8;
 
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%   

    % Retorno do Material do Sistema
    [ Mat_Param ] = get_mat ();
    
    % Retorno da Densidade do Material
    rho = Mat_Param ( 1 ).rho;   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DAS PROPRIEDADES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    % Retorno das Propriedades do Sistema
    [ Prop_Param ] = get_prop ( t );
    
    %%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DO MPC %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Retorno dos Mpcs do Sistema
    [ Mpc_Param ] = get_mpc ();    
  
    %%%%%%%%%%%%%%%%%%%%%%%
    % PAR�METROS DE MALHA %
    %%%%%%%%%%%%%%%%%%%%%%%
      
    % Retorno do Gerador de Malha
    [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = get_mesh ( b1 , h1 , b2 , h2 , L , Lf , t , d , r , n , Prop_Param , Mpc_Param , Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MONTAGEM DA MATRIZ DE RIGIDEZ %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % Retorno da Matriz de Rigidez do Problema
    [ K ] = get_matrix_K ( Node_Param , Elem_Param , Mat_Param , Prop_Param , Mpc_Param , multicore );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % MONTAGEM DA MATRIZ DE MASSA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno da Matriz de Massa do Problema
    [ M ] = get_matrix_M ( Node_Param , Elem_Param , Mat_Param , Prop_Param , Mpc_Param , multicore );    
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SOLU��O DO SISTEMA MODAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        
    % Retorno do Sistema de Solu��o Modal
    [ Node_Param ] = get_eigen_S ( K , M , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COMPLIANCE NORMALIZADA DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o da Matriz de Compliance Normalizada da C�lula de Carga
    Comp_N_LoadCell = zeros ( 6 , 6 );
            
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO ISOFLEX�O E COMPLIANCE %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nas 6 dire��es
    for i = 1:6
        
        %%%%%%%%%%%%%%%%%%%
        % VETOR DE FOR�AS %
        %%%%%%%%%%%%%%%%%%%

        % Retorno do Vetor de For�as do Problema
        [ F ] = get_vector_F ( Node_Param , i );

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % SOLU��O DO SISTEMA LINEAR %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%        

        % Retorno do Vetor de Deslocamentos
        [ Node_Param ] = get_vector_X ( K , F , Node_Param );        
            
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % DEFORMA��O C�LULA DE CARGA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Fun��o de C�lculo das Deforma��es no Ponto de Localiza��o do Gaige
        [ Comp_N_LoadCell ] = get_comp_N_loadcell ( Comp_N_LoadCell , L , t , r , P , Node_Param , Elem_Param , Prop_Param , i );
                
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ISOTROPIA DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
       
    % Fun��o de C�lculo da Isotropia da C�lula de Carga
    [ Iso_LoadCell ] = get_iso_loadcell ( Comp_N_LoadCell );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COMPLIANCE DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Fun��o de C�lculo das Deforma��es no Ponto de Localiza��o do Gaige
    [ Comp_LoadCell ] = get_comp_loadcell ( Comp_N_LoadCell );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CALIBRA��O DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    % Fun��o de C�lculo da Matriz de Calibra��o da C�lula de Carga
    [ Calib_LoadCell ] = get_calib_loadcell ( Comp_LoadCell );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CROSSTALKING - C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    % Fun��o de C�lculo do Cross Talking dos Canais da C�lula de Carga
    [ Cross_LoadCell ] = get_cross_loadcell ( Comp_LoadCell );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SENSIBILIDADE DA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
       
    % Fun��o de C�lculo das Sensibilidades dos Canais da C�lula de Carga
    [ Sens_LoadCell ] = get_sens_loadcell ( Comp_N_LoadCell );
 
    %%%%%%%%%%%%%%%%%%%
    % VETOR DE FOR�AS %
    %%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de For�as do Problema
    [ F , Node_Param ] = get_vector_F ( Node_Param , 7 );
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SOLU��O DO SISTEMA LINEAR %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deslocamentos
    [ Node_Param ] = get_vector_X ( K , F , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DAS DEFORMA��ES E TENS�ES DOS ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    % Fun��o de C�lculo das Deforma��es e Tens�es dos Elementos
    [ Elem_Param ] = get_strain_stress ( Node_Param , Elem_Param , Mat_Param , Prop_Param , multicore );  
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DAS DEFORMA��ES NAS POSI��ES DOS GAIGES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Retorno do Vetor de Deforma��es -- Sem Ponte
    [ Strain_Vector_NB ] = strain_vector_NB ( L , t , r , P , Node_Param , Elem_Param , Prop_Param );
    
    % Retorno do Vetor de Deforma��es -- Com Ponte
    [ Strain_Vector_FB ] = strain_vector_FB ( Strain_Vector_NB );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % C�LCULO DA FOR�A MEDIDA PELA C�LULA DE CARGA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    % Fun��o de C�lculo das For�as Lidas dos Canais da C�lula de Carga
    [ Force_LoadCell ] = get_force_loadcell ( Calib_LoadCell , Strain_Vector_FB );    
       
    %%%%%%%%%%%%%%%%%%%%
    % ESCRITA DA MALHA %
    %%%%%%%%%%%%%%%%%%%%    
    
    % Escrita da Malha Criada
    write_mesh_MD_Nastran ( Mat_Param , Prop_Param , Node_Param  , Elem_Param , Mpc_Param );
   
    %%%%%%%%%%%%%%%%%%%%%
    % FUN��O OTIMIZA��O %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Minimiza��o de Massa
    f1 ( 1 ) = - ( h1 * ( power ( d1 , 2 ) * pi + 4 * ( power ( d2 , 2 ) * pi - 4 * power ( r1 , 2 ) - pi * ( r + 2 * r1 ) * ( r + 2 * r1 - 2 * sqrt ( 2 ) * r1 ) ) ) * rho ) / 4. + b1 * h1 * rho * ( 1.2 * L - 0.6 * t ) - ...
               2.2399999999999998  * ( 1.*b1 + 0.4285714285714286 * b2 - 2.857142857142857 * d ) * ( d - 0.35 * h1 - 0.15 * h2 ) * rho * ( 1.*L - 0.5*t ) + ...
               0.10800000000000003 * ( 1.*b1 + 2.333333333333333  * b2 ) * ( 1.*h1 + 2.333333333333333 * h2 ) * rho * ( 1.*L - 0.5 * t ) + 4 * h2 * Lf * rho * t;
           
    % Maximiza��o das Sensibilidades
    f1 ( 2 ) = Sens_LoadCell ( 1 );
    f1 ( 3 ) = Sens_LoadCell ( 2 );
    f1 ( 4 ) = Sens_LoadCell ( 3 );
    f1 ( 5 ) = Sens_LoadCell ( 4 );
    f1 ( 6 ) = Sens_LoadCell ( 5 );
    f1 ( 7 ) = Sens_LoadCell ( 6 );
    
    % Fun��o Objetivo
    w1 = 0.0;
    w2 = 1.0;
    f = ( 1000 * w1 * f1 ( 1 ) ) - ( w2 * ( f1 ( 2 ) + f1 ( 3 ) + f1 ( 4 ) + f1 ( 5 ) + f1 ( 6 ) + f1 ( 7 ) ) );    
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita da Massa
    fprintf('\nMass       : %2.2f [ kg ].\n' , 1000 * f1 ( 1 ) );
   
    % Escrita dos Cross Talking
    fprintf('Cross 1    : %2.2f [ -  ].\n' , Cross_LoadCell ( 1 , 1 ) );
    fprintf('Cross 2    : %2.2f [ -  ].\n' , Cross_LoadCell ( 2 , 2 ) );
    fprintf('Cross 3    : %2.2f [ -  ].\n' , Cross_LoadCell ( 3 , 3 ) );
    fprintf('Cross 4    : %2.2f [ -  ].\n' , Cross_LoadCell ( 4 , 4 ) );
    fprintf('Cross 5    : %2.2f [ -  ].\n' , Cross_LoadCell ( 5 , 5 ) );
    fprintf('Cross 6    : %2.2f [ -  ].\n' , Cross_LoadCell ( 6 , 6 ) );
    
    % Escrita da Isotropia
    fprintf('Isotropy   : %2.2f [ -  ].\n' , Iso_LoadCell );
    
    % Escrita das Sensibilidade
    fprintf('Sensib 1   : %2.2f [ mV / V ].\n' , Sens_LoadCell ( 1 ) );
    fprintf('Sensib 2   : %2.2f [ mV / V ].\n' , Sens_LoadCell ( 2 ) );
    fprintf('Sensib 3   : %2.2f [ mV / V ].\n' , Sens_LoadCell ( 3 ) );
    fprintf('Sensib 4   : %2.2f [ mV / V ].\n' , Sens_LoadCell ( 4 ) );
    fprintf('Sensib 5   : %2.2f [ mV / V ].\n' , Sens_LoadCell ( 5 ) );
    fprintf('Sensib 6   : %2.2f [ mV / V ].\n' , Sens_LoadCell ( 6 ) );
    
    % Escrita das For�as
    fprintf('Force  1   : %2.2f [ N ].\n'    , Force_LoadCell ( 1 ) );
    fprintf('Force  2   : %2.2f [ N ].\n'    , Force_LoadCell ( 2 ) );
    fprintf('Force  3   : %2.2f [ N ].\n'    , Force_LoadCell ( 3 ) );
    fprintf('Force  4   : %2.2f [ N.mm ].\n' , Force_LoadCell ( 4 ) );
    fprintf('Force  5   : %2.2f [ N.mm ].\n' , Force_LoadCell ( 5 ) );
    fprintf('Force  6   : %2.2f [ N.mm ].\n' , Force_LoadCell ( 6 ) );
    
    % Escrita da Fun��o Objetivo
    fprintf('Objective  : %2.2f [ -  ].\n'   , f );

    Escrita do Tempo
    fprintf('%2.2f s.\n', t2 );

end