%% Retorno da Solu��o do Sistema Modal

%% INPUT
% K            - Matriz de Rigidez do Problema
% M            - Matriz de Massa do Problema

%% OUTPUT
% EVA          - Retorno do Vetor de Autovalores do Problema
% EVC          - Retorno do Vetor de Autovetores do Problema

%% Declara��o da Fun��o de Retorno da Solu��o do Sistema Linear
function [ EVA , EVC ] = esolve ( K , M )

    % Verificador de Autovalor Convergido
    EVA_conv = false;
    
    % Inicializa��o do Contador
    cont = 1;
    
    % Itera��es
    iter = 1;
    
    % Procura do Menor Autovalor
    while ( EVA_conv == false )
        
        % N�mero de Autovalores Convergidos
        Neigen = cont;
        
        % Solu��o do Sistema Modal
        [ EVC_i , EVA_i ] = eigs ( M , K , Neigen );
        
        % Ordenada��o do Sistema Modal -- Autovalores
        [ EVA_i , EVC_a ] = sort( diag ( EVA_i ) );
        
        % Ordena��o do Sistema Modal -- Autovetores
        EVC_i = EVC_i ( : , EVC_a );
    
        % Pre aloca��o do tamanho do autovalor
        EVA = zeros ( 1 , 1 );
        
        % Pre aloca��o do tamanho do autovetor
        EVC = zeros ( length ( K ) , 1 );
        
        % Procura nos Autovalores
        for i = 1:Neigen
            
            % Frequ�ncia Natural
            f = sqrt ( 1.0 / EVA_i ( end - i + 1 , 1 ) ) / ( 2 * pi );
            
            % Verifica��o se a Frequ�ncia � um N�mero Real
            if ( abs( imag ( f ) ) < 1e-10 )
                
                % Aloca��o do Autovalor Convergido
                EVA ( 1 , 1 ) = f;
                
                % Aloca��o do Autovetor Convergido
                EVC ( : , 1 ) = EVC_i ( : , i );
                
                % Atualiza��o do Verificador
                EVA_conv = true;
                
                % Quebra do C�digo
                break;
                
            end           
            
        end
        
        % Atualiza��o do Contador
        cont = cont + 1;
        
        % Atualiza��o do Iterator
        iter = iter + 1;
        
        % Verifica��o da Quantidade de Itera��es
        if ( iter > 1000 )
           
            % Quebra do C�digo
            break;
            
        end
        
    end

end