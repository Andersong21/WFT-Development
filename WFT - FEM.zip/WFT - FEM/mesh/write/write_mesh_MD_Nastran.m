%% Retorno da Escrita da Malha do Problema -- MD NASTRAN

%% INPUT
% Mat_Param         - Estrutura de Dados dos Materiais da Malha
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Node_Param        - Estrutura de Dados dos N�s da Malha
% Elem_Param        - Estrutura de Dados dos Elementos da Malha
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha

%% Declara��o da Fun��o de Escrita da Malha do Problema -- MD NASTRAN
function write_mesh_MD_Nastran ( Mat_Param , Prop_Param , Node_Param  , Elem_Param , Mpc_Param )

    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Abertura do Arquivo da Malha
    fileID = fopen ( 'mesh.bdf' , 'wt' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO CABE�ALHO %
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita do Cabe�alho
    [ fileID ] = write_title_MD ( fileID );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS PROPRIEDADES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Propriedades
    [ fileID ] = write_prop_MD ( fileID , Prop_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita dos Elementos
    [ fileID ] = write_elem_MD ( fileID , Elem_Param );    
        
    %%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita do Material
    [ fileID ] = write_mat_MD ( fileID , Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS N�S %
    %%%%%%%%%%%%%%%%%%%
    
    % Escrita dos N�s
    [ fileID ] = write_node_MD ( fileID , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS CONDI��ES DE CONTORNO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Condi��es de Contorno
    [ fileID ] = write_bc_MD ( fileID , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS FOR�AS %
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das For�as
    [ fileID ] = write_force_MD ( fileID , Node_Param );   
    
    %%%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS MPCS %
    %%%%%%%%%%%%%%%%%%%%
    
    % Escrita dos Elementos
    [ fileID ] = write_mpc_MD ( fileID , Elem_Param , Mpc_Param );   
    
    %%%%%%%%%%%%%%%
    % FINALIZA��O %
    %%%%%%%%%%%%%%%
    
    % Finaliza��o da Escrita
    fprintf ( fileID , 'ENDDATA 07393c7a\n' );
    
    % Fechar Arquivo
    fclose ( 'all' );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_mesh_MD : %2.2f s.\n', t2 );
    
end