%% Retorno da Escrita do T�tulo da Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  

%% OUPTUT
% fileID            - Carta do Problema com Cabe�alho

%% Declara��o da Fun��o de Escrita do T�tulo da Carta
function [ fileID ] = write_title_NX ( fileID )

    %%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO CABE�ALHO %
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;

    % Escrita do Cabe�alho
    fprintf ( fileID , 'INIT MASTER(S)\n' );
    fprintf ( fileID , 'NASTRAN SYSTEM(442)=-1,SYSTEM(319)=1\n' );
    fprintf ( fileID , 'ID Femap,Femap\n' );
    fprintf ( fileID , 'SOL SESTATIC\n' );
    fprintf ( fileID , 'TIME 10000\n' );
    fprintf ( fileID , 'CEND\n' );

    % Escrita do T�tulo
    fprintf ( fileID , '  TITLE = Example_NX_Nastran\n' );
    fprintf ( fileID , '  ECHO = NONE\n' );
    fprintf ( fileID , '  DISPLACEMENT(PLOT) = ALL\n' );
    fprintf ( fileID , '  SPCFORCE(PLOT) = ALL\n' );
    fprintf ( fileID , '  OLOAD(PLOT) = ALL\n' );
    fprintf ( fileID , '  FORCE(PLOT,CORNER) = ALL\n' );
    fprintf ( fileID , '  STRESS(PLOT,CORNER) = ALL\n' );   
    fprintf ( fileID , 'BEGIN BULK\n' );
    fprintf ( fileID , 'PARAM,POST,-1\n' );
    fprintf ( fileID , 'PARAM,OGEOM,NO\n' );
    fprintf ( fileID , 'PARAM,AUTOSPC,YES\n' );
    fprintf ( fileID , 'PARAM,K6ROT,100.\n' );
    fprintf ( fileID , 'PARAM,GRDPNT,0\n' );
    
    % Escrita das Coordenadas
    fprintf ( fileID , 'CORD2C         1       0      0.      0.      0.      0.      0.      1.+FEMAPC1\n' );
    fprintf ( fileID , '+FEMAPC1      1.      0.      1.        \n' );
    fprintf ( fileID , 'CORD2S         2       0      0.      0.      0.      0.      0.      1.+FEMAPC2\n' );
    fprintf ( fileID , '+FEMAPC2      1.      0.      1.        \n' );    
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_title : %2.2f s.\n', t2 );
           
end