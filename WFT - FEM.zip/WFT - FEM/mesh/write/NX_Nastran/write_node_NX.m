%% Retorno da Escrita dos N�s da Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  
% Node_Param        - Estrutura de Dados dos N�s do Problema

%% OUPTUT
% fileID            - Carta do Problema com N�s Preenchidos

%% Declara��o da Fun��o de Escrita dos N�s na Carta -- NX Nastran
function [ fileID ] = write_node_NX ( fileID , Node_Param )

   % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de N�s
    Nnode = Node_Param ( end ).id;

    %%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS N�S %
    %%%%%%%%%%%%%%%%%%%
    
    % ESCRITA DOS N�S
    for i = 1:Nnode
    
        % Inicializa��o do N�
        fprintf ( fileID , 'GRID    ' );
        
        % Transforma��o do Id do N� em Texto
        Idt1 = int2str ( Node_Param ( i ).id );
        
        % Convers�o para o Formato ASCII do Id do N�
        [ Idt ] = convert_text_end ( Idt1 );
        
        % Escrita do Id do N�
        fprintf ( fileID , Idt        );
        fprintf ( fileID , '       0' );
        
        % Transforma��o da Coordenada X do N� em Texto
        Cxt1 = num2str ( Node_Param ( i ).coord ( 1 ) , '%3.2f' );
        
        % Convers�o para o Formato ASCII da Coordenada X do N�
        [ Cxt ] = convert_text_end ( Cxt1 );
        
        % Transforma��o da Coordenada Y do N� em Texto
        Cyt1 = num2str ( Node_Param ( i ).coord ( 2 ) , '%3.2f' );
        
        % Convers�o para o Formato ASCII da Coordenada Y do N�
        [ Cyt ] = convert_text_end ( Cyt1 );
        
        % Transforma��o da Coordenada Z do N� em Texto
        Czt1 = num2str ( Node_Param ( i ).coord ( 3 ) , '%3.2f' );
        
        % Convers�o para o Formato ASCII da Coordenada Z do N�
        [ Czt ] = convert_text_end ( Czt1 );
        
        % Escrita das Coordenadas do N�
        fprintf ( fileID , Cxt          );
        fprintf ( fileID , Cyt          );
        fprintf ( fileID , Czt          );
        fprintf ( fileID , '       0\n' );
          
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_node : %2.2f s.\n', t2 );
    
end