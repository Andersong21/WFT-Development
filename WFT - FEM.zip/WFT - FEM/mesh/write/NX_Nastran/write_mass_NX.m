%% Retorno da Escrita da Massa Concentrada na Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  
% Elem_Param        - Estrutura de Dados dos Elementos do Problema

%% OUPTUT
% fileID            - Carta do Problema com Mpc Preenchidos

%% Declara��o da Fun��o de Escrita da Massa Concentrada na Carta -- NX Nastran
function [ fileID ] = write_mass_NX ( fileID , Elem_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DA MASSA CONCENTRADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;
      
    % Inicializa��o do Mpc
    fprintf ( fileID,  'CONM2   ' );
    
    % Transforma��o do Id da Massa Concentrada em Texto
    Idm1 = int2str ( Elem_Param ( end ).id );
    
    % Convers�o para o Formato ASCII do Id da Massa Concentrada
    [ Idm ] = convert_text_end ( Idm1 );        

    % Escrita do Id da Massa Concentrada
    fprintf ( fileID , Idm        );
    
    % Transforma��o do Id do N� Associado a Massa Concentrada em Texto
    Idn1 = int2str ( Elem_Param ( end ).node ( 1 ) );
    
    % Convers�o para o Formato ASCII do Id do N� Associado a Massa Concentrada
    [ Idn ] = convert_text_end ( Idn1 );        

    % Escrita do Id do N� associado a Massa Concentrada
    fprintf ( fileID , Idn        );
    
    % Termos Adicionais
    fprintf ( fileID,  '       0' );
    
    % Transforma��o da Massa Concentrada em Texto
    m1 = num2str ( Elem_Param ( end ).mass , '%2.2e' );

    % Elimina��o do Caracter e
    m2 = regexprep( m1 ,'e' ,'');

    % Convers�o para o Formato ASCII da Massa Concentrada
    [ m ] = convert_text_end ( m2 ); 

    % Escrita do Id da Massa Concentrada
    fprintf ( fileID , m        );
    
    % Termos Adicionais
    fprintf ( fileID,  '      0.' );
    fprintf ( fileID,  '      0.' );
    fprintf ( fileID,  '      0.' );
    fprintf ( fileID,  '        ' );
    fprintf ( fileID,  '        \n' );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_mass : %2.2f s.\n', t2 );

end