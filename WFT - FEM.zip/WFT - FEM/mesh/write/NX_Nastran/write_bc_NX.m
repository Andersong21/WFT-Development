%% Retorno da Escrita das Condi��es de Contorno da Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  
% Node_Param        - Estrutura de Dados dos N�s do Problema

%% OUPTUT
% fileID            - Carta do Problema com Condi��es Contorno Preenchidas

%% Declara��o da Fun��o de Escrita das Condi��es de Contorno na Carta -- NX Nastran
function [ fileID ] = write_bc_NX ( fileID , Node_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de N�s
    Nnode = Node_Param ( end ).id; 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS CONDI��ES DE CONTORNO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Condi��es de Contorno
    fprintf ( fileID , '$ Femap with NX Nastran Constraint Set 1 : BoundaryConditions\n' );
  
    % Varredura nos N�s
    for i = 1:Nnode
        
        % Verifica��o se � um N� de Borda
        if ( strcmp ( Node_Param ( i ).border , 'Y' ) == 1 )
        
            % Escrita das Condi��es de Contorno
            fprintf ( fileID , 'SPC1    ' );
            
            % Tipo da Condi��o
            fprintf ( fileID , '       1' );
            
            % Graus de Liberdade Restringidos
            fprintf ( fileID , '     123' );
            
            % Transforma��o do Id do N� em Texto
            Idnt1 = int2str ( Node_Param ( i ).id );
            
            % Convers�o para o Formato ASCII dos Momentos
            [ Idnt ] = convert_text_end ( Idnt1 );
            
            % Escrita do Id do N�
            fprintf ( fileID , Idnt        );
            
            % Quebra de Linha
            fprintf ( fileID , '\n'        );      
        
        end 
    
    end  
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_bc : %2.2f s.\n', t2 );
           
end