%% Retorno da Escrita das Propriedades da Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  
% Prop_Param        - Estrutura de Dados das Propriedades do Problema

%% OUPTUT
% fileID            - Carta do Problema com Propriedades Preenchidas

%% Declara��o da Fun��o de Escrita das Propriedades na Carta -- NX Nastran
function [ fileID ] = write_prop_NX ( fileID , Prop_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de Proprieades
    Nprop = Prop_Param ( end ).id;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS PROPRIEDADES 2D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita da Propriedade PSHELL
    fprintf ( fileID , '$ Femap with NX Nastran Property 1 : Plate\n' );
    
    % Transforma��o da Espessura em Texto
    Tt1 = int2str ( Prop_Param ( 1 ).thick );
    
    % Adi��o do Ponto ao Final
    Tt2 = [ Tt1 , '.' ];
    
    % Convers�o para o Formato ASCII da Espessura
    [ Tt ] = convert_text_end ( Tt2 ); 
    
    % Escrita dos Par�metros da Propriedade PSHELL
    fprintf ( fileID , 'PSHELL  '   );
    fprintf ( fileID , '       1'   );
    fprintf ( fileID , '       1'   );
    fprintf ( fileID , Tt           );
    fprintf ( fileID , '       1'   );
    fprintf ( fileID , '        '   );
    fprintf ( fileID , '       1'   );
    fprintf ( fileID , '        '   );
    fprintf ( fileID , '      0.'   );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS PROPRIEDADES 1D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Propriedades 1D    
    fprintf ( fileID , '$ Femap with NX Nastran Property : PBeamL\n' );    
    
    % Escrita das Se��es
    for i = 2:Nprop
    
        % Verifica��o do Elemento Tipo 1D
        if ( strcmp ( Prop_Param ( i ).type , '1d' ) == 1 )
        
            % Escrita do PBEAM
            fprintf ( fileID , 'PBEAML  '   );
            
            % Transforma��o do Id da Se��o em Texto
            Idst = int2str ( Prop_Param ( i ).id );    
    
            % Convers�o para o Formato ASCII do Id da Se��o
            [ Ids ] = convert_text_end ( Idst );  
    
            % Escrita do Id da Se��o
            fprintf ( fileID , Ids          );
            
            % Associa��o com o Material
            fprintf ( fileID , '       1'   );
            
            % Par�metros Vazios
            fprintf ( fileID , '       1'   );
            
            % Transforma��o da �rea do Ponto 1 em Texto
            A1t1 = num2str ( Prop_Param ( i ).Area ( 1 ) , '%2.2e' );
            
            % Transforma��o do Momento de In�rcia Iyy do Ponto 1 em Texto
            Iyy1t1 = num2str ( Prop_Param ( i ).Iyy ( 1 ) , '%2.2e' );
            
            % Transforma��o do Momento de In�rcia Izz do Ponto 1 em Texto
            Izz1t1 = num2str ( Prop_Param ( i ).Izz ( 1 ) , '%2.2e' );
            
            % Transforma��o do Momento Polar de In�rcia do Ponto 1 em Texto
            J1t1 = num2str ( Prop_Param ( i ).J ( 1 ) , '%2.2e' );
            
            % Elimina��o do Caracter e
            A1t2 = regexprep( A1t1 ,'e' ,'');
            
            % Elimina��o do Caracter e
            Iyy1t2 = regexprep( Iyy1t1 ,'e' ,'');
            
            % Elimina��o do Caracter e
            Izz1t2 = regexprep( Izz1t1 ,'e' ,'');
            
            % Elimina��o do Caracter e
            J1t2 = regexprep( J1t1 ,'e' ,'');
            
            % Convers�o para o Formato ASCII da �rea do Ponto 1
            [ A1t ] = convert_text_end ( A1t2 );
            
            % Convers�o para o Formato ASCII do Momento de In�rcia Iyy do Ponto 1
            [ Iyy1t ] = convert_text_end ( Iyy1t2 );
            
            % Convers�o para o Formato ASCII do Momento de In�rcia Izz do Ponto 1
            [ Izz1t ] = convert_text_end ( Izz1t2 );
            
            % Convers�o para o Formato ASCII do Momento Polar de In�rcia do Ponto 1
            [ J1t ] = convert_text_end ( J1t2 );
            
            % Escrita da �rea do Ponto 1 
            fprintf ( fileID , A1t          );
            
            % Escrita do Momento de In�rcia Iyy do Ponto 1
            fprintf ( fileID , Iyy1t       );
            
            % Escrita do Momento de In�rcia Izz do Ponto 1
            fprintf ( fileID , Izz1t       );
            
            % Produto de In�rcia
            fprintf ( fileID , '      0.'   );
            
            % Escrita do Momento Polar de In�rcia do Ponto 1
            fprintf ( fileID , J1t       );            
            
            % Termos Adicionais
            fprintf ( fileID , '      0.'   );
            fprintf ( fileID , '+       \n' );
            fprintf ( fileID , '+       '   );
            
            % Base do Ponto 1
            B1 = Prop_Param ( i ).b ( 1 );
            
            % Altura do Ponto 1
            H1 = Prop_Param ( i ).h ( 1 );
            
            % Posicionamento do Ponto 1 -- A
            a1y = - B1 / 2;
            a1z = - H1 / 2;
            
            % Posicionamento do Ponto 1 -- B
            b1y = + B1 / 2;
            b1z = - H1 / 2;
                        
            % Posicionamentos do Ponto 1 -- C
            c1y = + B1 / 2;
            c1z = + H1 / 2;
            
            % Posicionamentos do Ponto 1 -- D
            d1y = - B1 / 2;
            d1z = + H1 / 2;
            
            % Transforma��o do Ponto 1 - A em Texto
            a1yt1 = num2str ( a1y , '%2.2f' );
            a1zt1 = num2str ( a1z , '%2.2f' );
            
            % Transforma��o do Ponto 1 - B em Texto
            b1yt1 = num2str ( b1y , '%2.2f' );
            b1zt1 = num2str ( b1z , '%2.2f' );
            
            % Transforma��o do Ponto 1 - C em Texto
            c1yt1 = num2str ( c1y , '%2.2f' );
            c1zt1 = num2str ( c1z , '%2.2f' );
            
            % Transforma��o do Ponto 1 - D em Texto
            d1yt1 = num2str ( d1y , '%2.2f' );
            d1zt1 = num2str ( d1z , '%2.2f' );
            
            % Convers�o para o Formato ASCII do Ponto 1 - A            
            [ a1yt ] = convert_text_end ( a1yt1 );
            [ a1zt ] = convert_text_end ( a1zt1 );
            
            % Convers�o para o Formato ASCII do Ponto 1 - B           
            [ b1yt ] = convert_text_end ( b1yt1 );
            [ b1zt ] = convert_text_end ( b1zt1 );
            
            % Convers�o para o Formato ASCII do Ponto 1 - C            
            [ c1yt ] = convert_text_end ( c1yt1 );
            [ c1zt ] = convert_text_end ( c1zt1 );
            
            % Convers�o para o Formato ASCII do Ponto 1 - D            
            [ d1yt ] = convert_text_end ( d1yt1 );
            [ d1zt ] = convert_text_end ( d1zt1 );
            
            % Escrita do Ponto 1 - A
            fprintf ( fileID , a1zt       );
            fprintf ( fileID , a1yt       );
            
            % Escrita do Ponto 1 - B
            fprintf ( fileID , b1zt       );
            fprintf ( fileID , b1yt       );
            
            % Escrita do Ponto 1 - C
            fprintf ( fileID , c1zt       );
            fprintf ( fileID , c1yt       );
            
            % Escrita do Ponto 1 - D
            fprintf ( fileID , d1zt       );
            fprintf ( fileID , d1yt       );
            
            % Termos Adicionais
            fprintf ( fileID , '+       \n' );
            fprintf ( fileID , '+       '   );
            fprintf ( fileID , '     YES'   );
            fprintf ( fileID , '      1.'   );
            
            % Transforma��o da �rea do Ponto 2 em Texto
            A2t1 = num2str ( Prop_Param ( i ).Area ( 2 ) , '%2.2e' );
            
            % Transforma��o do Momento de In�rcia Iyy do Ponto 2 em Texto
            Iyy2t1 = num2str ( Prop_Param ( i ).Iyy ( 2 ) , '%2.2e' );
            
            % Transforma��o do Momento de In�rcia Izz do Ponto 2 em Texto
            Izz2t1 = num2str ( Prop_Param ( i ).Izz ( 2 ) , '%2.2e' );
            
            % Transforma��o do Momento Polar de In�rcia do Ponto 2 em Texto
            J2t1 = num2str ( Prop_Param ( i ).J ( 2 ) , '%2.2e' );
            
            % Elimina��o do Caracter e
            A2t2 = regexprep( A2t1 ,'e' ,'');
            
            % Elimina��o do Caracter e
            Iyy2t2 = regexprep( Iyy2t1 ,'e' ,'');
            
            % Elimina��o do Caracter e
            Izz2t2 = regexprep( Izz2t1 ,'e' ,'');
            
            % Elimina��o do Caracter e
            J2t2 = regexprep( J2t1 ,'e' ,'');
            
            % Convers�o para o Formato ASCII da �rea do Ponto 2
            [ A2t ] = convert_text_end ( A2t2 );
            
            % Convers�o para o Formato ASCII do Momento de In�rcia Iyy do Ponto 2 
            [ Iyy2t ] = convert_text_end ( Iyy2t2 );
            
            % Convers�o para o Formato ASCII do Momento de In�rcia Izz do Ponto 2
            [ Izz2t ] = convert_text_end ( Izz2t2 );
            
            % Convers�o para o Formato ASCII do Momento Polar de In�rcia do Ponto 2
            [ J2t ] = convert_text_end ( J2t2 );
            
            % Escrita da �rea do Ponto 2
            fprintf ( fileID , A2t          );
            
            % Escrita do Momento de In�rcia Iyy do Ponto 2
            fprintf ( fileID , Iyy2t       );
            
            % Escrita do Momento de In�rcia Izz do Ponto 2
            fprintf ( fileID , Izz2t       );
            
            % Produto de In�rcia
            fprintf ( fileID , '      0.'   );
            
            % Escrita do Momento Polar de In�rcia do Ponto 2
            fprintf ( fileID , J2t       ); 
            
             % Termos Adicionais
            fprintf ( fileID , '      0.'   );
            fprintf ( fileID , '+       \n' );
            fprintf ( fileID , '+       '   );
            
            % Base do Ponto 2
            B2 = Prop_Param ( i ).b ( 2 );
            
            % Altura do Ponto 2
            H2 = Prop_Param ( i ).h ( 2 );
            
            % Posicionamento do Ponto 2 -- A
            a2y = - B2 / 2;
            a2z = - H2 / 2;
            
            % Posicionamento do Ponto 1 -- B
            b2y = + B2 / 2;
            b2z = - H2 / 2;
                        
            % Posicionamentos do Ponto 1 -- C
            c2y = + B2 / 2;
            c2z = + H2 / 2;
            
            % Posicionamentos do Ponto 1 -- D
            d2y = - B2 / 2;
            d2z = + H2 / 2;
            
            % Transforma��o do Ponto 2 - A em Texto
            a2yt1 = num2str ( a2y , '%2.2f' );
            a2zt1 = num2str ( a2z , '%2.2f' );
            
            % Transforma��o do Ponto 2 - B em Texto
            b2yt1 = num2str ( b2y , '%2.2f' );
            b2zt1 = num2str ( b2z , '%2.2f' );
            
            % Transforma��o do Ponto 2 - C em Texto
            c2yt1 = num2str ( c2y , '%2.2f' );
            c2zt1 = num2str ( c2z , '%2.2f' );
            
            % Transforma��o do Ponto 2 - D em Texto
            d2yt1 = num2str ( d2y , '%2.2f' );
            d2zt1 = num2str ( d2z , '%2.2f' );
            
            % Convers�o para o Formato ASCII do Ponto 2 - A            
            [ a2yt ] = convert_text_end ( a2yt1 );
            [ a2zt ] = convert_text_end ( a2zt1 );
           
            % Convers�o para o Formato ASCII do Ponto 2 - B           
            [ b2yt ] = convert_text_end ( b2yt1 );
            [ b2zt ] = convert_text_end ( b2zt1 );
            
            % Convers�o para o Formato ASCII do Ponto 2 - C            
            [ c2yt ] = convert_text_end ( c2yt1 );
            [ c2zt ] = convert_text_end ( c2zt1 );
            
            % Convers�o para o Formato ASCII do Ponto 2 - D            
            [ d2yt ] = convert_text_end ( d2yt1 );
            [ d2zt ] = convert_text_end ( d2zt1 );
            
            % Escrita do Ponto 2 - A
            fprintf ( fileID , a2zt       );
            fprintf ( fileID , a2yt       );
            
            % Escrita do Ponto 2 - B
            fprintf ( fileID , b2zt       );
            fprintf ( fileID , b2yt       );
            
            % Escrita do Ponto 2 - C
            fprintf ( fileID , c2zt       );
            fprintf ( fileID , c2yt       );
            
            % Escrita do Ponto 2 - D
            fprintf ( fileID , d2zt       );
            fprintf ( fileID , d2yt       );
            
            % Termos Adicionais
            fprintf ( fileID , '+       \n' );
            fprintf ( fileID , '+       \n'  );    
        
        end    
    
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_prop : %2.2f s.\n', t2 );
    
end