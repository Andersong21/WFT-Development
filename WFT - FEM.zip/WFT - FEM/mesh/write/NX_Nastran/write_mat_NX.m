%% Retorno da Escrita dos Materiais da Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  
% Mat_Param         - Estrutura de Dados dos Materiais do Problema

%% OUPTUT
% fileID            - Carta do Problema com Materiais Preenchidos

%% Declara��o da Fun��o de Escrita dos Materiais na Carta -- NX Nastran
function [ fileID ] = write_mat_NX ( fileID , Mat_Param )

    %%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%% 
    
    % Inicializa��o do Tempo
    t1 = cputime;
   
    % Escrita Inicial do Material
    fprintf ( fileID , '$ Femap with NX Nastran Material 1 : Mat\n' );
    fprintf ( fileID , 'MAT1    '   );
    fprintf ( fileID , '       1'   );
        
    % Transforma��o do M�dulo de Elasticidade em Texto
    Et1 = int2str ( Mat_Param ( 1 ).E );
    
    % Adi��o do Ponto ao Final
    Et2 = [ Et1 , '.' ];
    
    % Convers�o para o Formato ASCII do M�dulo de Elasticidade
    [ Et ] = convert_text_end ( Et2 );
    
    % Escrita do M�dulo de Elasticidade
    fprintf ( fileID , Et           );
    fprintf ( fileID , '        '   );
    
    % Transforma��o do Coeficiente de Poisson em Texto
    Pt1 = num2str ( Mat_Param ( 1 ).poisson , 1 );
    
    % Convers�o para o Formato ASCII do Coeficiente de Poisson
    [ Pt ] = convert_text_end ( Pt1 );
    
    % Escrita do Coeficiente de Poisson
    fprintf ( fileID , Pt           );
    
    % Transforma��o da Densidade em Texto
    dt1 = num2str ( Mat_Param ( 1 ).rho , '%2.2e' );

    % Elimina��o do Caracter e
    dt2 = regexprep( dt1 ,'e' ,'');

    % Convers�o para o Formato ASCII da Densidade
    [ dt ] = convert_text_end ( dt2 );

    % Escrita da Densidade
    fprintf ( fileID , dt       );
    
    % Termos Adicionais
    fprintf ( fileID , '      0.'   );
    fprintf ( fileID , '      0.\n' );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_mat : %2.2f s.\n', t2 );
    
end