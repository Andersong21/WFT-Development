%% Retorno da Escrita das For�as da Carta do Problema -- NX Nastran

%% INPUT
% fileID            - Carta do Problema  

%% OUPTUT
% fileID            - Carta do Problema com For�as Preenchidas

%% Declara��o da Fun��o de Escrita das For�as na Carta -- NX Nastran
function [ fileID ] = write_force_NX ( fileID )

    %%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS FOR�AS %
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;

    % Escrita das For�as
    fprintf ( fileID , '$ Femap with NX Nastran Load Set 1 : ForceConditions\n' );
    
    % For�as Translacionais
    fx = 5200;
    fy = 5200;
    fz = 5200;
    
    % Transforma��o em Texto das For�as Translacionais
    fxt1 = num2str ( fx , '%2.2f' );
    fyt1 = num2str ( fy , '%2.2f' );
    fzt1 = num2str ( fz , '%2.2f' );
    
    % Convers�o para o Formato ASCII das For�as Translacionais
    [ fxt ] = convert_text_end ( fxt1 );
    [ fyt ] = convert_text_end ( fyt1 );
    [ fzt ] = convert_text_end ( fzt1 );
    
    % Escrita das For�as Translacionais
    fprintf ( fileID , 'FORCE   ' );
    fprintf ( fileID , '       1' );
    fprintf ( fileID , '       1' );
    fprintf ( fileID , '       0' );
    fprintf ( fileID , '      1.' );
    fprintf ( fileID , fxt        );
    fprintf ( fileID , fyt        );
    fprintf ( fileID , fzt        );
    fprintf ( fileID , '\n'       );
    
    % Momentos
    mx = 1400000;
    my = 1400000;
    mz = 1400000;
    
    % Transforma��o em Texto dos Momentos
    mxt1 = num2str ( mx , '%2.2e' );
    myt1 = num2str ( my , '%2.2e' );
    mzt1 = num2str ( mz , '%2.2e' );
    
    % Elimina��o do char e
    mxt2 = regexprep( mxt1 ,'e' ,'');
    myt2 = regexprep( myt1 ,'e' ,'');
    mzt2 = regexprep( mzt1 ,'e' ,'');    
    
    % Convers�o para o Formato ASCII dos Momentos
    [ mxt ] = convert_text_end ( mxt2 );
    [ myt ] = convert_text_end ( myt2 );
    [ mzt ] = convert_text_end ( mzt2 );
    
    % Escrita dos Momentos
    fprintf ( fileID , 'MOMENT  ' );
    fprintf ( fileID , '       1' );
    fprintf ( fileID , '       1' );
    fprintf ( fileID , '       0' );
    fprintf ( fileID , '      1.' );
    fprintf ( fileID , mxt        );
    fprintf ( fileID , myt        );
    fprintf ( fileID , mzt        );
    fprintf ( fileID , '\n'       );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_force : %2.2f s.\n', t2 );
           
end