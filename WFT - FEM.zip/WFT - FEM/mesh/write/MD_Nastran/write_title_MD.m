%% Retorno da Escrita do T�tulo da Carta do Problema

%% INPUT
% fileID            - Carta do Problema  

%% OUPTUT
% fileID            - Carta do Problema com Cabe�alho

%% Declara��o da Fun��o de Escrita do T�tulo da Carta
function [ fileID ] = write_title ( fileID )

    %%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO CABE�ALHO %
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;

    % Escrita do Cabe�alho
    fprintf ( fileID , '$ NASTRAN input file created by the FEM Parameter Optimizer input file translator\n' );
    fprintf ( fileID , '$ Direct Text Input for Nastran System Cell Section\n' );
    fprintf ( fileID , '$ Direct Text Input for File Management Section\n' );
    fprintf ( fileID , '$ Direct Text Input for Executive Control\n' );
    fprintf ( fileID , '$ Linear Static Analysis, Database\n' );
    
    % Escrita da Solu��o
    fprintf ( fileID , 'SOL 101\n' );
    fprintf ( fileID , 'CEND\n' );
    
    % Escrita do T�tulo
    fprintf ( fileID , '$ Direct Text Input for Global Case Control Data\n' );
    fprintf ( fileID , 'TITLE = MSC.Nastran job created on 27-Oct-15 at 09:08:59\n' );
    fprintf ( fileID , 'ECHO = NONE\n' );
    fprintf ( fileID , 'SUBCASE 1\n' );
    fprintf ( fileID , '$ Subcase name : Default\n' );
    fprintf ( fileID , '   SUBTITLE=Default\n' );
    fprintf ( fileID , '   SPC = 2\n' );
    fprintf ( fileID , '   LOAD = 3\n' );
    fprintf ( fileID , '   DISPLACEMENT(SORT1,REAL)=ALL\n' );
    fprintf ( fileID , '   SPCFORCES(SORT1,REAL)=ALL\n' );
    fprintf ( fileID , '   STRESS(SORT1,REAL,VONMISES,BILIN)=ALL\n' );    
    fprintf ( fileID , 'BEGIN BULK\n' );
    fprintf ( fileID , '$ Direct Text Input for Bulk Data\n' );
    fprintf ( fileID , 'PARAM    POST    0\n' );
    fprintf ( fileID , 'PARAM   PRTMAXIM YES\n' );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_title : %2.2f s.\n', t2 );
           
end