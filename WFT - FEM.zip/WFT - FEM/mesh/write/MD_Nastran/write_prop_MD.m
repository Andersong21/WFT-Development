%% Retorno da Escrita das Propriedades da Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema  
% Prop_Param        - Estrutura de Dados das Propriedades do Problema

%% OUPTUT
% fileID            - Carta do Problema com Propriedades Preenchidas

%% Declara��o da Fun��o de Escrita das Propriedades na Carta -- MD Nastran
function [ fileID ] = write_prop_MD ( fileID , Prop_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de Proprieades
    Nprop = Prop_Param ( end ).id;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS PROPRIEDADES 2D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita da Propriedade PSHELL
    fprintf ( fileID , '$ Element Properties for region : Plate\n' );
    
    % Transforma��o da Espessura em Texto
    Tt1 = int2str ( Prop_Param ( 1 ).thick );
    
    % Adi��o do Ponto ao Final
    Tt2 = [ Tt1 , '.' ];
    
    % Convers�o para o Formato ASCII da Espessura
    [ Tt ] = convert_text_begin ( Tt2 ); 
    
    % Escrita dos Par�metros da Propriedade PSHELL
    fprintf ( fileID , 'PSHELL   '  );
    fprintf ( fileID , '1       '   );
    fprintf ( fileID , '1       '   );
    fprintf ( fileID , Tt           );
    fprintf ( fileID , '1       '   );
    fprintf ( fileID , '        '   );
    fprintf ( fileID , '1       \n' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS PROPRIEDADES 1D %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Propriedades 1D    
    fprintf ( fileID , '$ Element Properties for region : Beam\n' );    
    
    % Escrita das Se��es
    for i = 2:Nprop
    
        % Verifica��o do Elemento Tipo 1D
        if ( strcmp ( Prop_Param ( i ).type , '1d' ) == 1 )
        
            % Escrita do PBEAM
            fprintf ( fileID , 'PBEAML   ' );
            
            % Transforma��o do Id da Se��o em Texto
            Idst = int2str ( Prop_Param ( i ).id );    
    
            % Convers�o para o Formato ASCII do Id da Se��o
            [ Ids ] = convert_text_begin ( Idst );  
    
            % Escrita do Id da Se��o
            fprintf ( fileID , Ids        );
            
            % Associa��o com o Material
            fprintf ( fileID , '1       ' );
            
            % Par�metros Vazios
            fprintf ( fileID , '        ' );
            
            % Tipo de Se��o
            fprintf ( fileID , 'BAR\n'    );
            
            % Par�metros Vazios
            fprintf ( fileID , '        ' );
            
            % Base da Propriedade
            b = ( Prop_Param ( i ).b ( 1 ) + Prop_Param ( i ).b ( 2 ) ) / 2;
            
            % Altura da Propriedade
            h = ( Prop_Param ( i ).h ( 1 ) + Prop_Param ( i ).h ( 2 ) ) / 2;
            
            % Transforma��o do Base em Texto
            bt = num2str ( b , '%2.2f' );
            
            % Transforma��o do Altura em Texto
            ht = num2str ( h , '%2.2f' );
            
            % Convers�o para o Formato ASCII da Base        
            [ B1 ] = convert_text_begin ( bt );
            
            % Convers�o para o Formato ASCII da Altura do       
            [ H1 ] = convert_text_begin ( ht );
            
            % Escrita da Altura do Ponto 1
            fprintf ( fileID , H1         );
            
            % Escrita da Base do Ponto 1
            fprintf ( fileID , B1         );
            
            % Nova Linha
            fprintf ( fileID , '\n' );
        
        end    
    
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_prop : %2.2f s.\n', t2 );
    
end