%% Retorno da Escrita das For�as da Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema 
% Node_Param        - Estrutura de Dados dos N�s do Problema

%% OUPTUT
% fileID            - Carta do Problema com For�as Preenchidas

%% Declara��o da Fun��o de Escrita das For�as na Carta -- MD Nastran
function [ fileID ] = write_force_MD ( fileID , Node_Param )

    %%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS FOR�AS %
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Quantidade de N�s
    Nnode = Node_Param ( end ).id;

    % Escrita das For�as
    fprintf ( fileID , '$ Nodal Forces of Load Set : ForceConditions\n' );
    
    % Varredura nos N�s
    for i = 1:Nnode
        
        % Verifica��o se � um N� de For�a
        if ( strcmp ( Node_Param ( i ).force , 'Y' ) == 1 )
            
            % Transforma��o do Id do N� em Texto
            Idnt1 = int2str ( Node_Param ( i ).id );
            
            % Convers�o para o Formato ASCII dos Momentos
            [ Idnt ] = convert_text_begin ( Idnt1 );
   
            % For�as Translacionais
            fx = Node_Param ( i ).force_value ( 1 );
            fy = Node_Param ( i ).force_value ( 2 );
            fz = Node_Param ( i ).force_value ( 3 );
    
            % Transforma��o em Texto das For�as Translacionais
            fxt1 = num2str ( fx , '%2.2f' );
            fyt1 = num2str ( fy , '%2.2f' );
            fzt1 = num2str ( fz , '%2.2f' );
    
            % Convers�o para o Formato ASCII das For�as Translacionais
            [ fxt ] = convert_text_begin ( fxt1 );
            [ fyt ] = convert_text_begin ( fyt1 );
            [ fzt ] = convert_text_begin ( fzt1 );
    
            % Escrita das For�as Translacionais
            fprintf ( fileID , 'FORCE    ' );
            fprintf ( fileID , '1       '  );
            fprintf ( fileID , Idnt        );
            fprintf ( fileID , '0      '   );
            fprintf ( fileID , '1.      '  );
            fprintf ( fileID , fxt         );
            fprintf ( fileID , fyt         );
            fprintf ( fileID , fzt         );
            fprintf ( fileID , '\n'        );
    
            % Momentos
            mx = Node_Param ( i ).force_value ( 4 );
            my = Node_Param ( i ).force_value ( 5 );
            mz = Node_Param ( i ).force_value ( 6 );
    
            % Transforma��o em Texto dos Momentos
            mxt1 = num2str ( mx , '%2.2e' );
            myt1 = num2str ( my , '%2.2e' );
            mzt1 = num2str ( mz , '%2.2e' );
    
            % Elimina��o do char e
            mxt2 = regexprep( mxt1 ,'e' ,'');
            myt2 = regexprep( myt1 ,'e' ,'');
            mzt2 = regexprep( mzt1 ,'e' ,'');    
    
            % Convers�o para o Formato ASCII dos Momentos
            [ mxt ] = convert_text_begin ( mxt2 );
            [ myt ] = convert_text_begin ( myt2 );
            [ mzt ] = convert_text_begin ( mzt2 );
    
            % Escrita dos Momentos
            fprintf ( fileID , 'MOMENT   ' );
            fprintf ( fileID , '1       '  );
            fprintf ( fileID , Idnt        );
            fprintf ( fileID , '0      '   );
            fprintf ( fileID , '1.      '  );
            fprintf ( fileID , mxt         );
            fprintf ( fileID , myt         );
            fprintf ( fileID , mzt         );
            fprintf ( fileID , '\n'        );
            
        end
        
    end

    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_force : %2.2f s.\n', t2 );
           
end