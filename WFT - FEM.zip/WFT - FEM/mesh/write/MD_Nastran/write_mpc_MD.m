%% Retorno da Escrita dos Mpcs da Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema  
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mpc_Param         - Estrutura de Dados dos Mpc do Problema

%% OUPTUT
% fileID            - Carta do Problema com Mpc Preenchidos

%% Declara��o da Fun��o de Escrita dos Mpcs na Carta -- MD Nastran
function [ fileID ] = write_mpc_MD ( fileID , Elem_Param , Mpc_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id + 1;
    
    % Quantidade de Mpcs
    Nmpc  = Mpc_Param ( end ).id;    

    %%%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS MPCS %
    %%%%%%%%%%%%%%%%%%%%
    
    % Escrita dos MPCs
    fprintf ( fileID , '$ Element for : Multi Point Constraint\n' );
    
    % Escrita dos Mpcs    
    for i = 1:Nmpc          
  
        % Inicializa��o do Mpc
        fprintf ( fileID , 'RBE2     ' );
        
        % Contador de Termos
        Ncont = 1;
        
        % Transforma��o do Id do Mpc em Texto
        Idt1 = int2str ( Nelem + i );

        % Convers�o para o Formato ASCII do Id do Mpc
        [ Idt ] = convert_text_begin ( Idt1 );

        % Escrita do Id do Mpc
        fprintf ( fileID , Idt        );
        
        % Atualiza��o do Contador de Linhas
        Ncont = Ncont + 1;
        
        % Transforma��o do Id do N� Independente em Texto
        Idn1 = int2str ( Mpc_Param ( i ).node_ind ( 1 ) );
        
        % Convers�o para o Formato ASCII do Id do N� Independente
        [ Idn ] = convert_text_begin ( Idn1 );
        
        % Escrita do Id do N� Independente
        fprintf ( fileID , Idn        );
        
        % Atualiza��o do Contador de Linhas
        Ncont = Ncont + 1;
        
        % Graus de Liberade Relacionados ao Mpc
        fprintf ( fileID , '123456  ' ); 
        
        % Atualiza��o do Contador de Linhas
        Ncont = Ncont + 1;
        
        % Varredura nos N�s Dependentes do Mpc
        for j = 1:length ( Mpc_Param ( i ).node_dep )
        
            % Transforma��o do Id do N� Dependente em Texto
            Idn2 = int2str ( Mpc_Param ( i ).node_dep ( j ) );
            
            % Convers�o para o Formato ASCII do Id do N� Dependente
            [ Idd ] = convert_text_begin ( Idn2 );
            
            % Escrita do Id do N� Dependente
            fprintf ( fileID , Idd        );
            
            % Atualiza��o do Contador de Linhas
            Ncont = Ncont + 1;
            
            % Quebra de Linha
            if ( Ncont == 9 )
            
                % Termos Adicionais
                fprintf ( fileID , '\n'          );
                fprintf ( fileID , '         '   );
                
                % Restart do Contador 
                Ncont = 1;
            
            end
            
        end
        
        % Adi��o de Linha ao Final
        fprintf ( fileID , '\n' );        
    
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_mpc : %2.2f s.\n', t2 );

end