%% Retorno da Escrita dos Materiais da Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema  
% Mat_Param         - Estrutura de Dados dos Materiais do Problema

%% OUPTUT
% fileID            - Carta do Problema com Materiais Preenchidos

%% Declara��o da Fun��o de Escrita dos Materiais na Carta -- MD Nastran
function [ fileID ] = write_mat_MD ( fileID , Mat_Param )

    %%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%% 
    
    % Inicializa��o do Tempo
    t1 = cputime;
   
    % Escrita Inicial do Material
    fprintf ( fileID , '$ Material Properties : Material\n' );
    fprintf ( fileID , 'MAT1     '  );
    fprintf ( fileID , '1      '    );
        
    % Transforma��o do M�dulo de Elasticidade em Texto
    Et1 = int2str ( Mat_Param ( 1 ).E );
    
    % Adi��o do Ponto ao Final
    Et2 = [ Et1 , '.' ];
    
    % Convers�o para o Formato ASCII do M�dulo de Elasticidade
    [ Et ] = convert_text_begin ( Et2 );
    
    % Escrita do M�dulo de Elasticidade
    fprintf ( fileID , Et           );
    fprintf ( fileID , '        '   );
    
    % Transforma��o do Coeficiente de Poisson em Texto
    Pt1 = num2str ( Mat_Param ( 1 ).poisson , 1 );
    
    % Convers�o para o Formato ASCII do Coeficiente de Poisson
    [ Pt ] = convert_text_begin ( Pt1 );
    
    % Escrita do Coeficiente de Poisson
    fprintf ( fileID , Pt           );
    
    % Transforma��o da Densidade em Texto
    dt1 = num2str ( Mat_Param ( 1 ).rho , '%2.2e' );

    % Elimina��o do Caracter e
    dt2 = regexprep( dt1 ,'e' ,'');

    % Convers�o para o Formato ASCII da Densidade
    [ dt ] = convert_text_begin ( dt2 );

    % Escrita da Densidade
    fprintf ( fileID , dt       );
    
    % Nova Linha
    fprintf ( fileID , '\n' );

    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_mat : %2.2f s.\n', t2 );
    
end