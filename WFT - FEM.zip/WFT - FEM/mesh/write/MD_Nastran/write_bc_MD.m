%% Retorno da Escrita das Condi��es de Contorno da Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema  
% Node_Param        - Estrutura de Dados dos N�s do Problema

%% OUPTUT
% fileID            - Carta do Problema com Condi��es Contorno Preenchidas

%% Declara��o da Fun��o de Escrita das Condi��es de Contorno na Carta -- MD Nastran
function [ fileID ] = write_bc_MD ( fileID , Node_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de N�s
    Nnode = Node_Param ( end ).id;
    
    %%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO LOADCASE %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita do Load Case
    fprintf ( fileID , '$ Loads for Load Case : Default\n' );
    fprintf ( fileID , 'SPCADD   2       1\n' );
    fprintf ( fileID , 'LOAD     2      1.      1.       1      1.       3\n' );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS CONDI��ES DE CONTORNO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Condi��es de Contorno
    fprintf ( fileID , '$ Displacement Constraints of Load Set : BoundaryConditions\n' );
  
    % Varredura nos N�s
    for i = 1:Nnode
        
        % Verifica��o se � um N� de Borda
        if ( strcmp ( Node_Param ( i ).border , 'Y' ) == 1 )
        
            % Escrita das Condi��es de Contorno
            fprintf ( fileID , 'SPC1     ' );
            
            % Tipo da Condi��o
            fprintf ( fileID , '1       '  );
            
            % Graus de Liberdade Restringidos
            fprintf ( fileID , '123     ' );
            
            % Transforma��o do Id do N� em Texto
            Idnt1 = int2str ( Node_Param ( i ).id );
            
            % Convers�o para o Formato ASCII dos Momentos
            [ Idnt ] = convert_text_begin ( Idnt1 );
            
            % Escrita do Id do N�
            fprintf ( fileID , Idnt        );
            
            % Quebra de Linha
            fprintf ( fileID , '\n'        );      
        
        end
        
        % Verifica��o se � um N� de Borda
        if ( strcmp ( Node_Param ( i ).border , 'YY' ) == 1 )
        
            % Escrita das Condi��es de Contorno
            fprintf ( fileID , 'SPC1     ' );
            
            % Tipo da Condi��o
            fprintf ( fileID , '1       '  );
            
            % Graus de Liberdade Restringidos
            fprintf ( fileID , '123456  ' );
            
            % Transforma��o do Id do N� em Texto
            Idnt1 = int2str ( Node_Param ( i ).id );
            
            % Convers�o para o Formato ASCII dos Momentos
            [ Idnt ] = convert_text_begin ( Idnt1 );
            
            % Escrita do Id do N�
            fprintf ( fileID , Idnt        );
            
            % Quebra de Linha
            fprintf ( fileID , '\n'        );      
        
        end 
    
    end  
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_bc : %2.2f s.\n', t2 );
           
end