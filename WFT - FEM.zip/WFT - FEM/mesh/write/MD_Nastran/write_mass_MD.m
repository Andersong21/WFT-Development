%% Retorno da Escrita da Massa Concentrada na Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema  
% Elem_Param        - Estrutura de Dados dos Elementos do Problema

%% OUPTUT
% fileID            - Carta do Problema com Mpc Preenchidos

%% Declara��o da Fun��o de Escrita da Massa Concentrada na Carta -- MD Nastran
function [ fileID ] = write_mass_MD ( fileID , Elem_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DA MASSA CONCENTRADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Escrita da Massa Concentrada
    fprintf ( fileID , '$ Element for : Concentrate Mass\n' );
      
    % Inicializa��o do Mpc
    fprintf ( fileID,  'CONM1    ' );
    
    % Transforma��o do Id da Massa Concentrada em Texto
    Idm1 = int2str ( Elem_Param ( end ).id + 1 );
    
    % Convers�o para o Formato ASCII do Id da Massa Concentrada
    [ Idm ] = convert_text_begin ( Idm1 );        

    % Escrita do Id da Massa Concentrada
    fprintf ( fileID , Idm        );
    
    % Transforma��o do Id do N� Associado a Massa Concentrada em Texto
    Idn1 = int2str ( Elem_Param ( end ).node ( 1 ) );
    
    % Convers�o para o Formato ASCII do Id do N� Associado a Massa Concentrada
    [ Idn ] = convert_text_begin ( Idn1 );        

    % Escrita do Id do N� associado a Massa Concentrada
    fprintf ( fileID , Idn        );
    
    % Termos Adicionais
    fprintf ( fileID,  '       ' );
    
    % Transforma��o da Massa Concentrada em Texto
    m1 = num2str ( Elem_Param ( end ).mass , '%2.2e' );

    % Elimina��o do Caracter e
    m2 = regexprep( m1 ,'e' ,'');

    % Convers�o para o Formato ASCII da Massa Concentrada
    [ m ] = convert_text_begin ( m2 ); 

    % Escrita do Id da Massa Concentrada
    fprintf ( fileID , m        );
    
    % Termos Adicionais
    fprintf ( fileID,  '      0.' );
    fprintf ( fileID , m          );
    fprintf ( fileID , '\n'       );
    fprintf ( fileID , '        ' );
    fprintf ( fileID , m          );
    fprintf ( fileID,  '\n' );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_mass : %2.2f s.\n', t2 );

end