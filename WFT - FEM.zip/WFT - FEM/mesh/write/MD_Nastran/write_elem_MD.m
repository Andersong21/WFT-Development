%% Retorno da Escrita dos Elementos da Carta do Problema -- MD Nastran

%% INPUT
% fileID            - Carta do Problema  
% Elem_Param        - Estrutura de Dados dos Elementos do Problema

%% OUPTUT
% fileID            - Carta do Problema com Elementos Preenchidos

%% Declara��o da Fun��o de Escrita dos Elementos na Carta -- MD Nastran
function [ fileID ] = write_elem_MD ( fileID , Elem_Param )

    % Inicializa��o do Tempo
    t1 = cputime;

    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id;

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita dos Elementos
    fprintf ( fileID , '$ Element for regions : Plate and Beam\n' );
    
    % Escrita dos Elementos    
    for i = 1:Nelem
        
        % TIPO CQUAD4
        if ( strcmp ( Elem_Param ( i ).type , '2d' ) == 1 )
            
            % Inicializa��o do Elemento
            fprintf ( fileID , 'CQUAD4   ' );

            % Transforma��o do Id do Elemento em Texto
            Idt1 = int2str ( Elem_Param ( i ).id );

            % Convers�o para o Formato ASCII do Id do Elemento
            [ Idt ] = convert_text_begin ( Idt1 );
            
            % Escrita do Id do Elemento
            fprintf ( fileID , Idt        );
            fprintf ( fileID , '1       ' );
            
            % Varredura na Lista de N�s
            for j = 1:4
                
                % Transforma��o do Id do N� i do Elemento em Texto
                Idn1 = int2str ( Elem_Param ( i ).node ( j ) );
                
                % Convers�o para o Formato ASCII do Id do N� i do Elemento
                [ Idn ] = convert_text_begin ( Idn1 );
                
                % Escrita do Id do Elemento
                fprintf ( fileID , Idn        );          
            
            end
            
            % Adi��o de Linha ao Final
            fprintf ( fileID , '\n' );
            
        end
        
        % TIPO CBEAM
        if ( strcmp ( Elem_Param ( i ).type , '1d' ) == 1 )
            
            % Inicializa��o do Elemento
            fprintf ( fileID , 'CBEAM    ' );

            % Transforma��o do Id do Elemento em Texto
            Idt1 = int2str ( Elem_Param ( i ).id );

            % Convers�o para o Formato ASCII do Id do Elemento
            [ Idt ] = convert_text_begin ( Idt1 );
            
            % Escrita do Id do Elemento
            fprintf ( fileID , Idt        );
            
            % Transforma��o do Id da Se��o do Elemento em Texto
            Ids1 = int2str ( Elem_Param ( i ).prop_id );

            % Convers�o para o Formato ASCII do Id da Se��o do Elemento
            [ Ids ] = convert_text_begin ( Ids1 );
            
            % Escrita do Id da Se��o do Elemento
            fprintf ( fileID , Ids        );

            % Varredura na Lista de N�s
            for j = 1:2
                
                % Transforma��o do Id do N� i do Elemento em Texto
                Idn1 = int2str ( Elem_Param ( i ).node ( j ) );
                
                % Convers�o para o Formato ASCII do Id do N� i do Elemento
                [ Idn ] = convert_text_begin ( Idn1 );
                
                % Escrita do Id do Elemento
                fprintf ( fileID , Idn        );          
            
            end
            
            % Cria��o do Vetor Perpendicular
            fprintf ( fileID , '0.      0.     1.');

            % Adi��o de Linha ao Final
            fprintf ( fileID , '\n' );
            
        end   
    
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('write_elem : %2.2f s.\n', t2 );

end