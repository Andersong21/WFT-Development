%% Retorno da Escrita da Malha do Problema -- NX NASTRAN

%% INPUT
% Mat_Param         - Estrutura de Dados dos Materiais da Malha
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Node_Param        - Estrutura de Dados dos N�s da Malha
% Elem_Param        - Estrutura de Dados dos Elementos da Malha
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha

%% Declara��o da Fun��o de Escrita da Malha do Problema -- NX NASTRAN
function write_mesh_NX_Nastran ( Mat_Param , Prop_Param , Node_Param  , Elem_Param , Mpc_Param )

    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Abertura do Arquivo da Malha
    fileID = fopen ( 'mesh.bdf' , 'wt' );
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO CABE�ALHO %
    %%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita do Cabe�alho
    [ fileID ] = write_title_NX ( fileID );
    
    %%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS FOR�AS %
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das For�as
    [ fileID ] = write_force_NX ( fileID );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS CONDI��ES DE CONTORNO %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Condi��es de Contorno
    [ fileID ] = write_bc_NX ( fileID , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DAS PROPRIEDADES %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita das Propriedades
    [ fileID ] = write_prop_NX ( fileID , Prop_Param );
      
    %%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DO MATERIAL %
    %%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita do Material
    [ fileID ] = write_mat_NX ( fileID , Mat_Param );
    
    %%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS N�S %
    %%%%%%%%%%%%%%%%%%%
    
    % Escrita dos N�s
    [ fileID ] = write_node_NX ( fileID , Node_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita dos Elementos
    [ fileID ] = write_elem_NX ( fileID , Elem_Param );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESCRITA DA MASSA CONCENTRADA %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Escrita da Matriz Concentrada
    [ fileID ] = write_mass_NX ( fileID , Elem_Param );
    
    %%%%%%%%%%%%%%%%%%%%
    % ESCRITA DOS MPCS %
    %%%%%%%%%%%%%%%%%%%%
    
    % Escrita dos Elementos
    [ fileID ] = write_mpc_NX ( fileID , Elem_Param , Mpc_Param );   
    
    %%%%%%%%%%%%%%%
    % FINALIZA��O %
    %%%%%%%%%%%%%%%
    
    % Finaliza��o da Escrita
    fprintf ( fileID , 'ENDDATA d99ab9be\n' );
    
    % Fechar Arquivo
    fclose ( 'all' );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    fprintf('write_mesh_NX : %2.2f s.\n', t2 );
    
end