%% Retorno do Gerador de Malha do Problema

%% INPUT
% b1                - Base da Se��o Transversal do N� Central
% h1                - Altura da Se��o Transversal do N� Central
% b2                - Base da Se��o Transversal do N� Extremidade
% h2                - Altura da Se��o Transversal do N� Extremidade
% L                 - Comprimento da Estrutura
% Lf                - Comprimento da Placa
% t                 - Espessura da Placa
% d                 - Rebaixo da Viga                    
% r                 - Raio do Centro da C�lulad de Carga 
% n                 - Quantidade de Elementos em Cada Estrutura
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha
% Mat_Param         - Estrutura de Dados dos Materiais da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha
% Elem_Param        - Estrutura de Dados dos Elementos da Malha
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha

%% Declara��o da Fun��o de Retorno do Gerador de Malha do Problema
function [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = get_mesh ( b1 , h1 , b2 , h2 , L , Lf , t , d , r , n , Prop_Param , Mpc_Param , Mat_Param )
    
    % Inicializa��o dos Par�metros de Malha
    [ Node_Param , Elem_Param , Mpc_Param ] = init_mesh ( Mpc_Param );
    
    % Defini��o da Malha 2D
    [ Node_Param , Elem_Param , Mpc_Param ] = create_mesh_2d ( h2 , b2 , L , Lf , r , n , Node_Param , Elem_Param , Mpc_Param );
    
    % Defini��o da Malha 1D
    [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = create_mesh_1d ( b1 , h1 , b2 , h2 , L , t , d , r , n , Node_Param , Elem_Param , Prop_Param , Mpc_Param , Mat_Param );
        
    % Cria��o dos Graus de Liberdade
    [ Node_Param ] = create_gl ( Node_Param );
    
end