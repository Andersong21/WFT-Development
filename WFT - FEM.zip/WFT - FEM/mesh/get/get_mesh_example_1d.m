%% Retorno do Gerador de Malha do Problema -- Exemplo beam2

%% INPUT
% b                 - Base da Se��o Transversal do Elemento
% h                 - Altura da Se��o Transversal do Elemento
% L                 - Comprimento da Estrutura
% n                 - Quantidade de Elementos
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha
% Mat_Param         - Estrutura de Dados dos Materiais da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha
% Elem_Param        - Estrutura de Dados dos Elementos da Malha
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha

%% Declara��o da Fun��o de Retorno do Gerador de Malha do Problema
function [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = get_mesh_example_1d ( b , h , L , n , Prop_Param , Mpc_Param , Mat_Param )
        
    % Defini��o da Malha 1D
    [ Node_Param , Elem_Param , Prop_Param ] = create_mesh_example_1d ( b , h , L , n , Prop_Param );
        
    % Cria��o dos Graus de Liberdade
    [ Node_Param ] = create_gl ( Node_Param );
    
end