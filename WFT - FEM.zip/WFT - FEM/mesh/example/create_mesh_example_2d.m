%% Defini��o dos N�s da Malha de Exemplo 2D

%% INPUT
% L1                - Largura da Placa
% L2                - Altura da Placa
% n                 - Quantidade de Elementos
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Mat_Param         - Estrutura de Dados dos Materiais da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha 1D e 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 1D e 2D
% Prop_Param        - Estrutura de Dados das Propriedades da Malha 1D e 2D

%% Declara��o da Fun��o de Defini��o dos N�s da Malha 2D
function [ Node_Param , Elem_Param , Prop_Param ] = create_mesh_example_2d ( L1 , L2 , n , Prop_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Inicializa��o Par�metros %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Timer
    t1 = cputime;

    % Quantidade de N�s
    Nnode = 1;
    
    % Quantidade de Elementos
    Nelem = 1;
    
    % Quantidade de Propriedades
    Nprop = Prop_Param ( end ).id;

    %%%%%%%%%%%%%%%%%%%%%%%
    % Defini��es Iniciais %
    %%%%%%%%%%%%%%%%%%%%%%%

    % Tamanho do Elemento na Altura
    s1 = ( L2 ) / n;

    % Tamanho do Elemento na Largura
    s2 = ( L1 ) / n;

    % Menor Tamanho do Elemento
    smin = min ( s1 , s2 );

    % Quantidade de Elementos na Altura
    n1 = fix ( L2 / ( smin ) );

    % Quantidade de Elementos na Largura
    n2 = fix ( L1 / ( smin ) );
    
    %%%%%%%%%%%%%%%%
    % N� In�cio BC %
    %%%%%%%%%%%%%%%%

    % Coordenada X In�cio da Boundary
    x1 = 0;

    % Coordenada Y In�cio da Boundary
    y1 = 0;

    %%%%%%%%%%%%%
    % N� Fim BC %
    %%%%%%%%%%%%%

    % Coordenada X Fim da Boundary
    x2 = L1;

    % Coordenada Y Fim da Boundary
    y2 = L2;

    %%%%%%%%%%%%%%%%%%%%%%%
    % Par�metros da Malha %
    %%%%%%%%%%%%%%%%%%%%%%%

    % Espa�amento em X
    dx = abs ( x2 - x1 ) / n2;
    
    % Espa�amento em Y
    dy = abs ( y2 - y1 ) / n1;

    %%%%%%%%%%%%%%%%%%%%
    % GERA��O DA MALHA %
    %%%%%%%%%%%%%%%%%%%%

    % Gera��o da Malha
    [ X , Y , ~ ] = meshgrid ( x1:dx:x2 , y1:dy:y2 , 0 );

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DA MALHA %
    %%%%%%%%%%%%%%%%%%%%%%%%%

    % Varredura na Lista de N�s da Camada X
    for i = 1:length ( X ( 1 , : , 1 ) )

        % Varredura na Lista de N�s da Camada Y
        for j = 1:length ( Y ( : , 1 , 1 ) )                    

            %%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DOS N�S % 
            %%%%%%%%%%%%%%%%%%%%%%%%

            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;

            % Defini��o da Coordenada X do N�
            Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , i , 1 );

            % Defini��o da Coordenada Y do N�
            Node_Param ( Nnode ).coord ( 2 ) = Y ( j , 1 , 1 );

            % Defini��o da Coordenada Z do N�
            Node_Param ( Nnode ).coord ( 3 ) = 0;

            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = 1;
            
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).border = 'YY';

            % Defini��o da Maneira como est� associado na an�lise
            Node_Param ( Nnode ).mpc_type = 'IND';         
            
            % Defini��o do N� de Borda
            if ( i == 1 )

                % Defini��o do N� de Borda
                Node_Param ( Nnode ).border = 'YY';
            else

                % Defini��o do N� de Borda
                Node_Param ( Nnode ).border = 'N';

            end
            
            % Defini��o do N� de For�a
            if ( i == length ( X ( 1 , : , 1 ) ) )

                % Defini��o do N� de For�a
                Node_Param ( Nnode ).force = 'Y';
                
            else

                % Defini��o do N� de Borda
                Node_Param ( Nnode ).force = 'N';

            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DOS ELEMENTOS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Cria��o dos Elementos
            if ( i > 1 && j ~= 1 )

                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '2d';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = 1;

                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                % Id do N� 3 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                % Id do N� 4 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                % Atualiza��o do Contador de Elementos
                Nelem = Nelem + 1;

            end

            % Atualiza��o do Contador de N�s
            Nnode = Nnode + 1; 

        end

    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_mesh_1d : %2.2f s.\n', t2 );
    
end