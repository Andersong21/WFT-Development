%% Defini��o dos N�s da Malha de Exemplo 1D

%% INPUT
% b                 - Base da Se��o Transversal do Elemento
% h                 - Altura da Se��o Transversal do Elemento
% L                 - Comprimento da Estrutura
% n                 - Quantidade de Elementos
% Prop_Param        - Estrutura de Dados das Propriedades da Malha
% Mat_Param         - Estrutura de Dados dos Materiais da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha 1D e 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 1D e 2D
% Prop_Param        - Estrutura de Dados das Propriedades da Malha 1D e 2D

%% Declara��o da Fun��o de Defini��o dos N�s da Malha 1D
function [ Node_Param , Elem_Param , Prop_Param ] = create_mesh_example_1d ( b , h , L , n , Prop_Param );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Inicializa��o Par�metros %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Timer
    t1 = cputime;

    % Quantidade de N�s
    Nnode = 1;
    
    % Quantidade de Elementos
    Nelem = 1;
    
    % Quantidade de Propriedades
    Nprop = Prop_Param ( end ).id + 1;

    %%%%%%%%%%%%%
    % ESTRUTURA %
    %%%%%%%%%%%%%
           
    % Defini��o do Id do N�
    Node_Param ( Nnode ).id = Nnode;

    % Defini��o das Coordenadas do N� -- Coordenada X
    Node_Param ( Nnode ).coord ( 1 ) = 0;

    % Defini��o das Coordenadas do N� -- Coordenada Y
    Node_Param ( Nnode ).coord ( 2 ) = 0;

    % Defini��o das Coordenadas do N� -- Coordenada Z
    Node_Param ( Nnode ).coord ( 3 ) = 0;

    % Defini��o da Estrutura Relacionada ao N�
    Node_Param ( Nnode ).estr = 1;

    % Defini��o do N� de Borda
    Node_Param ( Nnode ).border = 'YY';
    
    % Defini��o da Maneira como est� associado na an�lise
    Node_Param ( Nnode ).mpc_type = 'IND';
    
    % Defini��es dos Valores das For�as dos N�s
    Node_Param ( Nnode ).force = 'N';

    % Atualiza��o do N�mero de N�s
    Nnode = Nnode + 1;
    
    % Defini��o do Incremento - X
    DX = L / n;

    % Defini��o do Incremento - Y
    DY = 0;

    % Defini��o do Incremento - Z
    DZ = 0;
            
    % Quantidade de N�s a Serem Acrescidos
    Add_Node = n;
            
    % Varredura nos N�s Adicionais
    for j = Nnode:( Nnode + Add_Node - 1 )
                
        %%%%%%%%%%%%%%%%%%%%%%%%
        % ESTRUTURA��O DOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%

        % Defini��o do Id do N�
        Node_Param ( j ).id = j;
                
        % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
        Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

        % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
        Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

        % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
        Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
        % Defini��o da Estrutura Relacionada ao N�
        Node_Param ( j ).estr = 1;
                
        % Defini��o do N� de Borda
        Node_Param ( j ).border = 'N';
        
        % Defini��o da Maneira como est� associado na an�lise
        Node_Param ( j ).mpc_type = 'IND';
        
        % Defini��o da For�a no N�
        if ( j == ( Nnode + Add_Node - 1 ) )
            
            % Defini��es dos Valores das For�as dos N�s
            Node_Param ( j ).force = 'Y';
            
        else
            
            % Defini��es dos Valores das For�as dos N�s
            Node_Param ( j ).force = 'N';
            
        end            
                
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ESTRUTURA��O DOS ELEMENTOS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
        % Defini��o do Id do Elemento
        Elem_Param ( Nelem ).id   = Nelem;

        % Defini��o do Id da Propriedade ao Elemento
        Elem_Param ( Nelem ).prop_id = Nprop;

        % Defini��o do Tipo do Elemento
        Elem_Param ( Nelem ).type = '1d';

        % Defini��o da Parte do Elemento
        Elem_Param ( Nelem ).part = 'A';

        % Defini��o da Estrutura Relacionado
        Elem_Param ( Nelem ).estr = 1;

        % Id do N� 1 Associado ao Elemento
        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

        % Id do N� 2 Associado ao Elemento
        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ESTRUTURA��O DAS PROPRIEDADES %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Id da Propriedade
        Prop_Param ( Nprop ).id = Nprop;

        % Tipo da Propriedade
        Prop_Param ( Nprop ).type = '1d';

        % Defini��o dos Par�metros de Base
        Prop_Param ( Nprop ).b ( 1 ) = b;
        Prop_Param ( Nprop ).b ( 2 ) = b;

        % Defini��o dos Par�metros de Altura
        Prop_Param ( Nprop ).h ( 1 ) = h;
        Prop_Param ( Nprop ).h ( 2 ) = h;                         

        % Defini��o da �rea
        Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
        Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

        % Defini��o do Momento de In�rcia Iyy
        Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
        Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

        % Defini��o do Momento de In�rcia Izz
        Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
        Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

        % Defini��o do Momento Polar de In�rcia
        Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
        Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );

        %%%%%%%%%%%%%%%
        % INCREMENTOS %
        %%%%%%%%%%%%%%%

        % Incremento do Elemento
        Nelem = Nelem + 1;

        % Incremento da Propriedade
        Nprop = Nprop + 1;
        
    end        
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_mesh_1d : %2.2f s.\n', t2 );
    
end