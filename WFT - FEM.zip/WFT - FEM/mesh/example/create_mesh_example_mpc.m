%% Defini��o dos N�s da Malha de Exemplo MPC

%% INPUT
% b                 - Base da Se��o Transversal do Elemento
% h                 - Altura da Se��o Transversal do Elemento
% L1                - Largura da Placa
% t                 - Espessura da Placa
% n                 - Quantidade de Elementos
% Prop_Param        - Estrutura de Dados das Propriedades da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha 1D e 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 1D e 2D
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha 1D e 2D
% Prop_Param        - Estrutura de Dados das Propriedades da Malha 1D e 2D

%% Declara��o da Fun��o de Defini��o dos N�s da Malha MPC
function [ Node_Param , Elem_Param , Mpc_Param , Prop_Param ] = create_mesh_example_mpc ( b , h , L1 , t , n , Prop_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Inicializa��o Par�metros %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Timer
    t1 = cputime;
    
    % Quantidade de Estruturas
    N = 3;

    % Quantidade de N�s
    Nnode = 1;
    
    % Quantidade de Elementos
    Nelem = 1;
    
    % Quantidade de N�s Depedentes
    Ndep = 1;
    
    % Quantidade de Propriedades
    Nprop = Prop_Param ( end ).id + 1;
    
    %%%%%%%%%%%%
    % MALHA 1D %
    %%%%%%%%%%%%
           
    % Defini��o do Id do N�
    Node_Param ( Nnode ).id = Nnode;

    % Defini��o das Coordenadas do N� -- Coordenada X
    Node_Param ( Nnode ).coord ( 1 ) = 0;

    % Defini��o das Coordenadas do N� -- Coordenada Y
    Node_Param ( Nnode ).coord ( 2 ) = 0;

    % Defini��o das Coordenadas do N� -- Coordenada Z
    Node_Param ( Nnode ).coord ( 3 ) = 0;

    % Defini��o da Estrutura Relacionada ao N�
    Node_Param ( Nnode ).estr = 1;
    
    % Defini��o do N� de Borda
    Node_Param ( Nnode ).border = 'N';
    
    % Defini��o do N� de For�a
    Node_Param ( Nnode ).force = 'Y';
    
    % Defini��o da Maneira como est� associado na an�lise
    Node_Param ( Nnode ).mpc_type = 'IND';

    % Atualiza��o do N�mero de N�s
    Nnode = Nnode + 1;
    
    % Defini��o do Incremento - X
    DX = L1 / n;

    % Defini��o do Incremento - Y
    DY = 0;

    % Defini��o do Incremento - Z
    DZ = 0;
            
    % Quantidade de N�s a Serem Acrescidos
    Add_Node = n;
    
    % Varredura nos N�s Adicionais
    for j = Nnode:( Nnode + Add_Node - 1 )
                
        %%%%%%%%%%%%%%%%%%%%%%%%
        % ESTRUTURA��O DOS N�S %
        %%%%%%%%%%%%%%%%%%%%%%%%

        % Defini��o do Id do N�
        Node_Param ( j ).id = j;
                
        % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
        Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

        % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
        Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

        % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
        Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
        % Defini��o da Estrutura Relacionada ao N�
        Node_Param ( j ).estr = 1;
                
        % Defini��o do N� de Borda
        Node_Param ( j ).border = 'N';
        
        % Defini��es dos Valores das For�as dos N�s
        Node_Param ( j ).force = 'N';
        
        % Defini��o da Maneira como est� associado na an�lise
        Node_Param ( j ).mpc_type = 'IND';
        
        % Defini��o da For�a no N�
        if ( j == ( Nnode + Add_Node - 1 ) )           
            
            % Defini��o do Id do MPC relacionado ao N�
            Node_Param ( j ).mpc_id = 1;            
                        
            % Adi��o do Id ao MPC
            Mpc_Param ( 1 ).id = 1;

            % Adi��o do N� ao MPC
            Mpc_Param ( 1 ).node_ind ( 1 ) = j;
            
        end            
                
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ESTRUTURA��O DOS ELEMENTOS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
        % Defini��o do Id do Elemento
        Elem_Param ( Nelem ).id   = Nelem;

        % Defini��o do Id da Propriedade ao Elemento
        Elem_Param ( Nelem ).prop_id = Nprop;

        % Defini��o do Tipo do Elemento
        Elem_Param ( Nelem ).type = '1d';

        % Defini��o da Estrutura Relacionado
        Elem_Param ( Nelem ).estr = 1;

        % Id do N� 1 Associado ao Elemento
        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

        % Id do N� 2 Associado ao Elemento
        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % ESTRUTURA��O DAS PROPRIEDADES %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Id da Propriedade
        Prop_Param ( Nprop ).id = Nprop;

        % Tipo da Propriedade
        Prop_Param ( Nprop ).type = '1d';

        % Defini��o dos Par�metros de Base
        Prop_Param ( Nprop ).b ( 1 ) = b;
        Prop_Param ( Nprop ).b ( 2 ) = b;

        % Defini��o dos Par�metros de Altura
        Prop_Param ( Nprop ).h ( 1 ) = h;
        Prop_Param ( Nprop ).h ( 2 ) = h;                         

        %%%%%%%%%%%%%%%
        % INCREMENTOS %
        %%%%%%%%%%%%%%%

        % Incremento do Elemento
        Nelem = Nelem + 1;

        % Incremento da Propriedade
        Nprop = Nprop + 1;
        
    end
    
    % Atualiza��o da Numera��o dos N�s
    Nnode = Node_Param ( end ).id + 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O DA MALHA 2D %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nas Estruturas
    for i = 1:N
    
        %%%%%%%%%%%%%%%
        % ESTRUTURA 1 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 1
        if ( i == 1 )
            
            % Tamanho do Elemento na Altura
            s1 = ( h ) / n;

            % Tamanho do Elemento na Largura
            s2 = ( ( L1 / 2 ) - ( b / 2 ) ) / n;

            % Menor Tamanho do Elemento
            smin = min ( s1 , s2 );

            % Quantidade de Elementos na Altura
            n1 = fix ( h / ( smin ) );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( L1 / 2 ) - ( b / 2 ) ) / ( smin ) );

            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC % Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada Y In�cio da Boundary -- Parte A
            y1 = + ( L1 / 2 );

            % Coordenada Z In�cio da Boundary -- Parte A
            z1 = + ( h / 2 );

            %%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC % PARTE A %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada Y Fim da Boundary -- Parte A
            y2 = + ( b / 2 );

            % Coordenada Z Fim da Boundary -- Parte A
            z2 = - ( h / 2 );

            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y2 - y1 ) / n2;

            % Espa�amento em Z
            dz = abs ( z2 - z1 ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%

            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( L1 + ( t / 2 ) , y2:dy:y1 , z2:dz:z1 );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 1:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , 1 , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( length ( Y ( : , 1 , 1 ) ) - j + 1 , 1 , 1 );
                    
                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;
                    
                    % Defini��o do N� de For�a
                    Node_Param ( Nnode ).force = 'N';

                    % Defini��o do N� de Borda
                    if ( j == 1 )

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                        
                    else

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';

                    end
                    
                    % Defini��o do N� Dependente
                    if ( j == length ( Y ( : , 1 , 1 ) ) )
                        
                        % Defini��o do Id do MPC relacionado ao N�
                        Node_Param ( Nnode ).mpc_id = 1;

                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'DEP';

                        % Adi��o do N� ao MPC
                        Mpc_Param ( 1 ).node_dep ( Ndep ) = Nnode;

                        % Incremento no N�mero de N�s Dependentes
                        Ndep = Ndep + 1;                    
                    
                    else
                        
                        % Defini��o da Maneira como est� associado na an�lise
                        Node_Param ( Nnode ).mpc_type = 'IND';
                        
                    end
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'A';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end
            
        end        
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 2 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 2
        if ( i == 2 )

            % Tamanho do Elemento na Largura
            s2 = ( b ) / n;

            % Menor Tamanho do Elemento
            smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( b / ( smin ) );
            
            % Quantidade de Elementos Nulas
            if ( n2 == 0 )
                
                % Atualiza��o do Valor
                n2 = 1;
                
            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC % Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada Y In�cio da Boundary -- Parte B
            y1 = + ( b / 2 );

            % Coordenada Z In�cio da Boundary -- Parte B
            z1 = + ( h / 2 );

            %%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC % PARTE B %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada Y Fim da Boundary -- Parte B
            y2 = - ( b / 2 );

            % Coordenada Z Fim da Boundary -- Parte B
            z2 = - ( h / 2 );

            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y2 - y1 ) / n2;

            % Espa�amento em Z
            dz = abs ( z2 - z1 ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%

            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( L1 + ( t / 2 ) , y2:dy:y1 , z2:dz:z1 );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , 1 , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( length ( Y ( : , 1 , 1 ) ) - j + 1 , 1 , 1 );
                    
                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;
                    
                    % Defini��o do N� de For�a
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do N� de Borda
                    Node_Param ( Nnode ).border = 'N';
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( Nnode ).mpc_id = 1;

                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'DEP';

                    % Adi��o do N� ao MPC
                    Mpc_Param ( 1 ).node_dep ( Ndep ) = Nnode;

                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1; 
                   
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'B';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end        
            
        end
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 3 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 3
        if ( i == 3 )

            % Tamanho do Elemento na Largura
            s2 = ( ( L1 / 2 ) - ( b / 2 ) ) / n;

            % Menor Tamanho do Elemento
            smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( L1 / 2 ) - ( b / 2 ) ) / ( smin ) );
            
            % Quantidade de Elementos Nulas
            if ( n2 == 0 )
                
                % Atualiza��o do Valor
                n2 = 1;
                
            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC % Parte C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada Y In�cio da Boundary -- Parte C
            y1 = - ( b / 2 );

            % Coordenada Z In�cio da Boundary -- Parte C
            z1 = + ( h / 2 );

            %%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC % PARTE C %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Coordenada Y Fim da Boundary -- Parte C
            y2 = - ( L1 / 2 );

            % Coordenada Z Fim da Boundary -- Parte C
            z2 = - ( h / 2 );

            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y2 - y1 ) / n2;

            % Espa�amento em Z
            dz = abs ( z2 - z1 ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%

            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( L1 + ( t / 2 ) , y2:dy:y1 , z2:dz:z1 );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , 1 , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( length ( Y ( : , 1 , 1 ) ) - j + 1 , 1 , 1 );
                    
                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;
                    
                    % Defini��o do N� de For�a
                    Node_Param ( Nnode ).force = 'N';

                    % Defini��o do N� de Borda
                    if ( j == 1 )
                        
                        % Defini��o do Id do MPC relacionado ao N�
                        Node_Param ( Nnode ).mpc_id = 1;

                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'DEP';

                        % Adi��o do N� ao MPC
                        Mpc_Param ( 1 ).node_dep ( Ndep ) = Nnode;

                        % Incremento no N�mero de N�s Dependentes
                        Ndep = Ndep + 1;

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';

                    else
                        
                        % Defini��o da Maneira como est� associado na an�lise
                        Node_Param ( Nnode ).mpc_type = 'IND';
                        
                    end
                    
                    % Defini��o do N� Dependente
                    if ( j == length ( Y ( : , 1 , 1 ) ) )
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';                
                    
                    else
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';
                        
                    end                       
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'C';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end        
            
        end
        
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_mesh_1d : %2.2f s.\n', t2 );
    
end