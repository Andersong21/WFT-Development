%% Defini��o dos N�s da Malha de Exemplo MPC

%% INPUT
% L1                - Largura das Placas
% r                 - Dist�ncia entre Placas
% t                 - Espessura das Placas
% n                 - Quantidade de Elementos
% Prop_Param        - Estrutura de Dados das Propriedades da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha 1D e 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 1D e 2D
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha 1D e 2D
% Prop_Param        - Estrutura de Dados das Propriedades da Malha 1D e 2D

%% Declara��o da Fun��o de Defini��o dos N�s da Malha MPC
function [ Node_Param , Elem_Param , Mpc_Param , Prop_Param ] = create_mesh_example_mpc2 ( L1 , r , t , n , Prop_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Inicializa��o Par�metros %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Timer
    t1 = cputime;

    % Quantidade de N�s
    Nnode = 1;
    
    % Quantidade de Elementos
    Nelem = 1;
    
    % Quantidade de N�s Depedentes
    Ndep = 1;
    
    % Quantidade de Propriedades
    Nprop = 1;   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O DA MALHA 2D % PARTE A %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Tamanho do Elemento
    s = L1 / n;
    
    % Quantidade de Elementos
    n = fix ( L1 / s );

    %%%%%%%%%%%%%%%%
    % N� In�cio BC %
    %%%%%%%%%%%%%%%%
    
    % Coordenada X In�cio da Boundary
    x1 = 0;
    
    % Coordenada Y In�cio da Boundary
    y1 = 0;

    %%%%%%%%%%%%%
    % N� Fim BC %
    %%%%%%%%%%%%%

    % Coordenada X Fim da Boundary
    x2 = L1;
    
    % Coordenada Y Fim da Boundary
    y2 = L1;

    %%%%%%%%%%%%%%%%%%%%%%%
    % Par�metros da Malha %
    %%%%%%%%%%%%%%%%%%%%%%%

    % Espa�amento em X
    dx = abs ( x2 - x1 ) / n;

    % Espa�amento em Y
    dy = abs ( y2 - y1 ) / n;

    %%%%%%%%%%%%%%%%%%%%
    % GERA��O DA MALHA %
    %%%%%%%%%%%%%%%%%%%%

    % Gera��o da Malha
    [ X , Y , ~ ] = meshgrid ( x1:dx:x2 , y1:dy:y2 , 0 );

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DA MALHA %
    %%%%%%%%%%%%%%%%%%%%%%%%%

    % Varredura na Lista de N�s da Camada X
    for i = 1:length ( X ( 1 , : , 1 ) )

        % Varredura na Lista de N�s da Camada Y
        for j = 1:length ( Y ( : , 1 , 1 ) )
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DOS N�S % 
            %%%%%%%%%%%%%%%%%%%%%%%%

            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;

            % Defini��o da Coordenada X do N�
            Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , i , 1 );

            % Defini��o da Coordenada Y do N�
            Node_Param ( Nnode ).coord ( 2 ) = Y ( j , 1 , 1 );

            % Defini��o da Coordenada Z do N�
            Node_Param ( Nnode ).coord ( 3 ) = 0;

            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = 1;  
            
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).force = 'N';
            
            % Defini��o do N� de Borda
            if ( i == 1 )

                % Defini��o do N� de Borda
                Node_Param ( Nnode ).border = 'YY';
                
            else

                % Defini��o do N� de Borda
                Node_Param ( Nnode ).border = 'N';

            end
            
            % Defini��o do N� de MPC
            if ( i == length ( X ( 1 , : , 1 ) ) )
                
                % Defini��o da Maneira como est� associado na an�lise
                Node_Param ( Nnode ).mpc_type = 'DEP';
                
                % Defini��o do Id do MPC relacionado ao N�
                Node_Param ( Nnode ).mpc_id = 1;            

                % Adi��o do Id ao MPC
                Mpc_Param ( 1 ).id = 1;

                % Adi��o do N� ao MPC
                Mpc_Param ( 1 ).node_dep ( Ndep ) = Nnode;
                
                % Atualiza��o dos N�s Dependentes
                Ndep = Ndep + 1;
                
            else
                
                % Defini��o da Maneira como est� associado na an�lise
                Node_Param ( Nnode ).mpc_type = 'IND';  

            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DOS ELEMENTOS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Cria��o dos Elementos
            if ( i > 1 && j ~= 1 )

                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '2d';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = 1;

                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n - 2 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n - 1 ).id;

                % Id do N� 3 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                % Id do N� 4 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                % Atualiza��o do Contador de Elementos
                Nelem = Nelem + 1;

            end

            % Atualiza��o do Contador de N�s
            Nnode = Nnode + 1; 

        end

    end
    
    %%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O DO RBE2 %
    %%%%%%%%%%%%%%%%%%%%%
    
    % Defini��o do N� Central
    Node_Param ( Nnode ).id = Nnode;

    % Defini��o da Coordenada X do N�
    Node_Param ( Nnode ).coord ( 1 ) = L1 + ( r / 2 );

    % Defini��o da Coordenada Y do N�
    Node_Param ( Nnode ).coord ( 2 ) = L1/ 2;

    % Defini��o da Coordenada Z do N�
    Node_Param ( Nnode ).coord ( 3 ) = 0;

    % Defini��o da Estrutura Relacionada ao N�
    Node_Param ( Nnode ).estr = 2;
    
    % Defini��o da Maneira como est� associado na an�lise
    Node_Param ( Nnode ).mpc_type = 'IND';
    
    % Defini��o do N� de Borda
    Node_Param ( Nnode ).border = 'N';
    
    % Defini��o do N� de For�a
    Node_Param ( Nnode ).force = 'Y';
                
    % Defini��o do Id do MPC relacionado ao N�
    Node_Param ( Nnode ).mpc_id = 1;            

    % Adi��o do N� ao MPC
    Mpc_Param ( 1 ).node_ind ( 1 ) = Nnode;
    
    % Atualiza��o do N�mero de N�s
    Nnode = Nnode + 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O DA MALHA 2D % PARTE B %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Tamanho do Elemento
    s = L1 / n;
    
    % Quantidade de Elementos
    n = fix ( L1 / s );

    %%%%%%%%%%%%%%%%
    % N� In�cio BC %
    %%%%%%%%%%%%%%%%
    
    % Coordenada X In�cio da Boundary
    x1 = L1 + r;
    
    % Coordenada Y In�cio da Boundary
    y1 = 0;

    %%%%%%%%%%%%%
    % N� Fim BC %
    %%%%%%%%%%%%%

    % Coordenada X Fim da Boundary
    x2 = L1 + L1 + r;
    
    % Coordenada Y Fim da Boundary
    y2 = L1;

    %%%%%%%%%%%%%%%%%%%%%%%
    % Par�metros da Malha %
    %%%%%%%%%%%%%%%%%%%%%%%

    % Espa�amento em X
    dx = abs ( x2 - x1 ) / n;

    % Espa�amento em Y
    dy = abs ( y2 - y1 ) / n;

    %%%%%%%%%%%%%%%%%%%%
    % GERA��O DA MALHA %
    %%%%%%%%%%%%%%%%%%%%

    % Gera��o da Malha
    [ X , Y , ~ ] = meshgrid ( x1:dx:x2 , y1:dy:y2 , 0 );

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DA MALHA %
    %%%%%%%%%%%%%%%%%%%%%%%%%

    % Varredura na Lista de N�s da Camada X
    for i = 1:length ( X ( 1 , : , 1 ) )

        % Varredura na Lista de N�s da Camada Y
        for j = 1:length ( Y ( : , 1 , 1 ) )
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DOS N�S % 
            %%%%%%%%%%%%%%%%%%%%%%%%

            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;

            % Defini��o da Coordenada X do N�
            Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , i , 1 );

            % Defini��o da Coordenada Y do N�
            Node_Param ( Nnode ).coord ( 2 ) = Y ( j , 1 , 1 );

            % Defini��o da Coordenada Z do N�
            Node_Param ( Nnode ).coord ( 3 ) = 0;

            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = 1; 
            
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).border = 'N';

            % Defini��o do N� de Borda
            Node_Param ( Nnode ).force = 'N';
            
            % Defini��o do N� de MPC
            if ( i == 1 )
                
                % Defini��o da Maneira como est� associado na an�lise
                Node_Param ( Nnode ).mpc_type = 'DEP';
                
                % Defini��o do Id do MPC relacionado ao N�
                Node_Param ( Nnode ).mpc_id = 1;            

                % Adi��o do Id ao MPC
                Mpc_Param ( 1 ).id = 1;

                % Adi��o do N� ao MPC
                Mpc_Param ( 1 ).node_dep ( Ndep ) = Nnode;
                
                % Atualiza��o dos N�s Dependentes
                Ndep = Ndep + 1;
                
            else
                
                % Defini��o da Maneira como est� associado na an�lise
                Node_Param ( Nnode ).mpc_type = 'IND';  

            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DOS ELEMENTOS %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Cria��o dos Elementos
            if ( i > 1 && j ~= 1 )

                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '2d';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = 1;

                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n - 2 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n - 1 ).id;

                % Id do N� 3 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                % Id do N� 4 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                % Atualiza��o do Contador de Elementos
                Nelem = Nelem + 1;

            end

            % Atualiza��o do Contador de N�s
            Nnode = Nnode + 1; 

        end

    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_mesh_1d : %2.2f s.\n', t2 );
    
end