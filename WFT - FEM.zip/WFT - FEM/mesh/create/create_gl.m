%% Retorno de Cria��o dos Graus de Liberdade do Problema

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha

%% Declara��o da Fun��o de Cria��o dos Graus de Liberdade do Problema
function [ Node_Param ] = create_gl ( Node_Param )

    % Inicializa��o do Timer
    t1 = cputime;

    % Quantidade de N�s
    Nnode = Node_Param ( end ).id;
    
    % Inicializa��o dos Graus de Liberdade
    Ndof = 1;   
    
    % Inicializa��o do N�mero de N�s Dependentes
    Ndep = 1;
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Cria��o dos DOFs do Problema %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos N�s
    for i = 1:Nnode 
        
        % Verifica��o se o N� est� com rela��o de dependencia
        if ( strcmp ( Node_Param ( i ).mpc_type , 'DEP' ) == 1 )
           
            % Preenchimento da ordem do n� dependente
            Node_Param ( i ).node_dep = Ndep;
            
            % Atualiza��o da Quantidade de N�s Dependentes
            Ndep = Ndep + 1;
            
        else
            
            % Preenchimento da ordem do n� dependente
            Node_Param ( i ).node_dep = 0;
            
        end
            
        % Verifica��o se o N� est� Relacionado a uma Boundary Condition
        if ( strcmp ( Node_Param ( i ).border , 'YY' ) == 1 )

            % Aplica��o da Condi��o de Contorno
            for j = 1:6

                % Associa��o do Grau de Liberdade ao N�
                Node_Param ( i ).dof ( j ) = 0;                

            end

            % Continuar programa
            continue;

        end            
           
        % Verifica��o se o N� est� Relacionado a uma Boundary Condition
        if ( strcmp ( Node_Param ( i ).border , 'Y' ) == 1 )

            % Aplica��o da Condi��o de Contorno
            for j = 1:3

                % Associa��o do Grau de Liberdade ao N�
                Node_Param ( i ).dof ( j ) = 0;                

            end

            % Varredura nos Graus de Liberdade
            for j = 4:6

                % Associa��o do Grau de Liberdade ao N�
                Node_Param ( i ).dof ( j ) = Ndof;

                % Incremento nos Graus de Liberdade
                Ndof = Ndof + 1;

            end
            
            % Continuar programa
            continue;

        end
        
        % Verifica��o se o N� est� Relacionado a uma Boundary Condition
        if ( strcmp ( Node_Param ( i ).border , 'N' ) == 1 )

            % Varredura nos Graus de Liberdade
            for j = 1:6

                % Associa��o do Grau de Liberdade ao N�
                Node_Param ( i ).dof ( j ) = Ndof;

                % Incremento nos Graus de Liberdade
                Ndof = Ndof + 1;

            end 

        end           

    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_gl : %2.2f s.\n', t2 );
    
end