%% Defini��o da Malha 2D

%% INPUT
% h2                - Altura da Placa
% b2                - Largura da Se��o no Encontro com a Placa
% L                 - Comprimento da Estrutura Deform�vel
% Lf                - Comprimento da Placa
% r                 - Raio do Centro da C�lula de Carga          
% n                 - Quantidade de Elementos em Cada Estrutura
% Node_Param        - Estrutura de Dados dos N�s da Malha
% Elem_Param        - Estrutura de Dados dos Elementos da Malha
% Mpc_Param         - Estrutura de Dados dos Mpc

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 2D
% Mpc_Param         - Estrutura de Dados das Propriedades do Mpc 2D

%% Declara��o da Fun��o de Defini��o da Malha 2D
function [ Node_Param , Elem_Param , Mpc_Param ] = create_mesh_2d ( h2 , b2 , L , Lf , r , n , Node_Param , Elem_Param , Mpc_Param )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Inicializa��o Par�metros %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Timer
    t1 = cputime;
    
    % Quantidade de Estruturas
    N = 4;
    
    % Quantidade de N�s
    Nnode = 2;
    
    % Quantidade de Elementos
    Nelem = 2;
    
    % Quantidade de N�s Depedentes
    Ndep = 1;
  
    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O DA MALHA 2D %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nas Estruturas
    for i = 1:N
    
        %%%%%%%%%%%%%%%
        % ESTRUTURA 1 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 1
        if ( i == 1 )
            
            %%%%%%%%%%%
            % Parte A %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%
    
            % Tamanho do Elemento na Altura
            s1 = ( h2 ) / n;

            % Tamanho do Elemento na Largura
            s2 = ( ( Lf - b2 ) / 2 ) / n;

            % Menor Tamanho do Elemento
            smin = s1;

            % Quantidade de Elementos na Altura
            n1 = fix ( ( h2 ) / ( smin ) );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) );
            
            % Atualiza��o dos Elementos na Largura
            if ( n2 == 0 )
                
                % Atualiza��o dos Elementos na Largura
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y In�cio da Boundary -- A
            y1A = + Lf / 2;
            
            % Coordenada Z In�cio da Boundary -- A
            z1A = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y Fim da Boundary -- A
            y2A = + b2 / 2;
            
            % Coordenada Z Fim da Boundary -- A
            z2A = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y1A - y2A ) / n2;

            % Espa�amento em Z
            dz = abs ( z1A - z2A ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( L + r , y2A:dy:y1A , z1A:dz:z2A );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 1:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( length ( Y ( : , 1 , 1 ) ) - j + 1 , 1 , 1 );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == 1 )

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    else

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';

                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do N� Dependente
                    if ( j == length ( Y ( : , 1 , 1 ) ) )
                        
                        % Defini��o do Id do MPC relacionado ao N�
                        Node_Param ( Nnode ).mpc_id = i;

                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'DEP';

                        % Adi��o do N� ao MPC
                        Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;

                        % Incremento no N�mero de N�s Dependentes
                        Ndep = Ndep + 1;                    
                    
                    else
                        
                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'IND';
                        
                    end                        
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'A';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end
 
            %%%%%%%%%%%
            % Parte B %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = b2 / n;
%             
%             % Menor Tamanho do Elemento
%             smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( b2 ) / ( smin ) );
            
            % Quantidade de Elementos Nulas
            if ( n2 == 0 )
                
                % Atualiza��o do Valor
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y In�cio do MPC -- B
            y1B = + b2 / 2;
            
            % Coordenada Z In�cio do MPC -- B
            z1B = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y Fim do MPC -- B
            y2B = - b2 / 2;
            
            % Coordenada Z Fim do MPC -- B
            z2B = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y1B - y2B ) / n2;

            % Espa�amento em Z
            dz = abs ( z1B - z2B ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( L + r , y2B:dy:y1B , z1B:dz:z2B );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( j );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( length ( Y ( : , 1 , 1 ) ) - j + 1 , 1 , 1 );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    Node_Param ( Nnode ).border = 'N';
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( Nnode ).mpc_id = i;
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'DEP';
                    
                    % Adi��o do N� ao MPC
                    Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;
                    
                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                        
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'B';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            %%%%%%%%%%%
            % Parte C %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = ( ( Lf - b2 ) / 2 ) / n;
%             
%             % Menor Tamanho do Elemento
%             smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) ); 
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio Boundary -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y In�cio da Boundary -- C
            y1C = - b2 / 2;
            
            % Coordenada Z In�cio do Boundary -- C
            z1C = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim Boundary -- Parte C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y Fim da Boundary -- C
            y2C = - Lf / 2;
            
            % Coordenada Z Fim da Boundary -- C
            z2C = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y1C - y2C ) / n2;

            % Espa�amento em Z
            dz = abs ( z1C - z2C ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( L + r , y2C:dy:y1C , z1C:dz:z2C );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( j );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( length ( Y ( : , 1 , 1 ) ) - j + 1 , 1 , 1 );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == length ( Y ( : , 1 , 1 ) ) )
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    
                    else
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';
                        
                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'IND';
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                       
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'C';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            % Continuar
            continue;
            
        end
        
        % Reset do Vetor de N�s Dependentes
        Ndep = 1;
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 2 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 2
        if ( i == 2 )
            
            %%%%%%%%%%%
            % Parte A %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%
    
            % Tamanho do Elemento na Altura
            s1 = ( h2 ) / n;

            % Tamanho do Elemento na Largura
            s2 = ( ( Lf - b2 ) / 2 ) / n;

            % Menor Tamanho do Elemento
            %smin = min ( s1 , s2 );
            smin = s1;

            % Quantidade de Elementos na Altura
            n1 = fix ( ( h2 ) / ( smin ) );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) );   
            
            % Atualiza��o dos Elementos na Largura
            if ( n2 == 0 )
                
                % Atualiza��o dos Elementos na Largura
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X In�cio da Boundary -- A
            x1A = - Lf / 2;
            
            % Coordenada Z In�cio da Boundary -- A
            z1A = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X Fim da Boundary -- A
            x2A = - b2 / 2;
            
            % Coordenada Z Fim da Boundary -- A
            z2A = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em X
            dx = abs ( x1A - x2A ) / n2;

            % Espa�amento em Z
            dz = abs ( z1A - z2A ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( x1A:dx:x2A , L + r , z1A:dz:z2A );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 1:length ( X ( 1 , : , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , j , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );

                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;
                    
                    % Defini��o do N� de Borda
                    if ( j == 1 )

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    else

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';

                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do N� Dependente
                    if ( j == length ( X ( 1 , : , 1 ) ) )
                        
                        % Defini��o do Id do MPC relacionado ao N�
                        Node_Param ( Nnode ).mpc_id = i;

                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'DEP';

                        % Adi��o do N� ao MPC
                        Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;

                        % Incremento no N�mero de N�s Dependentes
                        Ndep = Ndep + 1;                    
                    
                    else
                        
                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'IND';
                        
                    end
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'A';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end
 
            %%%%%%%%%%%
            % Parte B %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = b2 / n;
%             
%             % Menor Tamanho do Elemento
%             smin = max ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( b2 ) / ( smin ) ); 
            
            % Quantidade de Elementos Nulas
            if ( n2 == 0 )
                
                % Atualiza��o do Valor
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X In�cio do MPC -- B
            x1B = - b2 / 2;
            
            % Coordenada Z In�cio do MPC -- B
            z1B = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X Fim do MPC -- B
            x2B = + b2 / 2;
            
            % Coordenada Z Fim do MPC -- B
            z2B = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dx = abs ( x1B - x2B ) / n2;

            % Espa�amento em Z
            dz = abs ( z1B - z2B ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( x1B:dx:x2B , L + r , z1B:dz:z2B );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( X ( 1 , : , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , j , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    Node_Param ( Nnode ).border = 'N';
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( Nnode ).mpc_id = i;
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'DEP';
                    
                    % Adi��o do N� ao MPC
                    Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;
                    
                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                        
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'B';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            %%%%%%%%%%%
            % Parte C %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = ( ( Lf - b2 ) / 2 ) / n;
%             
%             % Menor Tamanho do Elemento
%             smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) ); 
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio Boundary -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X In�cio da Boundary -- C
            x1C = + b2 / 2;
            
            % Coordenada Z In�cio do Boundary -- C
            z1C = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim Boundary -- Parte C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X Fim da Boundary -- C
            x2C = + Lf / 2;
            
            % Coordenada Z Fim da Boundary -- C
            z2C = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y=X
            dx = abs ( x1C - x2C ) / n2;

            % Espa�amento em Z
            dz = abs ( z1C - z2C ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( x1C:dx:x2C , L + r , z1C:dz:z2C );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( X ( 1 , : , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , j , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == length ( X ( 1 , : , 1 ) ) )
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    
                    else
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';
                        
                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'IND';
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                       
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'C';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            % Continuar
            continue;
            
        end
        
        % Reset do Vetor de N�s Dependentes
        Ndep = 1;
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 3 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 3
        if ( i == 3 )
            
            %%%%%%%%%%%
            % Parte A %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%
    
            % Tamanho do Elemento na Altura
            s1 = ( h2 ) / n;

            % Tamanho do Elemento na Largura
            s2 = ( ( Lf - b2 ) / 2 ) / n;

            % Menor Tamanho do Elemento
            %smin = min ( s1 , s2 );
            smin = s1;

            % Quantidade de Elementos na Altura
            n1 = fix ( ( h2 ) / ( smin ) );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) ); 
            
            % Atualiza��o dos Elementos na Largura
            if ( n2 == 0 )
                
                % Atualiza��o dos Elementos na Largura
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y In�cio da Boundary -- A
            y1A = - Lf / 2;
            
            % Coordenada Z In�cio da Boundary -- A
            z1A = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y Fim da Boundary -- A
            y2A = - b2 / 2;
            
            % Coordenada Z Fim da Boundary -- A
            z2A = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y1A - y2A ) / n2;

            % Espa�amento em Z
            dz = abs ( z1A - z2A ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( - ( L + r ) , y1A:dy:y2A , z1A:dz:z2A );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 1:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j , 1 , 1 );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == 1 )

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    else

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';

                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do N� Dependente
                    if ( j == length ( Y ( : , 1 , 1 ) ) )
                        
                        % Defini��o do Id do MPC relacionado ao N�
                        Node_Param ( Nnode ).mpc_id = i;

                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'DEP';

                        % Adi��o do N� ao MPC
                        Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;

                        % Incremento no N�mero de N�s Dependentes
                        Ndep = Ndep + 1;                    
                    
                    else
                        
                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'IND';
                        
                    end           
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'A';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end
 
            %%%%%%%%%%%
            % Parte B %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = b2 / n;
%             
%             % Menor Tamanho do Elemento
%             smin = max ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( b2 ) / ( smin ) );  
            
            % Quantidade de Elementos Nulas
            if ( n2 == 0 )
                
                % Atualiza��o do Valor
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y In�cio do MPC -- B
            y1B = - b2 / 2;
            
            % Coordenada Z In�cio do MPC -- B
            z1B = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y Fim do MPC -- B
            y2B = + b2 / 2;
            
            % Coordenada Z Fim do MPC -- B
            z2B = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y1B - y2B ) / n2;

            % Espa�amento em Z
            dz = abs ( z1B - z2B ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( - ( L + r ) , y1B:dy:y2B , z1B:dz:z2B );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( j );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j , 1 , 1 );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    Node_Param ( Nnode ).border = 'N';
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( Nnode ).mpc_id = i;
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'DEP';
                    
                    % Adi��o do N� ao MPC
                    Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;
                    
                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                        
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'B';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            %%%%%%%%%%%
            % Parte C %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = ( ( Lf - b2 ) / 2 ) / n;
%             
%             % Menor Tamanho do Elemento
%             smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) ); 
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio Boundary -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y In�cio da Boundary -- C
            y1C = + b2 / 2;
            
            % Coordenada Z In�cio do Boundary -- C
            z1C = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim Boundary -- Parte C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada Y Fim da Boundary -- C
            y2C = + Lf / 2;
            
            % Coordenada Z Fim da Boundary -- C
            z2C = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dy = abs ( y1C - y2C ) / n2;

            % Espa�amento em Z
            dz = abs ( z1C - z2C ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( - ( L + r ) , y1C:dy:y2C , z1C:dz:z2C );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( Y ( : , 1 , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( j );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j , 1 , 1 );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == length ( Y ( : , 1 , 1 ) ) )
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    
                    else
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';
                        
                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'IND';
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                       
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'C';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            % Continuar
            continue;
            
        end        
        
        % Reset do Vetor de N�s Dependentes
        Ndep = 1;
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 4 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 4
        if ( i == 4 )
            
            %%%%%%%%%%%
            % Parte A %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%
    
            % Tamanho do Elemento na Altura
            s1 = ( h2 ) / n;

            % Tamanho do Elemento na Largura
            s2 = ( ( Lf - b2 ) / 2 ) / n;

            % Menor Tamanho do Elemento
            %smin = min ( s1 , s2 );
            smin = s1;

            % Quantidade de Elementos na Altura
            n1 = fix ( ( h2 ) / ( smin ) );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) );
            
            % Atualiza��o dos Elementos na Largura
            if ( n2 == 0 )
                
                % Atualiza��o dos Elementos na Largura
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X In�cio da Boundary -- A
            x1A = + Lf / 2;
            
            % Coordenada Z In�cio da Boundary -- A
            z1A = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim BC -- Parte A %
            %%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X Fim da Boundary -- A
            x2A = + b2 / 2;
            
            % Coordenada Z Fim da Boundary -- A
            z2A = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em X
            dx = abs ( x1A - x2A ) / n2;

            % Espa�amento em Z
            dz = abs ( z1A - z2A ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( x2A:dx:x1A , - ( L + r ) , z1A:dz:z2A );
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE A %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 1:length ( X ( 1 , : , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , length ( X ( 1 , : , 1 ) ) - j + 1 , 1 );
                    
                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == 1 )

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    else

                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';

                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do N� Dependente
                    if ( j == length ( X ( 1 , : , 1 ) ) )
                        
                        % Defini��o do Id do MPC relacionado ao N�
                        Node_Param ( Nnode ).mpc_id = i;

                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'DEP';

                        % Adi��o do N� ao MPC
                        Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;

                        % Incremento no N�mero de N�s Dependentes
                        Ndep = Ndep + 1;                    
                    
                    else
                        
                        % Defini��o da Maneira como est� presente no MPC
                        Node_Param ( Nnode ).mpc_type = 'IND';
                        
                    end
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE A %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Cria��o dos Elementos
                    if ( j > 1 && k ~= 1 )

                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'A';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;

                    end

                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1; 
                    
                end
                
            end
 
            %%%%%%%%%%%
            % Parte B %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = b2 / n;
%             
%             % Menor Tamanho do Elemento
%             smin = max ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( b2 ) / ( smin ) ); 
            
            % Quantidade de Elementos Nulas
            if ( n2 == 0 )
                
                % Atualiza��o do Valor
                n2 = 1;
                
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X In�cio do MPC -- B
            x1B = + b2 / 2;
            
            % Coordenada Z In�cio do MPC -- B
            z1B = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim MPC -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X Fim do MPC -- B
            x2B = - b2 / 2;
            
            % Coordenada Z Fim do MPC -- B
            z2B = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y
            dx = abs ( x1B - x2B ) / n2;

            % Espa�amento em Z
            dz = abs ( z1B - z2B ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( x2B:dx:x1B , - ( L + r ) , z1B:dz:z2B );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( X ( 1 , : , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , length ( X ( 1 , : , 1 ) ) - j + 1 , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    Node_Param ( Nnode ).border = 'N';
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( Nnode ).mpc_id = i;
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'DEP';
                    
                    % Adi��o do N� ao MPC
                    Mpc_Param ( i ).node_dep ( Ndep ) = Nnode;
                    
                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE B %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                        
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'B';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            %%%%%%%%%%%
            % Parte C %
            %%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Defini��es Iniciais %
            %%%%%%%%%%%%%%%%%%%%%%%

%             % Tamanho do Elemento na Largura
%             s2 = ( ( Lf - b2 ) / 2 ) / n;
%             
%             % Menor Tamanho do Elemento
%             smin = min ( s1 , s2 );

            % Quantidade de Elementos na Largura
            n2 = fix ( ( ( Lf - b2 ) / 2 ) / ( smin ) ); 
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� In�cio Boundary -- Parte B %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X In�cio da Boundary -- C
            x1C = - b2 / 2;
            
            % Coordenada Z In�cio do Boundary -- C
            z1C = - h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % N� Fim Boundary -- Parte C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Coordenada X Fim da Boundary -- C
            x2C = - Lf / 2;
            
            % Coordenada Z Fim da Boundary -- C
            z2C = + h2 / 2;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % Par�metros da Malha %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Espa�amento em Y=X
            dx = abs ( x1C - x2C ) / n2;

            % Espa�amento em Z
            dz = abs ( z1C - z2C ) / n1;

            %%%%%%%%%%%%%%%%%%%%
            % GERA��O DA MALHA %
            %%%%%%%%%%%%%%%%%%%%
          
            % Gera��o da Malha
            [ X , Y , Z ] = meshgrid ( x2C:dx:x1C , - ( L + r ) , z1C:dz:z2C );
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ESTRUTURA��O DA MALHA % PARTE C %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Varredura na Lista de N�s da Camada Z
            for j = 2:length ( X ( 1 , : , 1 ) )
                
                % Varredura na Lista de N�s da Camada Y
                for k = 1:length ( Z ( 1 , 1 , : ) )                    
                        
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS N�S % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    % Defini��o do Id do N�
                    Node_Param ( Nnode ).id = Nnode;

                    % Defini��o da Coordenada X do N�
                    Node_Param ( Nnode ).coord ( 1 ) = X ( 1 , length ( X ( 1 , : , 1 ) ) - j + 1 , 1 );

                    % Defini��o da Coordenada Y do N�
                    Node_Param ( Nnode ).coord ( 2 ) = Y ( j );

                    % Defini��o da Coordenada Z do N�
                    Node_Param ( Nnode ).coord ( 3 ) = Z ( 1 , 1 , k );
                    
                    % Defini��o da Estrutura Relacionada ao N�
                    Node_Param ( Nnode ).estr = i;

                    % Defini��o do N� de Borda
                    if ( j == length ( X ( 1 , : , 1 ) ) )
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'Y';
                    
                    else
                        
                        % Defini��o do N� de Borda
                        Node_Param ( Nnode ).border = 'N';
                        
                    end
                    
                    % Defini��es dos Valores das For�as dos N�s
                    Node_Param ( Nnode ).force = 'N';
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( Nnode ).mpc_type = 'IND';
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % ESTRUTURA��O DOS ELEMENTOS % PARTE C %
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                    % Cria��o do Elemento
                    if ( k ~= 1 )
                       
                        % Defini��o do Id do Elemento
                        Elem_Param ( Nelem ).id   = Nelem;

                        % Defini��o do Id da Propriedade ao Elemento
                        Elem_Param ( Nelem ).prop_id = 1;

                        % Defini��o do Tipo do Elemento
                        Elem_Param ( Nelem ).type = '2d';

                        % Defini��o da Parte do Elemento
                        Elem_Param ( Nelem ).part = 'C';

                        % Defini��o da Estrutura Relacionado
                        Elem_Param ( Nelem ).estr = i;

                        % Id do N� 1 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( Nnode - n1 - 2 ).id; 

                        % Id do N� 2 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( Nnode - n1 - 1 ).id;

                        % Id do N� 3 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 3 ) = Node_Param ( Nnode ).id;

                        % Id do N� 4 Associado ao Elemento
                        Elem_Param ( Nelem ).node ( 4 ) = Node_Param ( Nnode - 1 ).id;   

                        % Atualiza��o do Contador de Elementos
                        Nelem = Nelem + 1;
                    
                    end
 
                    % Atualiza��o do Contador de N�s
                    Nnode = Nnode + 1;                        
                    
                end
                
            end
            
            % Continuar
            continue;
            
        end
        
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_mesh_2d : %2.2f s.\n', t2 );
    
end