%% Defini��o dos N�s da Malha 1D

%% INPUT
% b1                - Base da Se��o Transversal do N� Central
% h1                - Altura da Se��o Transversal do N� Central
% b2                - Base da Se��o Transversal do N� Extremidade
% h2                - Altura da Se��o Transversal do N� Extremidade
% L                 - Comprimento da Estrutura
% d                 - Rebaixo da Viga
% r                 - Raio do Centro da C�lula de Carga          
% n                 - Quantidade de Elementos em Cada Estrutura
% Node_Param        - Estrutura de Dados dos N�s da Malha 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 2D
% Prop_Param        - Estrutura de Dados das Propriedades da Malha 2D
% Mpc_Param         - Estrutura de Dados dos Mpcs da Malha 2D
% Mat_Param         - Estrutura de Dados dos Materiais da Malha

%% OUPTUT
% Node_Param        - Estrutura de Dados dos N�s da Malha 1D e 2D
% Elem_Param        - Estrutura de Dados dos Elementos da Malha 1D e 2D
% Prop_Param        - Estrutura de Dados das Propriedades da Malha 1D e 2D
% Prop_Param        - Estrutura de Dados dos Mpcs da Malha 1D e 2D

%% Declara��o da Fun��o de Defini��o dos N�s da Malha 1D
function [ Node_Param , Elem_Param , Prop_Param , Mpc_Param ] = create_mesh_1d ( b1 , h1 , b2 , h2 , L , t , d , r , n , Node_Param , Elem_Param , Prop_Param , Mpc_Param , ~ )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Inicializa��o Par�metros %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Timer
    t1 = cputime;

    % Quantidades de Estrutura
    N = 4;
    
    % Quantidade de N�s
    Nnode = Node_Param ( end ).id + 1;
    
    % Quantidade de Elementos
    Nelem = Elem_Param ( end ).id + 1;
    
    % Quantidade de N�s Depedentes
    Ndep = 1;
    
    % Quantidade de Propriedades
    Nprop = Prop_Param ( end ).id + 1;
    
    % Posi��o Final da Estrutura Deform�vel
    L1 = L + r - ( t / 2 );
    
    % Comprimento da Estrutura Deform�vel
    L2 = L - ( t / 2 );

    %%%%%%%%%%%%%%%%%%%%%%%%%
    % DEFINI��O DA MALHA 1D %
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura em Cada Estrutura
    for i = 1:N        
       
        %%%%%%%%%%%%%%%
        % ESTRUTURA 1 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 1
        if ( i == 1 )
            
            %%%%%%%%%%%
            % PARTE 1 %
            %%%%%%%%%%%
           
            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;
            
            % Defini��o das Coordenadas do N� -- Coordenada X
            Node_Param ( Nnode ).coord ( 1 ) = L1;
            
            % Defini��o das Coordenadas do N� -- Coordenada Y
            Node_Param ( Nnode ).coord ( 2 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Coordenada Z
            Node_Param ( Nnode ).coord ( 3 ) = 0;
            
            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = i;
                        
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).border = 'N';
            
            % Defini��es dos Valores das For�as dos N�s
            Node_Param ( Nnode ).force = 'N';
            
            % Defini��o do Id do MPC relacionado ao N�
            Node_Param ( Nnode ).mpc_id = i;
            
            % Defini��o da Maneira como est� presente no MPC
            Node_Param ( Nnode ).mpc_type = 'IND';
            
            % Adi��o do N� ao MPC
            Mpc_Param ( i ).node_ind ( 1 ) = Nnode;
            
            % Adi��o do Id ao MPC
            Mpc_Param ( i ).id = i;

            % Atualiza��o do N�mero de N�s
            Nnode = Nnode + 1;
                        
            % Defini��o do Incremento - X
            DX = ( L1 - ( 0.7 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Y
            DY = 0;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )
                
                % Defini��o do Par�metro Lx
                Lx = abs ( ( j - Nnode + 1 ) * DX );
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) - DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) - DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) - DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'A';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';
                
                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = b2;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = h2;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );
                    
                end                

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );
      
                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );

                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end 
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;       
            
            %%%%%%%%%%%
            % PARTE 2 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = ( ( ( 0.7 * L2 ) + r ) - ( 0.3 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Y
            DY = 0;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Lx
                Lx = ( 0.3 * L2 ) +  abs ( ( j - Nnode + 1 ) * DX );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) - DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) - DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) - DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'B';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) - d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) - d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) ) - d;                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 );
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) ) - d;
                    
                end    

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;   
            
            %%%%%%%%%%%
            % PARTE 3 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = ( ( ( 0.3 * L2 ) + r ) - r ) / n;
            
            % Defini��o do Incremento - Y
            DY = 0;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n ;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Lx
                Lx = ( 0.7 * L2 ) + abs ( ( j - Nnode + 1 ) * DX );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) - DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) - DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) - DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';                     
                
                % �ltimo N� Criado
                if ( j == Nnode + Add_Node - 1 )

                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( j ).mpc_id = 5;

                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'DEP';

                    % Adi��o do N� ao MPC
                    Mpc_Param ( 5 ).node_dep ( Ndep ) = j;

                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;
                 
                else
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'IND';
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'C';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) + d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) + d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );
                    
                end   

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;                  

            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node; 
            
            % Continuar
            continue;
                   
        end
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 2 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 2
        if ( i == 2 )
            
            %%%%%%%%%%%
            % PARTE 1 %
            %%%%%%%%%%%
           
            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;
            
            % Defini��o das Coordenadas do N� -- Coordenada X
            Node_Param ( Nnode ).coord ( 1 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Coordenada Y
            Node_Param ( Nnode ).coord ( 2 ) = L1;
            
            % Defini��o das Coordenadas do N� -- Coordenada Z
            Node_Param ( Nnode ).coord ( 3 ) = 0;
            
            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = i;
            
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).border = 'N';
            
            % Defini��es dos Valores das For�as dos N�s
            Node_Param ( Nnode ).force = 'N';
            
            % Defini��o do Id do MPC relacionado ao N�
            Node_Param ( Nnode ).mpc_id = i;
            
            % Defini��o da Maneira como est� presente no MPC
            Node_Param ( Nnode ).mpc_type = 'IND';
            
            % Adi��o do N� ao MPC
            Mpc_Param ( i ).node_ind ( 1 ) = Nnode;
            
            % Adi��o do Id ao MPC
            Mpc_Param ( i ).id = i;

            % Atualiza��o do N�mero de N�s
            Nnode = Nnode + 1;
                        
            % Defini��o do Incremento - X
            DX = 0;
            
            % Defini��o do Incremento - Y
            DY = ( L1 - ( 0.7 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )
                
                % Defini��o do Par�metro Ly
                Ly = abs ( ( j - Nnode + 1 ) * DY );
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) - DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) - DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) - DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'A';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';
                
                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = b2;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = h2;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );
                    
                end                

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );
      
                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );

                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end 
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;       
            
            %%%%%%%%%%%
            % PARTE 2 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = 0;
            
            % Defini��o do Incremento - Y
            DY = ( ( ( 0.7 * L2 ) + r ) - ( 0.3 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Ly
                Ly = ( 0.3 * L2 ) +  abs ( ( j - Nnode + 1 ) * DY );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) - DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) - DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) - DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'B';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) - d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) - d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) ) - d;                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 );
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) ) - d;
                    
                end    

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;   
            
            %%%%%%%%%%%
            % PARTE 3 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = 0;
            
            % Defini��o do Incremento - Y
            DY = ( ( ( 0.3 * L2 ) + r ) - r ) / n;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n ;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Ly
                Ly = ( 0.7 * L2 ) + abs ( ( j - Nnode + 1 ) * DY );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) - DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) - DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) - DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % �ltimo N� Criado
                if ( j == Nnode + Add_Node - 1 )   
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( j ).mpc_id = 5;

                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'DEP';

                    % Adi��o do N� ao MPC
                    Mpc_Param ( 5 ).node_dep ( Ndep ) = j;

                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;
                
                else
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'IND';
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'C';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) + d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) + d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );
                    
                end   

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;                  

            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node; 
            
            % Continuar
            continue;
                   
        end
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 3 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 3
        if ( i == 3 )
            
            %%%%%%%%%%%
            % PARTE 1 %
            %%%%%%%%%%%
           
            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;
            
            % Defini��o das Coordenadas do N� -- Coordenada X
            Node_Param ( Nnode ).coord ( 1 ) = - L1;
            
            % Defini��o das Coordenadas do N� -- Coordenada Y
            Node_Param ( Nnode ).coord ( 2 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Coordenada Z
            Node_Param ( Nnode ).coord ( 3 ) = 0;
            
            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = i;
            
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).border = 'N';
            
            % Defini��es dos Valores das For�as dos N�s
            Node_Param ( Nnode ).force = 'N';
            
            % Defini��o do Id do MPC relacionado ao N�
            Node_Param ( Nnode ).mpc_id = i;
            
            % Defini��o da Maneira como est� presente no MPC
            Node_Param ( Nnode ).mpc_type = 'IND';
            
            % Adi��o do N� ao MPC
            Mpc_Param ( i ).node_ind ( 1 ) = Nnode;
            
            % Adi��o do Id ao MPC
            Mpc_Param ( i ).id = i;

            % Atualiza��o do N�mero de N�s
            Nnode = Nnode + 1;
                        
            % Defini��o do Incremento - X
            DX = ( L1 - ( 0.7 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Y
            DY = 0;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )
                
                % Defini��o do Par�metro Lx
                Lx = abs ( ( j - Nnode + 1 ) * DX );
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'A';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';
                
                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = b2;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = h2;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );
                    
                end                

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );
      
                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );

                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end 
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;       
            
            %%%%%%%%%%%
            % PARTE 2 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = ( ( ( 0.7 * L2 ) + r ) - ( 0.3 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Y
            DY = 0;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Lx
                Lx = ( 0.3 * L2 ) +  abs ( ( j - Nnode + 1 ) * DX );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'B';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) - d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) - d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) ) - d;                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 );
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) ) - d;
                    
                end    

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;   
            
            %%%%%%%%%%%
            % PARTE 3 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = ( ( ( 0.3 * L2 ) + r ) - r ) / n;
            
            % Defini��o do Incremento - Y
            DY = 0;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n ;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Lx
                Lx = ( 0.7 * L2 ) + abs ( ( j - Nnode + 1 ) * DX );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % �ltimo N� Criado
                if ( j == Nnode + Add_Node - 1 )  

                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( j ).mpc_id = 5;

                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'DEP';

                    % Adi��o do N� ao MPC
                    Mpc_Param ( 5 ).node_dep ( Ndep ) = j;

                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;
                
                else
                    
                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'IND';
                    
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'C';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) + d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) + d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Lx / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Lx / L2 ) );
                    
                end   

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;                  

            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;
            
            % Continuar
            continue;
                   
        end
        
        %%%%%%%%%%%%%%%
        % ESTRUTURA 4 %
        %%%%%%%%%%%%%%%
        
        % Estrutura 4
        if ( i == 4 )
            
            %%%%%%%%%%%
            % PARTE 1 %
            %%%%%%%%%%%
           
            % Defini��o do Id do N�
            Node_Param ( Nnode ).id = Nnode;
            
            % Defini��o das Coordenadas do N� -- Coordenada X
            Node_Param ( Nnode ).coord ( 1 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Coordenada Y
            Node_Param ( Nnode ).coord ( 2 ) = - L1;
            
            % Defini��o das Coordenadas do N� -- Coordenada Z
            Node_Param ( Nnode ).coord ( 3 ) = 0;
            
            % Defini��o da Estrutura Relacionada ao N�
            Node_Param ( Nnode ).estr = i;
            
            % Defini��o do N� de Borda
            Node_Param ( Nnode ).border = 'N';
            
            % Defini��es dos Valores das For�as dos N�s
            Node_Param ( Nnode ).force = 'N';
            
            % Defini��o do Id do MPC relacionado ao N�
            Node_Param ( Nnode ).mpc_id = i;
            
            % Defini��o da Maneira como est� presente no MPC
            Node_Param ( Nnode ).mpc_type = 'IND';
            
            % Adi��o do N� ao MPC
            Mpc_Param ( i ).node_ind ( 1 ) = Nnode;
            
            % Adi��o do Id ao MPC
            Mpc_Param ( i ).id = i;

            % Atualiza��o do N�mero de N�s
            Nnode = Nnode + 1;
                        
            % Defini��o do Incremento - X
            DX = 0;
            
            % Defini��o do Incremento - Y
            DY = ( L1 - ( 0.7 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )
                
                % Defini��o do Par�metro Ly
                Ly = abs ( ( j - Nnode + 1 ) * DY );
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id   = Nelem;

                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'A';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';
                
                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = b2;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = h2;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );
                    
                end                

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );
      
                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );

                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end 
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;       
            
            %%%%%%%%%%%
            % PARTE 2 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = 0;
            
            % Defini��o do Incremento - Y
            DY = ( ( ( 0.7 * L2 ) + r ) - ( 0.3 * L2 ) - r ) / n;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Ly
                Ly = ( 0.3 * L2 ) +  abs ( ( j - Nnode + 1 ) * DY );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % Defini��o da Maneira como est� presente no MPC
                Node_Param ( j ).mpc_type = 'IND';
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'B';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) - d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) - d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) ) - d;                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 );
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) ) - d;

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) ) - d;
                    
                end    

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;
            
            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node;   
            
            %%%%%%%%%%%
            % PARTE 3 %
            %%%%%%%%%%%
            
            % Defini��o do Incremento - X
            DX = 0;
            
            % Defini��o do Incremento - Y
            DY = ( ( ( 0.3 * L2 ) + r ) - r ) / n;
            
            % Defini��o do Incremento - Z
            DZ = 0;
            
            % Quantidade de N�s a Serem Acrescidos
            Add_Node = n ;
            
            % Varredura nos N�s Adicionais
            for j = Nnode:( Nnode + Add_Node - 1 )

                % Defini��o do Par�metro Ly
                Ly = ( 0.7 * L2 ) + abs ( ( j - Nnode + 1 ) * DY );                
                
                %%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS N�S %
                %%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do N�
                Node_Param ( j ).id = j;
                
                % Defini��o das Coordenadas do N� -- X -- Primeiro Novo N�
                Node_Param ( j ).coord ( 1 ) = Node_Param ( j - 1 ).coord ( 1 ) + DX;

                % Defini��o das Coordenadas do N� -- Y -- Primeiro Novo N�
                Node_Param ( j ).coord ( 2 ) = Node_Param ( j - 1 ).coord ( 2 ) + DY;

                % Defini��o das Coordenadas do N� -- Z -- Primeiro Novo N�
                Node_Param ( j ).coord ( 3 ) = Node_Param ( j - 1 ).coord ( 3 ) + DZ;
                
                % Defini��o da Estrutura Relacionada ao N�
                Node_Param ( j ).estr = i;
                
                % Defini��o do N� de Borda
                Node_Param ( j ).border = 'N';
                
                % Defini��es dos Valores das For�as dos N�s
                Node_Param ( j ).force = 'N';
                
                % �ltimo N� Criado
                if ( j == Nnode + Add_Node - 1 ) 
                    
                    % Defini��o do Id do MPC relacionado ao N�
                    Node_Param ( j ).mpc_id = 5;

                    % Defini��o da Maneira como est� presente no MPC
                    Node_Param ( j ).mpc_type = 'DEP';

                    % Adi��o do N� ao MPC
                    Mpc_Param ( 5 ).node_dep ( Ndep ) = j;

                    % Incremento no N�mero de N�s Dependentes
                    Ndep = Ndep + 1;
                
                else
                    
                    % Defini��o da Maneira como est� presente no MPC
                     Node_Param ( j ).mpc_type = 'IND';
                     
                end                 
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DOS ELEMENTOS %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Defini��o do Id do Elemento
                Elem_Param ( Nelem ).id = Nelem;               
                
                % Defini��o do Id da Propriedade ao Elemento
                Elem_Param ( Nelem ).prop_id = Nprop;

                % Defini��o do Tipo do Elemento
                Elem_Param ( Nelem ).type = '1d';

                % Defini��o da Parte do Elemento
                Elem_Param ( Nelem ).part = 'C';

                % Defini��o da Estrutura Relacionado
                Elem_Param ( Nelem ).estr = i;
                
                % Id do N� 1 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 1 ) = Node_Param ( j - 1 ).id; 

                % Id do N� 2 Associado ao Elemento
                Elem_Param ( Nelem ).node ( 2 ) = Node_Param ( j ).id;
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % ESTRUTURA��O DAS PROPRIEDADES %
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % Id da Propriedade
                Prop_Param ( Nprop ).id = Nprop;
                
                % Tipo da Propriedade
                Prop_Param ( Nprop ).type = '1d';              

                % Primeira Propriedade Criada
                if ( j == Nnode )
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) + d;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) + d;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );                    
                
                % Demais Elementos
                else
                    
                    % Defini��o dos Par�metros de Base
                    Prop_Param ( Nprop ).b ( 1 ) = Prop_Param ( Nprop - 1 ).b ( 2 ) ;
                    Prop_Param ( Nprop ).b ( 2 ) = b2 + ( ( b1 - b2 ) * ( Ly / L2 ) );

                    % Defini��o dos Par�metros de Altura
                    Prop_Param ( Nprop ).h ( 1 ) = Prop_Param ( Nprop - 1 ).h ( 2 ) ;
                    Prop_Param ( Nprop ).h ( 2 ) = h2 + ( ( h1 - h2 ) * ( Ly / L2 ) );
                    
                end   

                % Defini��o da �rea
                Prop_Param ( Nprop ).Area ( 1 ) = Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 );
                Prop_Param ( Nprop ).Area ( 2 ) = Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 );

                % Defini��o do Momento de In�rcia Iyy
                Prop_Param ( Nprop ).Iyy ( 1 ) = ( Prop_Param ( Nprop ).b ( 1 ) * Prop_Param ( Nprop ).h ( 1 )^3 ) / 12;
                Prop_Param ( Nprop ).Iyy ( 2 ) = ( Prop_Param ( Nprop ).b ( 2 ) * Prop_Param ( Nprop ).h ( 2 )^3 ) / 12;

                % Defini��o do Momento de In�rcia Izz
                Prop_Param ( Nprop ).Izz ( 1 ) = ( ( Prop_Param ( Nprop ).b ( 1 )^3 ) * Prop_Param ( Nprop ).h ( 1 ) ) / 12;
                Prop_Param ( Nprop ).Izz ( 2 ) = ( ( Prop_Param ( Nprop ).b ( 2 )^3 ) * Prop_Param ( Nprop ).h ( 2 ) ) / 12;

                % Defini��o do Momento Polar de In�rcia
                Prop_Param ( Nprop ).J ( 1 )   = Prop_Param ( Nprop ).Izz ( 1 ) + Prop_Param ( Nprop ).Iyy ( 1 );
                Prop_Param ( Nprop ).J ( 2 )   = Prop_Param ( Nprop ).Izz ( 2 ) + Prop_Param ( Nprop ).Iyy ( 2 );
                
                %%%%%%%%%%%%%%%
                % INCREMENTOS %
                %%%%%%%%%%%%%%%
                
                % Incremento do Elemento
                Nelem = Nelem + 1;
                
                % Incremento da Propriedade
                Nprop = Nprop + 1;                  

            end
            
            % Incremento do N�
            Nnode = Nnode + Add_Node; 
                   
        end             
        
    end
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('create_mesh_1d : %2.2f s.\n', t2 );
    
end