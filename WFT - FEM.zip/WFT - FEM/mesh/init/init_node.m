%% Inicializa��o dos Par�metros dos N�s da Malha

%% INPUT
% L                 - Comprimento da Estrutura

%% OUTPUT
% Node_Param        - Estrutura de Dados dos N�s da Malha

%% Declara��o da Fun��o de Inicializa��o dos Par�metros de Malha
function [ Node_Param ] = init_node ( L )
 
    % Inicializa��o da Contagem de Graus de Liberdade
    DOF = 1;

    % Defini��o dos N�s Iniciais
    for i = 1:5
        
        % Defini��o do Id do N� Inicial
        Node_Param ( i ).id = i;
        
        % Varredura nos Graus de Liberdade do N�
        for j = 1:6
        
            % Defini��o dos Graus de Liberdade do N�
            Node_Param ( i ).dof ( j ) = DOF;
            
            % Incremento na Contagem
            DOF = DOF + 1;          
        
        end
        
        % Cria��o das Coordenadas do N�
        
        % N� 1
        if ( i == 1 )
        
            % Defini��o das Coordenadas do N� -- X
            Node_Param ( i ).coord ( 1 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Y
            Node_Param ( i ).coord ( 2 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Z
            Node_Param ( i ).coord ( 3 ) = 0;
        
        end
        
        % N� 2
        if ( i == 2 )
        
            % Defini��o das Coordenadas do N� -- X
            Node_Param ( i ).coord ( 1 ) = L;
            
            % Defini��o das Coordenadas do N� -- Y
            Node_Param ( i ).coord ( 2 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Z
            Node_Param ( i ).coord ( 3 ) = 0;
        
        end
        
        % N� 3
        if ( i == 3 )
        
            % Defini��o das Coordenadas do N� -- X
            Node_Param ( i ).coord ( 1 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Y
            Node_Param ( i ).coord ( 2 ) = L;
            
            % Defini��o das Coordenadas do N� -- Z
            Node_Param ( i ).coord ( 3 ) = 0;
        
        end
        
        % N� 4
        if ( i == 4 )
        
            % Defini��o das Coordenadas do N� -- X
            Node_Param ( i ).coord ( 1 ) = - L;
            
            % Defini��o das Coordenadas do N� -- Y
            Node_Param ( i ).coord ( 2 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Z
            Node_Param ( i ).coord ( 3 ) = 0;
        
        end
        
        % N� 5
        if ( i == 5 )
        
            % Defini��o das Coordenadas do N� -- X
            Node_Param ( i ).coord ( 1 ) = 0;
            
            % Defini��o das Coordenadas do N� -- Y
            Node_Param ( i ).coord ( 2 ) = - L;
            
            % Defini��o das Coordenadas do N� -- Z
            Node_Param ( i ).coord ( 3 ) = 0;
        
        end
        
    end    
    
end

