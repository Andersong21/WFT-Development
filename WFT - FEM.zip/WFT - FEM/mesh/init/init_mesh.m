%% Inicializa��o dos Par�metros de Malha

%% INPUT
% Mpc_Param         - Estrutura dos Mpc da Malha a Ser Criada

%% OUTPUT
% Node_Param        - Estrutura dos N�s da Malha a Ser Criada
% Elem_Param        - Estrutura dos Elementos da Malha a Ser Criada
% Mpc_Param         - Estrutura dos Mpc da Malha a Ser Criada

%% Declara��o da Fun��o de Inicializa��o dos Par�metros de Malha
function [ Node_Param , Elem_Param , Mpc_Param ] = init_mesh ( Mpc_Param )

    % Inicializa��o da Estrutura dos N�s da Malha
    Node_Param = struct;
    
    % Inicializa��o da Estrutura dos Elementos da Malha
    Elem_Param = struct; 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DO N� CENTRAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Defini��o do Id do N�
    Node_Param ( 1 ).id = 1;

    % Defini��o da Coordenada X do N� Central
    Node_Param ( 1 ).coord ( 1 ) = 0;

    % Defini��o da Coordenada Y do N� Central
    Node_Param ( 1 ).coord ( 2 ) = 0;

    % Defini��o da Coordenada Z do N� Central
    Node_Param ( 1 ).coord ( 3 ) = 0;
    
    % Defini��o do N� de Borda
    Node_Param ( 1 ).border = 'N';
    
    % Defini��es dos Valores das For�as dos N�s
    Node_Param ( 1 ).force = 'Y';
    
    % Defini��o do Id do Mpc Relacionado ao N�
    Node_Param ( 1 ).mpc_id = 5;
    
    % Defini��o da Forma do N� no Mpc
    Node_Param ( 1 ).mpc_type = 'IND';
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DO ELEMENTO CENTRAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Defini��o do Id do Elemento
    Elem_Param ( 1 ).id = 1;               

    % Defini��o do Id da Propriedade ao Elemento
    Elem_Param ( 1 ).prop_id = 0;

    % Defini��o do Tipo do Elemento
    Elem_Param ( 1 ).type = '0d';
    
    % Defini��o da Massa do Elemento
    Elem_Param ( 1 ).mass = 0.000189;
    
    % Id do N� 1 Associado ao Elemento
    Elem_Param ( 1 ).node ( 1 ) = Node_Param ( 1 ).id; 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DO MPC CENTRAL %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Defini��o do Id do MPC
    Mpc_Param ( 5 ).id = 5;
    
    % Defini��o do N� Independente do Mpc
    Mpc_Param ( 5 ).node_ind ( 1 ) = 1;    
    
end

