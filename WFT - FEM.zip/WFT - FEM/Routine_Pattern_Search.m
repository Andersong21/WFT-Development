%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROTINA DO M�TODO DA BUSCA PADR�O %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Limpeza das Vari�veis
clear all;

% Fechar todas as janelas
close all;

% Limpeza das Entrada
clc;

% Inicializa��o do Timer
tic;

% Formatar Sa�da
format short;

% Defini��o do Multicore    
p = gcp('nocreate');

% Processadores n�o Dispon�veis
if isempty( p )

    % N�mero de Processadores
    multicore = 1;

else

    % N�mero de Processadores
    multicore = p.NumWorkers;

end

%% ESTRUTURA DO PROBLEMA

% Vari�veis
% x ( 1  ) - Vari�vel b1      - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1      - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2      - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2      - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L       - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf      - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t       - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d       - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r       - Raio do Centro da C�lula de Carga    - [ mm ]

% Qualidade de Malha
N        = input ('Entre com a qualidade de malha:');

% Quantidade de Amostras
Ns       = input ('Entre a quantidade de amostras:');

% Fator de Correla��o
FS       = input ('Entre o fato de correla��o:');

%%%%%%%%%%%%%%%%%
% INICIALIZA��O %
%%%%%%%%%%%%%%%%%

% Inicializa��o do Di�rio
diary ( strcat ( 'pattern_search_' , int2str ( N ) , '.out' ) );

% Lower Bound
LB       = [ 10 , 10 , 10 , 10 , 41 , 41 , 0.5 , 1.5 , 30 ];

% Upper Bound
UB       = [ 40 , 40 , 40 , 40 , 52 , 94 , 8.0 , 8.0 , 32 ];

% Inicializa��o do Timer
tic;

% Escrita da Qualidade de Malha
fprintf( 'Mesh Quality %d :\n' , N );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFINI��O DOS PONTOS INICIAIS - RANDOM %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Retorno dos Pontos Iniciais 
[ xn , fn ] = get_starting_point2 ( N , Ns , LB , UB , multicore );

%%%%%%%%%%%%%%%%%
% INICIALIZA��O %
%%%%%%%%%%%%%%%%%

% Inicializa��o do Di�rio
diary ( strcat ( 'pattern_search_' , int2str ( N ) , '.out' ) );

% Escrita da Qualidade de Malha
fprintf( 'Mesh Quality %d :\n' , N );

%%%%%%%%%%%%%%%%%%%%%%%%%%
% OTIMIZA��O DO PROBLEMA %
%%%%%%%%%%%%%%%%%%%%%%%%%%

% Inicializa��o das Vari�veis das Fun��es Objetivo do Problema
fval_points = zeros ( 1 , Ns );

% Inicializa��o das Vari�veis dos Pontos Iniciais
x0_points   = zeros ( length ( LB ) , Ns );

% Inicializa��o das Vari�veis dos Pontos Finais
xf_points   = zeros ( length ( LB ) , Ns );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OTIMIZA��O - PONTOS DE ESTUDO %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Varredura nos Pontos de Estudo
for i = 1:Ns
   
    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Di�rio
    diary ( strcat ( 'pattern_search_' , int2str ( N ) , '_point_' , int2str ( i ) , '.out' ) );

    % Escrita do Ponto de Estudo
    fprintf( 'Point %d :\n' , i );
    
    % Ponto de Estudo
    x0 = xn ( i , 1:end );
    
    % Aloca��o da Vari�vel
    x0_points ( 1:end , i ) = x0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ESTRUTURA��O DA OTIMIZA��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Parametriza��o da Fun��o Objetivo
    ObjFunction  = @ ( x )objective_function ( x , N , FS , multicore );

    % Restri��es
    ConsFunction = @ ( x )restriction        ( x , N , FS , multicore );
    
    %%%%%%%%%%%%%%%%%%
    % PATTERN SEARCH %
    %%%%%%%%%%%%%%%%%%

    % Op��es do Solver -- PatternSearch
    options = psoptimset ( 'UseParallel' , true );
    options = psoptimset ( options , 'Display' , 'iter' );
    options = psoptimset ( options , 'PlotFcns' , { { @psplotbestf } , { @psplotfuncount } , { @psplotmeshsize } , { @psplotbestx } , { @psplotmaxconstr } } );
    options = psoptimset ( options , 'PollMethod' , 'GPSPositiveBasis2N' );
    options = psoptimset ( options , 'CompletePoll' , 'on' );
    options = psoptimset ( options , 'CompleteSearch' , 'on' );
    options = psoptimset ( options , 'MeshAccelerator' , 'on' );
    options = psoptimset ( options , 'Cache' , 'on' );

    % Estrutura��o do Problema do PatternSearch
    [ x1 , fval1 , exitflag1 , output1 ] = patternsearch ( ObjFunction , x0 , [] , [] , [] , [] , LB , UB , ConsFunction , options );

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VERIFICA��O % PATTERN SEARCH %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Saida da Otimiza��o
    fprintf('\nPattern Search - Mesh Quality %d - Point %d :' , N , i                );
    fprintf('\nThe number of iterations was : %d'             , output1.iterations   );
    fprintf('\nThe number of function evaluations was : %d'   , output1.funccount    );
    fprintf('\nThe best function value found was : %g\n'      , fval1                );
            
    % Figura
    savefig ( strcat ( 'pattern_search_' , int2str ( N ) , '_point_' , int2str ( i ) , '.fig' ) );
    
    % Aloca��o do Ponto Final
    xf_points ( 1:end , i ) = x1;
    
    % Aloca��o da Fun��o Objetivo
    fval_points ( 1 , i ) = fval1;
    
    % Salvar as Vari�veis
    save ( strcat ( 'pattern_search_' , int2str ( N ) , '_point_' , int2str ( i ) , '.mat' ) );
    
    % Determina��o do Tempo
    fprintf('\nTotal time - Point %d [ s ] : %g\n\n' , i , toc );

    % Finaliza��o do Di�rio
    diary off;
    
end

% Salvar as Vari�veis
save ( strcat ( 'pattern_search_' , int2str ( N ) , '.mat' ) );

% Determina��o do Tempo
fprintf('\nTotal time [ s ] : %g\n\n' , toc );

% Finaliza��o da An�lise
display ( '\nEnd' );
display ( 'Analysis Succesfully' );