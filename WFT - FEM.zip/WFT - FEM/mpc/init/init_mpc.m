%% Inicializa��o dos Par�metros dos Mpcs do Problema

%% INPUT

%% OUTPUT
% Mpc_Param         - Estrutura de Dados dos Mpcs da An�lise

%% Declara��o da Fun��o de Inicializa��o dos Par�metros dos Mpcs
function [ Mpc_Param ] = init_mpc ()
 
    % Inicializa��o da Estrutura dos Mpc da An�lise
    Mpc_Param = struct;
    
end