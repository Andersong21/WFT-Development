%% Retorno do Gerador dos Mpcs do Problema

%% INPUT

%% OUPTUT
% Mpc_Param    - Estrutura de Dados dos Mpcs do Sistema

%% Declara��o da Fun��o de Retorno do Gerador dos Mpcs do Problema
function [ Mpc_Param ] = get_mpc ()

    % Inicializa��o do Timer
    t1 = cputime;
    
    % Inicializa��o dos Par�metros dos Mpcs
    [ Mpc_Param ] = init_mpc (); 
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_mpc : %2.2f s.\n', t2 );
   
end