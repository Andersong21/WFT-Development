%% Retorno da Solu��o do Sistema Linear

%% INPUT
% K            - Matriz de Rigidez do Problema
% F            - Vetor de For�as do Sistema

%% OUTPUT
% X            - Retorno do Vetor de Deslocamentos do Sistema

%% Declara��o da Fun��o de Retorno da Solu��o do Sistema Linear
function [ X ] = lsolve ( K , F )

    % Solu��o do Sistema Linear
    X = mldivide ( K , F );  
    
end