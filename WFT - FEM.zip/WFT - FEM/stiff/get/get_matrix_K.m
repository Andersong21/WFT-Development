%% Retorno do Gerador da Matriz de Rigidez do Problema

%% INPUT
% Node_Param   - Estrutura de Dados dos N�s do Problema
% Elem_Param   - Estrutura de Dados dos Elementos do Problema
% Mat_Param    - Estrutura de Dados do Material do Problema
% Prop_Param   - Estrutura de Dados das Propriedades do Problema
% Mpc_Param    - Estrutura de Dados dos Multi Point Constraint do Problema
% multicore    - Quantidade de N�cleos

%% OUPTUT
% K            - Matriz de Rigidez do Problema

%% Declara��o da Fun��o de Retorno do Gerador da Matriz de Rigidez do Problema
function [ K ] = get_matrix_K ( Node_Param , Elem_Param , Mat_Param , Prop_Param , Mpc_Param , multicore )

    % Inicializa��o do Tempo
    t1 = cputime;
    
    % Cria��o da Matriz de Rigidez do Problema
    [ K ] = create_matrix_K ( Node_Param , Elem_Param , Mat_Param , Prop_Param , Mpc_Param , multicore );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_matrix_K : %2.2f s.\n', t2 );    
    
end