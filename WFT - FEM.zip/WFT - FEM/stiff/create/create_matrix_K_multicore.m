%% Cria��o das Matrizes de Rigidez do Elemento -- Multicore

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s do Problema
% Elem_Param        - Estrutura de Dados dos Elementos do Problema
% Mat_Param         - Estrutura de Dados do Material do Problema
% Prop_Param        - Estrutura de Dados das Proprieades do Problema
% List_Elem         - Lista dos Ids dos Elementos do N�cleo

%% OUTPUT
% Kif               - Termo i da Matriz de Rigidez Global
% Kjf               - Termo j da Matriz de Rigidez Global
% Kvf               - Valor ( i , j ) da Matriz de Rigidez Global

%% Declara��o da Fun��o de Cria��o das Matrizes de Rigidez do Elemento
function [ Kif , Kjf , Kvf ] = create_matrix_K_multicore ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem )

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % VARREDURA NA LISTA DE ELEMENTOS %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Quantidade de Elementos
    Nelem = length ( List_elem );
    
    % Inicializa��o das C�lulas para Aloca��o dos Termos i da Rigidez
    Kig = cell ( [ 1 , Nelem ] );
    
    % Inicializa��o das C�lulas para Aloca��o dos Termos j da Rigidez
    Kjg = cell ( [ 1 , Nelem ] );
    
    % Inicializa��o das C�lulas para Aloca��o dos Valores da Rigidez
    Kvg = cell ( [ 1 , Nelem ] );

    % Varredura na Lista de Elementos
    for i = 1:length ( List_elem )
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DA MATRIZ DE RIGIDEZ 1D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Matriz de Rigidez 1D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '1d' ) == 1 )
        
            % Montagem da Matriz de Rigidez - Beam2
            [ Ki , Kj , Kv ] = matrix_K_beam2 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem ( i ) );
            
            % Aloca��o dos Vetores do Triplet
            Kig { i } = Ki;
            Kjg { i } = Kj;
            Kvg { i } = Kv;             
            
            % Continuar
            continue;     
        
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CRIA��O DA MATRIZ DE RIGIDEZ 2D %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Matriz de Rigidez 2D
        if ( strcmp ( Elem_Param ( List_elem ( i ) ).type , '2d' ) == 1 )
        
            % Montagem da Matriz de Rigidez - Quad4
            [ Ki , Kj , Kv ] = matrix_K_quad4 ( Node_Param , Elem_Param , Mat_Param , Prop_Param , List_elem ( i ) );
            
            % Aloca��o dos Vetores do Triplet
            Kig { i } = Ki;
            Kjg { i } = Kj;
            Kvg { i } = Kv; 
            
            % Continuar
            continue;       
        
        end
        
    end  
    
    % Aloca��o dos Termos i no Vetor de Sa�da
    Kia = cell2mat( Kig );
    Kif = horzcat ( Kia ( : ) );

    % Aloca��o dos Termos j no Vetor de Sa�da
    Kja = cell2mat( Kjg );
    Kjf = horzcat ( Kja ( : ) );
    
    % Aloca��o dos Valores no Vetor de Sa�da
    Kva = cell2mat( Kvg );
    Kvf = horzcat ( Kva ( : ) );

end

