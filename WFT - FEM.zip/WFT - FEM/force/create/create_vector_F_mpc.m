%% Cria��o do Vetor de For�as do Sistema

%% INPUT
% Node_Param  - Estrutura de Dados dos N�s do Problema
% Mpc_Param   - Estrutura de Dados dos Multi Point Constraint do Problema
% i           - Condi��o de For�a a Ser Aplicada
%             - 1 = For�a Apenas em X 
%             - 2 = For�a Apenas em Y
%             - 3 = For�a Apenas em Z
%             - 4 = Momento Apenas em X
%             - 5 = Momento Apenas em Y
%             - 6 = Momento Apenas em Z
%             - 7 = Somat�ria For�as

%% OUTPUT
% F           - Vetor de For�as Preenchido do Problema

%% Declara��o da Fun��o de Cria��o do Vetor de For�as do Sistema
function [ F , Node_Param ] = create_vector_F_mpc ( Node_Param , i )
    
    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%

    % Quantidade de Graus de Liberdade
    Ndof = max ( arrayfun ( @(struct)max(struct(:).dof ( : ) ) , Node_Param ) );

    % Quantidade de N�s
    Nnode = Node_Param ( end ).id;
    
    % Quantidade de N�s Dependentes
    Ndep = 0;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Cria��o dos DOFs do Problema %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Varredura nos N�s
    for j = 1:Nnode
        
        % Verifica��o se o n� � Dependente
        if ( strcmp ( Node_Param ( j ).mpc_type , 'DEP' ) == 1 )
            
            % Atualiza��o da Quantidade de N�s Dependentes
            Ndep = Ndep + 1;
            
        end
        
    end
       
    % Inicializa��o do Vetor de For�as
    F = sparse ( Ndof + ( 6 * Ndep ) , 1 );     

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O  % FOR�A APENAS EM X %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % For�as Apenas em X
    if ( i == 1 )
        
        % For�as no Centro da C�lula de Carga
        Fx = 5500;
        Fy = 0;
        Fz = 0;
        Mx = 0;
        My = 0;
        Mz = 0;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O 2 % FOR�A APENAS EM Y %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % For�as Apenas em Y
    if ( i == 2 )
        
        % For�as no Centro da C�lula de Carga
        Fx = 0;
        Fy = 2940;
        Fz = 0;
        Mx = 0;
        My = 0;
        Mz = 0;        
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O 3 % FOR�A APENAS EM Z %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % For�as Apenas em Z
    if ( i == 3 )
        
        % For�as no Centro da C�lula de Carga
        Fx = 0;
        Fy = 0;
        Fz = 5880;
        Mx = 0;
        My = 0;
        Mz = 0;        
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O 4 % MOMENTO EM X %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Momento Apenas em X
    if ( i == 4 )
        
        % For�as no Centro da C�lula de Carga
        Fx = 0;
        Fy = 0;
        Fz = 0;
        Mx = 50000;
        My = 0;
        Mz = 0;        
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O 5 % MOMENTO EM Y %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Momento Apenas em Y
    if ( i == 5 )
        
        % For�as no Centro da C�lula de Carga
        Fx = 0;
        Fy = 0;
        Fz = 0;
        Mx = 0;
        My = 50000;
        Mz = 0;
       
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O 6 % MOMENTO EM Z %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Momento Apenas em Z
    if ( i == 6 )
        
        % For�as no Centro da C�lula de Carga
        Fx = 0;
        Fy = 0;
        Fz = 0;
        Mx = 0;
        My = 0;
        Mz = 1485000;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CONDI��O 7 % COMBINA��O %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Combina��o
    if ( i == 7 )        
        
        % For�as no Centro da C�lula de Carga
        Fx = 5500;
        Fy = 2940;
        Fz = 5880;
        Mx = 50000;
        My = 50000;
        Mz = 1485000;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%
    % VARREDURA NOS N�S %
    %%%%%%%%%%%%%%%%%%%%%    
        
    % Varredura nos N�s
    for j = 1:Nnode            

        % Verifica��o se � um N� de Borda
        if ( strcmp ( Node_Param ( j ).force , 'Y' ) == 1 )                

            % Inicializa��o do Vetor de For�as
            F ( Node_Param ( j ).dof ( 1 ) ) = Fx;
            F ( Node_Param ( j ).dof ( 2 ) ) = Fy;
            F ( Node_Param ( j ).dof ( 3 ) ) = Fz;
            F ( Node_Param ( j ).dof ( 4 ) ) = Mx;
            F ( Node_Param ( j ).dof ( 5 ) ) = My;
            F ( Node_Param ( j ).dof ( 6 ) ) = Mz;
            
            %%%%%%%%%%%%%%%%%%%%%%%
            % ALOCA��O DAS FOR�AS %
            %%%%%%%%%%%%%%%%%%%%%%%

            % Aloca��o do Vetor de For�as
            Node_Param ( j ).force_value ( 1 ) = Fx;
            Node_Param ( j ).force_value ( 2 ) = Fy;
            Node_Param ( j ).force_value ( 3 ) = Fz;
            Node_Param ( j ).force_value ( 4 ) = Mx;
            Node_Param ( j ).force_value ( 5 ) = My;
            Node_Param ( j ).force_value ( 6 ) = Mz;

        end

    end 

end

