%% Inicializa��o do Vetor de For�as do Problema

%% INPUT
% Node_Param        - Estrutura de Dados dos N�s da Malha

%% OUTPUT
% F                 - Vetor de For�as do Problema

%% Declara��o da Fun��o de Inicializa��o do Vetor de For�as
function [ F ] = init_vector_F ( Node_Param )

    % Quantidade de Graus de Liberdade do Sistem
    n_DOF = Node_Param ( end ).dof ( 6 );
    
    % Inicializa��o do Vetor de For�as
    F = zeros ( n_DOF , 1 );
            
end

