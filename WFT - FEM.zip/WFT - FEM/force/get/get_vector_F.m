%% Retorno do Gerador do Vetor de For�as do Problema

%% INPUT
% Node_Param   - Estrutura de Dados dos N�s do Problema
% i            - Condi��o de For�a a Ser Aplicada
%              - 1 = For�a Apenas em X 
%              - 2 = For�a Apenas em Y
%              - 3 = For�a Apenas em Z
%              - 4 = Momento Apenas em X
%              - 5 = Momento Apenas em Y
%              - 6 = Momento Apenas em Z
%              - 7 = Somat�ria For�as

%% OUTPUT
% F            - Vetor de For�as do Problema
% Node_Param   - Estrutura de Dados dos N�s do Problema + For�as

%% Declara��o da Fun��o de Retorno do Gerador do Vetor de For�as da An�lise
function [ F , Node_Param ] = get_vector_F ( Node_Param , i )

    % Inicializa��o do Tempo
    t1 = cputime;    
        
    % Cria��o do Vetor de For�as do Problema
    [ F , Node_Param ] = create_vector_F ( Node_Param , i );
    
    % Determina��o do Tempo
    t2 = cputime - t1;
    
    % Escrita do Tempo
    %fprintf('get_vector_F : %2.2f s.\n', t2 );
    
end