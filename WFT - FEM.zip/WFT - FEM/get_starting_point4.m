%% Defini��o do Ponto Inicial

%% INPUT
% nsamples                   - Quantidade de Amostras
% LB                         - Lower Bound das Vari�veis
% UB                         - Upper Bound das Vari�veis

%% OUTPUT
% x ( 1  ) - Vari�vel b1     - Base da Se��o Transversal no N� 1    - [ mm ]
% x ( 2  ) - Vari�vel h1     - Altura da Se��o Transversal no N� 1  - [ mm ]
% x ( 3  ) - Vari�vel b2     - Base da Se��o Transversal no N� 2    - [ mm ]
% x ( 4  ) - Vari�vel h2     - Altura da Se��o Transversal no N� 2  - [ mm ]
% x ( 5  ) - Vari�vel L      - Comprimento da Viga                  - [ mm ]
% x ( 6  ) - Vari�vel Lf     - Comprimento da Placa                 - [ mm ]
% x ( 7  ) - Vari�vel t      - Espessura da Placa                   - [ mm ]
% x ( 8  ) - Vari�vel d      - Rebaixo da Viga                      - [ mm ]
% x ( 9  ) - Vari�vel r      - Raio do Centro da C�lulad de Carga   - [ mm ]

%% Declara��o da Fun��o de Defini��o do Ponto Inicial
function [ xn ] = get_starting_point4 ( nsamples , LB , UB )
    
    %%%%%%%%%%%%%%%%%%%%
    % N�MERO RAND�MICO %
    %%%%%%%%%%%%%%%%%%%%
    
    % Garantia de N�meros Rand�micos
    rng ( 'shuffle' );    
   
    %%%%%%%%%%%%%%%%%
    % INICIALIZA��O %
    %%%%%%%%%%%%%%%%%
    
    % Inicializa��o do Vetor de N�meros Rand�micos
    xn = zeros ( nsamples , length ( LB ) );    
    
    %%%%%%%%%%%%%
    % ITERA��ES %
    %%%%%%%%%%%%%
    
    % Inicializa��o do Contador
    cont = 1;
    
    % Itera��es do Problema    
    while ( cont <= nsamples )
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % DISTRIBUI��O DAS VARI�VEIS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % Distribui��o Uniforme        
        xn ( cont , 1:end ) = LB + ( rand ( 1 , length ( LB ) ) .* ( UB - LB ) ); 
        
        %%%%%%%%%%%%%
        % VARI�VEIS %
        %%%%%%%%%%%%%

        % Defini��o das Vari�veis
        b1 = xn ( 1 , 1 );
        h1 = xn ( 1 , 2 );
        b2 = xn ( 1 , 3 );
        h2 = xn ( 1 , 4 );
        L  = xn ( 1 , 5 );
        Lf = xn ( 1 , 6 );
        t  = xn ( 1 , 7 );
        d  = xn ( 1 , 8 );
        r  = xn ( 1 , 9 );
        
        %%%%%%%%%%%%%%%%%%%
        % PAR�METROS RODA %
        %%%%%%%%%%%%%%%%%%%

        % Raio Interno da Roda
        Ri = 176 / 2;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        % RESTRI��ES GEOM�TRICAS %
        %%%%%%%%%%%%%%%%%%%%%%%%%%

        % Restri��o de Inequaldade - Geometria
        c ( 1 ) = h1 - 60;
        c ( 2 ) = h2 - 60;
        c ( 3 ) = ( L - ( t / 2 ) ) + r - Ri;
        c ( 4 ) = ( Lf / 2 ) + 15 - ( Ri * sqrt ( 2 ) / 2 );
        c ( 5 ) = ( d / min ( min ( min ( b1 , b2 ) , h1 ) , h2 ) ) - 0.10;
     
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        % VALIDA��ES DO PROBLEMA %
        %%%%%%%%%%%%%%%%%%%%%%%%%%

        % Valida��es das Restri��es do Problema
        if ( all ( c ( : ) <= 1e-8 ) )
            
            % Incremento do Contador dos Pontos
            cont = cont + 1;  

        end
        
    end
    
end